# @voxel-studio/render-runtime

共享的体素材质、合批、特效与后处理运行时。包只依赖 `three` peer dependency；场景组织、编辑器 UI、天空、水体和天气由消费方负责。

当前消费者：

- `scene-builder.html`：完整渲染运行时。
- `js/editor/VoxelMaterialTagController.js`：Voxel Studio 材质标签薄适配层。

优先从包根入口导入稳定 API；只有编辑器内部接线才直接导入 `./src/*` 子模块。
