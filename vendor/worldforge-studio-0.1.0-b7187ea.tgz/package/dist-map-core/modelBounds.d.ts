import type { Vec3 } from './protocol';
export interface Aabb {
    min: Vec3;
    max: Vec3;
}
export type ColliderCandidateRank = 'volume' | 'height' | 'planArea';
export interface ModelColliderBox extends Aabb {
    sourceNodeId?: string;
}
export interface ModelColliderPlan {
    version: 1;
    boxes: ModelColliderBox[];
    sourceMeshCount: number;
    candidateCount: number;
    fallbackUsed: boolean;
}
export interface ModelColliderProfile {
    maxBoxes: number;
    minVolume: number;
    minPlanArea: number;
    minHeight: number;
    minExtent: number;
    rankBy: ColliderCandidateRank;
    fallbackToBounds: boolean;
    padding: number;
}
export declare const MAP_ASSET_COLLIDER_PROFILE: ModelColliderProfile;
export declare const PLAYER_MODEL_COLLIDER_PROFILE: ModelColliderProfile;
export declare function calculateModelHitBounds(modelJson: unknown): Aabb;
export declare function buildModelColliderPlan(modelJson: unknown, profile?: ModelColliderProfile): ModelColliderPlan;
export declare function normalizeModelColliderPlan(value: unknown, modelJson: unknown, profile?: ModelColliderProfile): ModelColliderPlan;
export declare function modelColliderBoundingVolume(plan: ModelColliderPlan): number;
export declare function modelVolumeAtScale(plan: ModelColliderPlan, scale: number): number;
export declare function modelScaleForVolume(plan: ModelColliderPlan, volume: number): number;
export declare function rayModelHitboxIntersection(origin: Vec3, direction: Vec3, modelPosition: Vec3, rotationY: number, modelScale: number, modelJson: unknown, colliderPlan?: ModelColliderPlan | null): number | null;
export declare function modelColliderWorldAabbs(colliderPlan: ModelColliderPlan, modelPosition: Vec3, rotationY: number, modelScale: number): Aabb[];
/**
 * Returns representative points on the actual collider boxes instead of a
 * single point at the model origin. Keeping the points on each box (rather
 * than on one combined AABB) avoids counting empty space between model parts.
 */
export declare function modelColliderVisibilityPoints(colliderPlan: ModelColliderPlan, modelPosition: Vec3, rotationY: number, modelScale: number, maxBoxes?: number): Vec3[];
