export declare const MODEL_GENERATION_MODES: readonly [{
    readonly key: "standard";
    readonly label: "PRO";
}, {
    readonly key: "lite";
    readonly label: "LITE";
}, {
    readonly key: "voxel";
    readonly label: "VOXEL";
}, {
    readonly key: "voxel-pro";
    readonly label: "VOXEL-PRO";
}, {
    readonly key: "curve";
    readonly label: "CURVE";
}, {
    readonly key: "wire";
    readonly label: "WIRE";
}, {
    readonly key: "math";
    readonly label: "MATH";
}];
export type ModelGenerationMode = typeof MODEL_GENERATION_MODES[number]['key'];
export declare function normalizeModelGenerationMode(value: unknown, fallback?: ModelGenerationMode): ModelGenerationMode;
