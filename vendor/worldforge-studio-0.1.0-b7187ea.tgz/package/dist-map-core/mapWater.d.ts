import { type EditableMap, type MapWaterBody } from './map';
/**
 * Sinks a lake basin into the height field so the water plane sits inside the
 * terrain instead of hovering over it. Idempotent: every grid point is clamped
 * down to a ceiling derived purely from the lake polygon, so re-running after a
 * level or width change never digs progressively deeper. Shrinking or deleting a
 * lake leaves the basin behind as ordinary terrain.
 */
export declare function carveWaterBasinInPlace(map: EditableMap, water: MapWaterBody): void;
export declare function isNearWater(map: EditableMap, x: number, z: number, padding: number): boolean;
export declare function isPointInsideWaterBody(water: MapWaterBody, x: number, z: number): boolean;
