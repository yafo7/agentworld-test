import { type Aabb, type ModelColliderPlan } from './modelBounds';
import { type VerticalMotionState } from './math';
import type { Vec3 } from './protocol';
import { type MapAssetSizeClass } from './mapAssetMetadata';
import { type ModelGenerationMode } from './modelGenerationMode';
import { type MapGrassLayer } from './mapGrass';
import { type MapMaterialTagPolicy } from './materialTagPolicy';
import { type MapVisualSemantics } from './visualDirection';
export type MapSurface = 'floor' | 'ceiling' | 'north' | 'south' | 'east' | 'west' | 'terrain';
export type TerrainBrushMode = 'raise' | 'lower' | 'flatten';
export interface Transform3D {
    position: Vec3;
    rotation: Vec3;
    scale: Vec3;
    size: Vec3;
}
export interface MapBoxColors {
    floor: string;
    ceiling: string;
    north: string;
    south: string;
    east: string;
    west: string;
}
export interface MapBox {
    size: Vec3;
    colors: MapBoxColors;
}
export interface MapTerrain {
    resolutionX: number;
    resolutionZ: number;
    heights: number[];
}
export type MapWaterBodyType = 'lake' | 'river';
export interface MapWaterBody {
    id: string;
    name: string;
    type: MapWaterBodyType;
    level: number;
    /** Lake basin depth below `level`. Rivers keep their flat plane for now. */
    depth: number;
    width: number;
    points: Array<[number, number]>;
}
export interface MapLighting {
    sunPosition: Vec3;
}
export interface MapPaintStroke {
    id: string;
    surface: MapSurface;
    point: Vec3;
    uv: [number, number];
    color: string;
    size: number;
    softness: number;
    opacity: number;
    createdAt: number;
}
export interface MapAsset {
    id: string;
    name: string;
    prompt: string;
    tags?: string[];
    modelJson: unknown;
    colliderPlan: ModelColliderPlan;
    footprintRadius?: number;
    sizeClass?: MapAssetSizeClass;
    mode: string;
    provider?: string;
    createdAt: number;
    updatedAt: number;
}
export interface MapObject {
    id: string;
    name: string;
    parentId: string | null;
    assetId: string | null;
    transform: Transform3D;
    visible: boolean;
    locked: boolean;
}
export interface EditableMap {
    id: string;
    name: string;
    seed: number;
    assetGenerationMode: ModelGenerationMode;
    version: number;
    createdAt: number;
    updatedAt: number;
    box: MapBox;
    lighting: MapLighting;
    terrain: MapTerrain;
    grassLayers: MapGrassLayer[];
    waterBodies: MapWaterBody[];
    paintStrokes: MapPaintStroke[];
    objects: MapObject[];
    spawnPoints: Vec3[];
    spawnYaw: number;
    confirmedAt: number | null;
    renderSchemeId: string | null;
    renderPromptSuggestions: string[];
    materialTagPolicy: MapMaterialTagPolicy;
    visualSemantics: MapVisualSemantics;
    assets?: MapAsset[];
    collisionBake?: MapCollisionBake;
}
export interface MapSummary {
    id: string;
    name: string;
    version: number;
    updatedAt: number;
    width: number;
    height: number;
    depth: number;
    objectCount: number;
    assetGenerationMode: ModelGenerationMode;
    confirmedAt: number | null;
    renderSchemeId: string | null;
}
export interface MapBounds {
    minX: number;
    maxX: number;
    minY: number;
    maxY: number;
    minZ: number;
    maxZ: number;
}
export interface WorldTransform {
    position: Vec3;
    rotation: Vec3;
    scale: Vec3;
}
export interface MapObjectAabb extends Aabb {
    objectId: string;
}
export interface MapCollisionBake {
    version: 1;
    sourceHash: string;
    sourceBoxCount: number;
    boxes: MapObjectAabb[];
    cellSize: number;
    cells: Record<string, number[]>;
}
export interface CompositeMapCollisionObstacles {
    base: MapCollisionBake;
    dynamic: MapObjectAabb[];
}
export type MapCollisionObstacles = MapObjectAabb[] | MapCollisionBake | CompositeMapCollisionObstacles;
export interface PlayerVerticalMotionSweep {
    velocity: number;
    duration: number;
    jumpRequested: boolean;
}
export declare const PLAYER_RADIUS = 0.45;
export declare const PLAYER_HEIGHT = 2.7;
export declare const PLAYER_SPAWN_OBJECT_ID = "__player_spawn__";
export declare const SUN_OBJECT_ID = "__sun__";
export declare const DEFAULT_SUN_POSITION: Vec3;
export declare const DEFAULT_TERRAIN_RESOLUTION = 33;
/**
 * Terrain height 0 is sea level, not the floor. Lake basins are carved below it,
 * so the height field has to be allowed to go negative.
 */
export declare const TERRAIN_MIN_HEIGHT = -16;
export declare const MAX_WATER_DEPTH = 12;
export declare const DEFAULT_WATER_DEPTH = 1.5;
export declare const MAP_SIZE_PRESETS: readonly [{
    readonly key: "small";
    readonly label: "小";
    readonly size: Vec3;
    readonly terrain: 33;
}, {
    readonly key: "medium";
    readonly label: "中";
    readonly size: Vec3;
    readonly terrain: 65;
}, {
    readonly key: "large";
    readonly label: "大";
    readonly size: Vec3;
    readonly terrain: 129;
}];
export type MapSizePresetKey = typeof MAP_SIZE_PRESETS[number]['key'];
export declare function createEmptyMap(name?: string, id?: string, size?: Vec3, assetGenerationMode?: ModelGenerationMode): EditableMap;
export declare function createMapObject(name?: string, assetId?: string | null): MapObject;
export declare function createPaintStroke(input: Partial<MapPaintStroke> & Pick<MapPaintStroke, 'surface' | 'point'>): MapPaintStroke;
export declare function normalizeMap(input: Partial<EditableMap>): EditableMap;
export declare function mapToSummary(map: EditableMap): MapSummary;
export declare function getMapBounds(map: EditableMap): MapBounds;
export declare function getSpawnPoints(map: EditableMap): Vec3[];
export declare function getPlayerSpawnYaw(map: EditableMap): number;
export declare function getSunPosition(map: EditableMap): Vec3;
export declare function sampleTerrainHeight(map: EditableMap, x: number, z: number): number;
export declare function applyTerrainBrush(map: EditableMap, mode: TerrainBrushMode, point: Vec3, radius: number, strength: number, targetHeight?: number): EditableMap;
export declare function applyTerrainBrushInPlace(map: EditableMap, mode: TerrainBrushMode, point: Vec3, radius: number, strength: number, targetHeight?: number): void;
export declare function terrainResolutionForSize(size: Vec3): number;
export declare function addPaintStroke(map: EditableMap, stroke: Partial<MapPaintStroke> & Pick<MapPaintStroke, 'surface' | 'point'>): EditableMap;
export declare function surfaceUvFromPoint(map: EditableMap, surface: MapSurface, point: Vec3): [number, number];
export declare function resolvePlayerPositionForMap(position: Vec3, map: EditableMap, obstacles?: MapCollisionObstacles): Vec3;
/**
 * Returns the highest walkable surface below the player's feet. Object tops
 * only become support after the feet have reached them from above, so walking
 * into the side of a low object never teleports the player onto it.
 */
export declare function getPlayerSupportHeightForMap(position: Vec3, map: EditableMap, obstacles?: MapCollisionObstacles): number;
export declare function stepPlayerVerticalMotionForMap(position: Vec3, velocity: number, dt: number, jumpRequested: boolean, map: EditableMap, obstacles?: MapCollisionObstacles): VerticalMotionState;
/**
 * Moves a player along the requested horizontal delta using conservative,
 * axis-separated sweeps. Unlike endpoint-only penetration resolution, this is
 * stable across different client/server frame sizes and cannot tunnel through
 * a thin collider during a long frame. When vertical motion is supplied, the
 * player's height is sampled at the exact horizontal contact time.
 */
export declare function movePlayerPositionForMap(position: Vec3, delta: Vec3, map: EditableMap, obstacles?: MapCollisionObstacles, verticalMotion?: PlayerVerticalMotionSweep): Vec3;
export declare function spectatorPositionForMap(position: Vec3, map: EditableMap): Vec3;
export declare function getMapObjectAabbs(map: EditableMap): MapObjectAabb[];
/**
 * Bakes every visible map object's local collider into one immutable world-space
 * collision set. Aligned/overlapping boxes are merged without filling doorways
 * or gaps, then indexed into a broad-phase grid for cheap runtime queries.
 */
export declare function bakeMapCollisions(map: EditableMap): MapCollisionBake;
export declare function bakeCollisionBoxes(sourceBoxes: MapObjectAabb[], sourceHash?: string): MapCollisionBake;
export declare function getMapCollisionBake(map: EditableMap): MapCollisionBake;
export declare function firstMapRayHitDistance(origin: Vec3, direction: Vec3, map: EditableMap, maxDistance: number, obstacles?: MapCollisionObstacles): number | null;
export declare function isLineBlockedByMap(origin: Vec3, target: Vec3, map: EditableMap, obstacles?: MapCollisionObstacles): boolean;
export declare function getObjectWorldTransforms(map: EditableMap): Map<string, WorldTransform>;
export declare function terrainIndex(terrain: Pick<MapTerrain, 'resolutionX'>, x: number, z: number): number;
export declare function terrainPointAt(map: EditableMap, xIndex: number, zIndex: number): Vec3;
export declare function createId(prefix: string): string;
