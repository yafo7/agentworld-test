export type Vec3 = [number, number, number];
export declare const PLAYER_MOVE_SPEED = 4.2;
export declare const PLAYER_SPRINT_MULTIPLIER = 1.6;
export declare const SPECTATOR_MOVE_SPEED = 8;
export declare const PLAYER_JUMP_HEIGHT_MULTIPLIER = 1.5;
export declare const PLAYER_JUMP_SPEED: number;
export declare const PLAYER_GRAVITY = 18;
export declare const DEFAULT_INPUT: InputState;
export declare const MODEL_API_BASE = "https://voxel-studio-backend.zeabur.app";
export declare const MODEL_PROVIDERS: readonly ["fireworks", "glm", "gpt", "deepseek"];
export declare const CHAT_PROVIDER_OPTIONS: readonly [{
    readonly key: "gpt";
    readonly label: "GPT";
    readonly disabled: false;
}, {
    readonly key: "glm";
    readonly label: "GLM 5";
    readonly disabled: true;
}, {
    readonly key: "fireworks";
    readonly label: "GLM 5.1";
    readonly disabled: true;
}, {
    readonly key: "deepseek-v4-pro";
    readonly label: "DeepSeek V4 Pro";
    readonly disabled: true;
}];
export type ChatProvider = typeof CHAT_PROVIDER_OPTIONS[number]['key'];
export interface InputState {
    forward: boolean;
    backward: boolean;
    left: boolean;
    right: boolean;
    up: boolean;
    down: boolean;
    sprint: boolean;
    yaw: number;
    pitch: number;
}
export interface ModelJobState {
    status: 'queued' | 'running' | 'stage' | 'success' | 'error' | 'cancelled';
    stage?: string;
    message?: string;
}
export interface AgentProgressEvent {
    phase: 'planning' | 'composing' | 'consulting' | 'checking-assets' | 'resolving-assets' | 'generating-asset' | 'asset-retrying' | 'replanning' | 'compiling' | 'reviewing' | 'validating' | 'repairing' | 'complete' | 'failed';
    label: string;
    current?: number;
    total?: number;
    detail?: string;
}
