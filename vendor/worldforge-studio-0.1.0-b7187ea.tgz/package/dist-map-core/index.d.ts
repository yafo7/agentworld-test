/**
 * `@worldforge/map-core` — the zero-dependency half of WorldForge Studio.
 *
 * Everything re-exported here is pure TypeScript with no `three`, no DOM and no
 * Node imports, so a game server or a gameplay layer can run collisions, spawn
 * placement and terrain queries against the exact data the editor saved.
 *
 * Deliberately NOT exported: the map/render AI pipeline (`sceneComposition*`,
 * `mapAi` prompts, `mapLint`, `mapScatter`, `mapPlanning`) and the editor
 * transaction protocol. Those are studio internals; keeping them out keeps the
 * contract we owe downstream projects small.
 */
export * from './map';
export * from './materialTagPolicy';
export * from './mapSpawnSafety';
export * from './mapWater';
export * from './mapGrass';
export * from './terrainGeneration';
export * from './modelBounds';
export * from './mapAssetMetadata';
export * from './hdri';
export * from './renderScheme';
export * from './renderPlan';
/**
 * Vector/angle helpers shared with the editor. Namespaced because names like
 * `add`, `scale` and `length` have no business sitting in a package's top level.
 */
export * as vectorMath from './math';
