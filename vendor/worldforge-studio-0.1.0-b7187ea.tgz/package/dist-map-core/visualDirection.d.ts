export declare const VISUAL_DIRECTION_VERSION: 1;
export declare const CONTRAST_MODES: readonly ["bright-cartoon", "colored-shadow", "dramatic"];
export declare const VISUAL_TIMES_OF_DAY: readonly ["morning", "noon", "evening"];
export declare const VISUAL_TEMPERATURES: readonly ["cool", "warm"];
export declare const VISUAL_ZONE_TAGS: readonly ["grass", "forest", "water", "lowland", "dry", "settlement", "rocky"];
export type ContrastMode = typeof CONTRAST_MODES[number];
export type VisualTimeOfDay = typeof VISUAL_TIMES_OF_DAY[number];
export type VisualTemperature = typeof VISUAL_TEMPERATURES[number];
export type VisualZoneTag = typeof VISUAL_ZONE_TAGS[number];
export interface VisualPalette {
    sky: string;
    keyLight: string;
    fillLight: string;
    shadow: string;
    fog: string;
    waterBias: string;
    accent: string;
}
export interface AtmosphereFxIntent {
    masterStrength: number;
    sunShafts: number;
    pollen: number;
    vapor: number;
    dust: number;
    windStreaks: number;
}
/** Render-scheme-owned semantic source of truth. */
export interface VisualDirection {
    version: 1;
    contrastMode: ContrastMode;
    timeOfDay: VisualTimeOfDay;
    temperature: VisualTemperature;
    palette: VisualPalette;
    atmosphereFx: AtmosphereFxIntent;
}
export interface SceneVisualZone {
    id: string;
    tags: VisualZoneTag[];
    center: [number, number];
    radius: number;
    intensity: number;
}
export interface SceneWindField {
    direction: [number, number];
    speed: number;
    gustStrength: number;
    gustFrequency: number;
}
/** Map-owned spatial semantics. Coordinates and radii are in world units. */
export interface MapVisualSemantics {
    version: 1;
    zones: SceneVisualZone[];
    wind: SceneWindField;
}
export interface CompiledVisualDirection {
    contrastMode: ContrastMode;
    lightRig: {
        recipe: 'hard-day' | 'soft-morning' | 'backlit' | 'sunset';
        strength: number;
        warmth: number;
        shadowSoftness: number;
    };
    colorGrade: {
        contrast: number;
        saturation: number;
        shadowLift: number;
        temperature: number;
        tint: string;
    };
    surfaceShadowFloor: number;
    palette: VisualPalette;
    atmosphereFx: AtmosphereFxIntent;
}
export declare const DEFAULT_VISUAL_DIRECTION: VisualDirection;
export declare const DEFAULT_MAP_VISUAL_SEMANTICS: MapVisualSemantics;
export declare function normalizeVisualDirection(input: unknown): VisualDirection;
export declare function normalizeMapVisualSemantics(input: unknown): MapVisualSemantics;
export declare function compileVisualDirection(input: VisualDirection): CompiledVisualDirection;
