import type { RenderEnvironmentSettings } from './renderScheme';
import { type VisualDirection } from './visualDirection';
export type RenderModuleId = 'environment.palette' | 'environment.hdri' | 'atmosphere.fog' | 'lighting.hemisphere' | 'lighting.sun' | 'presentation.exposure' | 'runtime.surface-style' | 'runtime.outline-style' | 'runtime.presentation-style' | 'runtime.color-grade' | 'runtime.water-style' | 'runtime.grass-style' | 'runtime.material-theme' | 'runtime.light-rig' | 'runtime.post-quality' | 'runtime.effect-recipe' | 'runtime.atmosphere-fx' | 'runtime.shader-extension';
export type RenderScopeTarget = 'scene' | 'water' | 'material-tag' | 'asset-tag';
export interface RenderModuleScope {
    target: RenderScopeTarget;
    tag?: string;
}
export interface RenderModuleSelection {
    key?: string;
    id: RenderModuleId;
    scope?: RenderModuleScope;
    params: Record<string, string | number>;
}
export interface RenderPlan {
    version: 1 | 2;
    baseSchemeId: string;
    modules: RenderModuleSelection[];
    visualDirection?: VisualDirection;
}
export type RenderControlType = 'range' | 'number' | 'select' | 'color' | 'toggle' | 'code';
export interface RenderCapability {
    id: RenderModuleId;
    label: string;
    priority?: 'P1' | 'P2' | 'P3' | 'pro';
    repeatable?: boolean;
    developerOnly?: boolean;
    availability?: 'ready' | 'limited' | 'unsupported';
    availabilityNote?: string;
    params: Record<string, {
        type: 'color';
        default?: string;
        control?: RenderControlType;
    } | {
        type: 'number';
        min: number;
        max: number;
        default?: number;
        control?: RenderControlType;
    } | {
        type: 'enum';
        values: readonly string[];
        default?: string;
        control?: RenderControlType;
    } | {
        type: 'code';
        maxLength: number;
        default?: string;
        control?: RenderControlType;
    }>;
}
export interface RenderAccessRange {
    enabled: boolean;
    min?: number;
    max?: number;
    values?: string[];
}
export interface RenderParameterAccess {
    moduleId: RenderModuleId;
    parameter: string;
    control: RenderControlType;
    ai: RenderAccessRange;
    developer: RenderAccessRange;
}
export interface RenderAccessPolicy {
    version: 1;
    parameters: RenderParameterAccess[];
}
export interface RuntimeSurfaceStyle {
    mode: 'pbr' | 'cel';
    cartoon: Partial<{
        bands: number;
        shadowFloor: number;
        highlightFactor: number;
        rampStrength: number;
        transitionSoftness: number;
    }>;
}
export interface RuntimeOutlineStyle {
    mode: 'none' | 'clean' | 'ink' | 'echo' | 'curvature';
    params: Partial<{
        strength: number;
        threshold: number;
        width: number;
        color: string;
        depthWeight: number;
        normalWeight: number;
        objectWeight: number;
        materialWeight: number;
        noiseStrength: number;
        strokeVariation: number;
        echoCount: number;
        echoSpacing: number;
        echoAngle: number;
        echoStrength: number;
        echoColor: string;
        fadeStart: number;
        fadeEnd: number;
    }>;
}
export interface RuntimePresentationStyle {
    mode: 'none' | 'sketch' | 'comic-clean' | 'comic-print';
    sketch: Partial<{
        coordinateSpace: 'world' | 'screen';
        worldScale: number;
        strength: number;
        hatchSpacing: number;
        hatchAngle: number;
        lineWidth: number;
        jitter: number;
        preserveColor: boolean;
        toneStrength: number;
        toneBias: number;
        denseSpacing: number;
        darkFill: number;
        break: number;
        lineColor: string;
        paperColor: string;
    }>;
    paper: Partial<{
        strength: number;
        scale: number;
        tint: string;
    }>;
    comic: Partial<{
        halftoneStrength: number;
        cellSize: number;
        printOffset: number;
        lineBoost: number;
        lineWidth: number;
        inkColor: string;
    }>;
}
export interface RuntimeColorGrade {
    recipe: 'neutral' | 'warm' | 'cool' | 'misty' | 'cinematic' | 'pastel';
    temperature?: number;
    contrast?: number;
    saturation?: number;
    shadowLift?: number;
    tint?: string;
}
export interface RuntimeWaterStyle {
    scope: RenderModuleScope;
    recipe: 'calm-lake' | 'clear-river' | 'stylized' | 'stormy';
    opacity?: number;
    color?: string;
    shallowColor?: string;
    depthColor?: string;
    waveStrength?: number;
    waveSpeed?: number;
    foamStrength?: number;
    reflectionStrength?: number;
    environmentReflectionStrength?: number;
    environmentReflectionExposure?: number;
    reflectionDistortion?: number;
    reflectionFresnel?: number;
}
export interface RuntimeGrassStyle {
    rootColor: string;
    tipColor: string;
    paletteVariation: number;
    bands: 2 | 3;
    bladeHeight: number;
    bladeWidth: number;
    windStrength: number;
    windDirection: [number, number];
    normalFlatten: number;
    rootDarken: number;
    gradientBias: number;
    cellSize: number;
    fadeStart: number;
    fadeEnd: number;
    maxInstances: number;
    groundTint: boolean;
    groundColor: string;
    groundTintStrength: number;
}
export declare const DEFAULT_RUNTIME_GRASS_STYLE: RuntimeGrassStyle;
export interface RuntimeMaterialTheme {
    key: string;
    scope: RenderModuleScope;
    recipe: 'natural' | 'autumn' | 'winter' | 'weathered' | 'polished' | 'pastel';
    strength?: number;
    color?: string;
    roughness?: number;
    metalness?: number;
}
export interface RuntimeLightRig {
    recipe: 'neutral' | 'soft-morning' | 'hard-day' | 'backlit' | 'overcast' | 'sunset';
    strength?: number;
    warmth?: number;
    shadowSoftness?: number;
}
export interface RuntimePostQuality {
    bloom: 'off' | 'soft' | 'strong';
    bloomStrength?: number;
    ssao: 'off' | 'soft' | 'strong';
    depthOfField: 'off' | 'soft' | 'portrait';
}
export interface RuntimeEffectRecipe {
    key: string;
    scope: RenderModuleScope;
    recipe: 'glow' | 'fresnel' | 'flame' | 'magic' | 'aura' | 'sway';
    intensity?: number;
    speed?: number;
    color?: string;
}
export interface RuntimeHdriSky {
    /** Empty means "no HDRI"; the scheme's solid background stays in charge. */
    texture: string;
    rotation: number;
    exposure: number;
    saturation: number;
    intensity: number;
    tint?: string;
    tintStrength: number;
    /** Also feed the panorama to `scene.environment` through PMREM. */
    useAsEnvironment: boolean;
}
export interface RuntimeShaderExtension {
    mode: 'off' | 'whitelist-fragment' | 'isolated-glsl';
    fragmentId?: string;
    code?: string;
}
export declare const RENDER_CAPABILITIES: readonly RenderCapability[];
export declare function normalizeRenderPlan(input: unknown, allowedBaseIds?: readonly string[], accessPolicy?: RenderAccessPolicy, actor?: 'ai' | 'developer'): RenderPlan;
export declare function compileRenderPlan(plan: RenderPlan): Partial<RenderEnvironmentSettings>;
/** Density for 95% fog opacity at a user-facing visibility distance. */
export declare function fogDensityForVisibilityDistance(distance: number): number;
export declare function compileRuntimeStyle(plan: RenderPlan): RuntimeSurfaceStyle;
export declare function compileRuntimeOutline(plan: RenderPlan): RuntimeOutlineStyle;
export declare function compileRuntimePresentation(plan: RenderPlan): RuntimePresentationStyle;
export declare function compileRuntimeColorGrade(plan: RenderPlan): RuntimeColorGrade;
export declare function compileRuntimeWaterStyles(plan: RenderPlan): RuntimeWaterStyle[];
export declare function compileRuntimeGrassStyle(plan: RenderPlan): RuntimeGrassStyle;
export declare function compileRuntimeMaterialThemes(plan: RenderPlan): RuntimeMaterialTheme[];
export declare function compileRuntimeLightRig(plan: RenderPlan): RuntimeLightRig;
export declare function compileRuntimePostQuality(plan: RenderPlan): RuntimePostQuality;
export declare function compileRuntimeEffectRecipes(plan: RenderPlan): RuntimeEffectRecipe[];
export declare function compileRuntimeHdriSky(plan: RenderPlan): RuntimeHdriSky;
export declare function compileRuntimeShaderExtension(plan: RenderPlan): RuntimeShaderExtension;
export declare function createDefaultRenderAccessPolicy(): RenderAccessPolicy;
export declare function normalizeRenderAccessPolicy(input: unknown): RenderAccessPolicy;
export declare function renderCapabilitySummary(): unknown[];
export declare function renderModuleLabel(id: RenderModuleId): string;
