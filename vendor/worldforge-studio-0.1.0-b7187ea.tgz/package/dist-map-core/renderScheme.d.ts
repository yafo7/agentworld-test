import { type RenderAccessPolicy, type RenderPlan } from './renderPlan';
export interface RenderEnvironmentSettings {
    background: string;
    fogColor: string;
    fogDensity: number;
    hemisphereSkyColor: string;
    hemisphereGroundColor: string;
    hemisphereIntensity: number;
    sunColor: string;
    sunIntensity: number;
    exposure: number;
}
export interface RenderScheme {
    id: string;
    name: string;
    description: string;
    sourcePrompt: string;
    styleTags: string[];
    provider?: string;
    renderPlan?: RenderPlan;
    accessPolicy: RenderAccessPolicy;
    schemaVersion: 1;
    kind: 'builtin' | 'custom';
    settings: RenderEnvironmentSettings;
    createdAt: number;
    updatedAt: number;
}
export interface RenderSuggestion {
    baseSchemeId: string;
    settings: Partial<RenderScheme['settings']>;
    styleTags: string[];
    explanation: string;
    plan: RenderPlan;
}
export declare const BUILTIN_RENDER_SCHEMES: readonly RenderScheme[];
export declare function createRenderScheme(input: Partial<RenderScheme>): RenderScheme;
export declare function normalizeRenderScheme(input: Partial<RenderScheme>): RenderScheme;
