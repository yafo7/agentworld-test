import type { ModelColliderPlan } from './modelBounds';
export type MapAssetSizeClass = 'small' | 'medium' | 'large';
export declare function normalizeAssetTags(value: unknown): string[] | undefined;
export declare function assetFootprintRadius(plan: ModelColliderPlan): number;
export declare function assetSizeClass(radius: number): MapAssetSizeClass;
