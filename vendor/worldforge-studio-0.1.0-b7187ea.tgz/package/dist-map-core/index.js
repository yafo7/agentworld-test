const PLAYER_MOVE_SPEED = 4.2;
const PLAYER_SPRINT_MULTIPLIER = 1.6;
const SPECTATOR_MOVE_SPEED = 8;
const PLAYER_JUMP_HEIGHT_MULTIPLIER = 1.5;
const PLAYER_JUMP_SPEED = 6.5 * Math.sqrt(PLAYER_JUMP_HEIGHT_MULTIPLIER);
const PLAYER_GRAVITY = 18;
const MAX_PITCH = Math.PI / 2 - 0.08;
const EPSILON = 1e-5;
function clamp$5(value, min, max) {
  return Math.min(max, Math.max(min, value));
}
function wrapAngle(angle) {
  if (!Number.isFinite(angle)) return 0;
  return Math.atan2(Math.sin(angle), Math.cos(angle));
}
function clampPitch(pitch) {
  return clamp$5(Number.isFinite(pitch) ? pitch : 0, -MAX_PITCH, MAX_PITCH);
}
function add(a, b) {
  return [a[0] + b[0], a[1] + b[1], a[2] + b[2]];
}
function sub(a, b) {
  return [a[0] - b[0], a[1] - b[1], a[2] - b[2]];
}
function dot(a, b) {
  return a[0] * b[0] + a[1] * b[1] + a[2] * b[2];
}
function length(v) {
  return Math.hypot(v[0], v[1], v[2]);
}
function normalize(v) {
  const len = length(v);
  if (len <= EPSILON) return [0, 0, 0];
  return [v[0] / len, v[1] / len, v[2] / len];
}
function scale(v, amount) {
  return [v[0] * amount, v[1] * amount, v[2] * amount];
}
function distance(a, b) {
  return length(sub(a, b));
}
function forwardFromYawPitch(yaw, pitch = 0) {
  const safeYaw = wrapAngle(yaw);
  const safePitch = clampPitch(pitch);
  const cp = Math.cos(safePitch);
  return normalize([-Math.sin(safeYaw) * cp, Math.sin(safePitch), -Math.cos(safeYaw) * cp]);
}
function planarForwardFromYaw(yaw) {
  const safeYaw = wrapAngle(yaw);
  return normalize([-Math.sin(safeYaw), 0, -Math.cos(safeYaw)]);
}
function rightFromYaw(yaw) {
  const safeYaw = wrapAngle(yaw);
  return [Math.cos(safeYaw), 0, -Math.sin(safeYaw)];
}
function movementDelta(input, dt, spectating = false) {
  if (!Number.isFinite(dt) || dt <= 0) return [0, 0, 0];
  const forward = spectating ? forwardFromYawPitch(input.yaw, input.pitch) : planarForwardFromYaw(input.yaw);
  const right = rightFromYaw(input.yaw);
  let move = [0, 0, 0];
  if (input.forward) move = [move[0] + forward[0], move[1] + forward[1], move[2] + forward[2]];
  if (input.backward) move = [move[0] - forward[0], move[1] - forward[1], move[2] - forward[2]];
  if (input.right) move = [move[0] + right[0], move[1], move[2] + right[2]];
  if (input.left) move = [move[0] - right[0], move[1], move[2] - right[2]];
  if (spectating && input.up) move[1] += 1;
  if (spectating && input.down) move[1] -= 1;
  const direction = normalize(move);
  const speed = (spectating ? SPECTATOR_MOVE_SPEED : PLAYER_MOVE_SPEED) * (!spectating && input.sprint ? PLAYER_SPRINT_MULTIPLIER : 1);
  return [direction[0] * speed * dt, direction[1] * speed * dt, direction[2] * speed * dt];
}
function stepVerticalMotion(currentY, groundY, velocity, dt, jumpRequested) {
  const safeGround = Number.isFinite(groundY) ? groundY : 0;
  const safeY = Number.isFinite(currentY) ? Math.max(currentY, safeGround) : safeGround;
  if (!Number.isFinite(dt) || dt <= 0) {
    return { y: safeY, velocity: Number.isFinite(velocity) ? velocity : 0, grounded: safeY <= safeGround + 1e-3 };
  }
  const wasGrounded = safeY <= safeGround + 1e-3 && (!Number.isFinite(velocity) || velocity <= 0);
  let nextVelocity = Number.isFinite(velocity) ? velocity : 0;
  if (wasGrounded) nextVelocity = jumpRequested ? PLAYER_JUMP_SPEED : 0;
  const nextY = safeY + nextVelocity * dt - 0.5 * PLAYER_GRAVITY * dt * dt;
  nextVelocity -= PLAYER_GRAVITY * dt;
  if (nextY <= safeGround) return { y: safeGround, velocity: 0, grounded: true };
  return { y: nextY, velocity: nextVelocity, grounded: false };
}
function raySphereIntersection(origin, direction, center, radius) {
  if (length(direction) <= EPSILON) return null;
  const dir = normalize(direction);
  const oc = sub(origin, center);
  const b = 2 * dot(oc, dir);
  const c = dot(oc, oc) - radius * radius;
  const discriminant = b * b - 4 * c;
  if (discriminant < 0) return null;
  const root = Math.sqrt(discriminant);
  const t1 = (-b - root) / 2;
  const t2 = (-b + root) / 2;
  if (t1 >= 0) return t1;
  if (t2 >= 0) return t2;
  return null;
}
function rayAabbIntersection(origin, direction, min, max) {
  if (length(direction) <= EPSILON) return null;
  const dir = normalize(direction);
  let tMin = -Infinity;
  let tMax = Infinity;
  for (let axis = 0; axis < 3; axis += 1) {
    const d = dir[axis];
    if (Math.abs(d) < 1e-5) {
      if (origin[axis] < min[axis] || origin[axis] > max[axis]) return null;
      continue;
    }
    const inv = 1 / d;
    let t1 = (min[axis] - origin[axis]) * inv;
    let t2 = (max[axis] - origin[axis]) * inv;
    if (t1 > t2) [t1, t2] = [t2, t1];
    tMin = Math.max(tMin, t1);
    tMax = Math.min(tMax, t2);
    if (tMin > tMax) return null;
  }
  if (tMax < 0) return null;
  return tMin >= 0 ? tMin : tMax;
}
function isTargetInView(origin, yaw, pitch, target, fovDegrees = 70, maxDistance = 28) {
  const toTarget = sub(target, origin);
  const dist = length(toTarget);
  if (dist > maxDistance) return false;
  const forward = forwardFromYawPitch(yaw, pitch);
  const alignment = dot(forward, normalize(toTarget));
  return alignment >= Math.cos(fovDegrees * Math.PI / 180 / 2);
}
const math = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  MAX_PITCH,
  add,
  clamp: clamp$5,
  clampPitch,
  distance,
  dot,
  forwardFromYawPitch,
  isTargetInView,
  length,
  movementDelta,
  normalize,
  planarForwardFromYaw,
  rayAabbIntersection,
  raySphereIntersection,
  rightFromYaw,
  scale,
  stepVerticalMotion,
  sub,
  wrapAngle
}, Symbol.toStringTag, { value: "Module" }));
const MAP_ASSET_COLLIDER_PROFILE = {
  maxBoxes: 12,
  minVolume: 0.08,
  minPlanArea: 0.04,
  minHeight: 0.1,
  minExtent: 0.08,
  rankBy: "volume",
  fallbackToBounds: true,
  padding: 0
};
const PLAYER_MODEL_COLLIDER_PROFILE = {
  maxBoxes: 18,
  minVolume: 0.04,
  minPlanArea: 0.025,
  minHeight: 0.08,
  minExtent: 0.06,
  rankBy: "volume",
  fallbackToBounds: true,
  padding: 0.12
};
const IDENTITY_QUAT = [0, 0, 0, 1];
const HITBOX_PADDING = 0.12;
const MIN_HALF_EXTENT_XZ = 0.18;
const MIN_HEIGHT = 0.28;
const FALLBACK_BOUNDS = {
  min: [-0.6, 0, -0.6],
  max: [0.6, 1.2, 0.6]
};
function calculateModelHitBounds(modelJson) {
  const { rawBounds } = collectModelMeshBounds(modelJson);
  if (!rawBounds) return cloneBounds(expandHitBounds(FALLBACK_BOUNDS));
  return expandHitBounds(normalizeLikeClient(rawBounds));
}
function buildModelColliderPlan(modelJson, profile = MAP_ASSET_COLLIDER_PROFILE) {
  const collected = collectModelMeshBounds(modelJson);
  const assetBounds = collected.rawBounds ?? FALLBACK_BOUNDS;
  const candidates = collected.meshes.map((mesh) => ({ ...mesh, bounds: normalizeChildLikeClient(mesh.bounds, assetBounds) })).map((mesh) => {
    const size = boundsSize(mesh.bounds);
    return {
      ...mesh,
      volume: size[0] * size[1] * size[2],
      planArea: size[0] * size[2],
      height: size[1],
      minHorizontalExtent: Math.min(size[0], size[2])
    };
  }).filter((candidate) => candidate.minHorizontalExtent >= profile.minExtent && candidate.height >= profile.minHeight && candidate.volume >= profile.minVolume && candidate.planArea >= profile.minPlanArea);
  const selected = [...candidates].sort((a, b) => candidateRank(b, profile.rankBy) - candidateRank(a, profile.rankBy) || String(a.sourceNodeId ?? "").localeCompare(String(b.sourceNodeId ?? ""))).slice(0, Math.max(1, Math.round(profile.maxBoxes)));
  let fallbackUsed = false;
  if (selected.length === 0 && profile.fallbackToBounds) {
    selected.push({
      bounds: normalizeLikeClient(assetBounds),
      sourceNodeId: "asset-bounds",
      volume: 0,
      planArea: 0,
      height: 0,
      minHorizontalExtent: 0
    });
    fallbackUsed = true;
  }
  return {
    version: 1,
    boxes: selected.map((candidate) => ({
      ...expandBounds(candidate.bounds, profile.padding),
      sourceNodeId: candidate.sourceNodeId
    })),
    sourceMeshCount: collected.meshes.length,
    candidateCount: candidates.length,
    fallbackUsed
  };
}
function normalizeModelColliderPlan(value, modelJson, profile = MAP_ASSET_COLLIDER_PROFILE) {
  const data = value;
  const boxes = Array.isArray(data?.boxes) ? data.boxes.map(sanitizeColliderBox).filter((box) => Boolean(box)) : [];
  if (data?.version !== 1 || boxes.length === 0) return buildModelColliderPlan(modelJson, profile);
  return {
    version: 1,
    boxes: boxes.slice(0, Math.max(1, Math.round(profile.maxBoxes))),
    sourceMeshCount: Math.max(0, Math.round(finiteNumber$3(data?.sourceMeshCount, boxes.length))),
    candidateCount: Math.max(boxes.length, Math.round(finiteNumber$3(data?.candidateCount, boxes.length))),
    fallbackUsed: data?.fallbackUsed === true
  };
}
function modelColliderBoundingVolume(plan) {
  const boxes = plan.boxes.filter((box) => [...box.min, ...box.max].every(Number.isFinite));
  if (boxes.length === 0) return 1;
  const min = [Number.POSITIVE_INFINITY, Number.POSITIVE_INFINITY, Number.POSITIVE_INFINITY];
  const max = [Number.NEGATIVE_INFINITY, Number.NEGATIVE_INFINITY, Number.NEGATIVE_INFINITY];
  for (const box of boxes) {
    for (let axis = 0; axis < 3; axis += 1) {
      min[axis] = Math.min(min[axis], box.min[axis]);
      max[axis] = Math.max(max[axis], box.max[axis]);
    }
  }
  const size = boundsSize({ min, max });
  return Math.max(1e-6, size[0] * size[1] * size[2]);
}
function modelVolumeAtScale(plan, scale2) {
  const safeScale = Number.isFinite(scale2) && scale2 > 0 ? scale2 : 1;
  return modelColliderBoundingVolume(plan) * safeScale ** 3;
}
function modelScaleForVolume(plan, volume) {
  const safeVolume = Number.isFinite(volume) && volume > 0 ? volume : modelColliderBoundingVolume(plan);
  return Math.cbrt(safeVolume / modelColliderBoundingVolume(plan));
}
function rayModelHitboxIntersection(origin, direction, modelPosition, rotationY, modelScale, modelJson, colliderPlan) {
  const scaleValue = Number.isFinite(modelScale) && modelScale > 0 ? modelScale : 1;
  const plan = colliderPlan?.version === 1 && colliderPlan.boxes.length > 0 ? colliderPlan : buildModelColliderPlan(modelJson, PLAYER_MODEL_COLLIDER_PROFILE);
  const localOrigin = scaleVec3(rotateY(sub(origin, modelPosition), -rotationY), 1 / scaleValue);
  const localDirection = rotateY(direction, -rotationY);
  let closest = null;
  for (const box of plan.boxes) {
    const distance2 = rayAabbIntersection(localOrigin, localDirection, box.min, box.max);
    if (distance2 !== null && (closest === null || distance2 < closest)) closest = distance2;
  }
  return closest === null ? null : closest * scaleValue;
}
function modelColliderWorldAabbs(colliderPlan, modelPosition, rotationY, modelScale) {
  const scaleValue = Number.isFinite(modelScale) && modelScale > 0 ? modelScale : 1;
  return colliderPlan.boxes.map((box) => {
    let min = [Infinity, Infinity, Infinity];
    let max = [-Infinity, -Infinity, -Infinity];
    for (const corner of boundsCorners$1(box)) {
      const scaled = [corner[0] * scaleValue, corner[1] * scaleValue, corner[2] * scaleValue];
      const rotated = rotateY(scaled, rotationY);
      const world = [
        rotated[0] + modelPosition[0],
        rotated[1] + modelPosition[1],
        rotated[2] + modelPosition[2]
      ];
      min = [Math.min(min[0], world[0]), Math.min(min[1], world[1]), Math.min(min[2], world[2])];
      max = [Math.max(max[0], world[0]), Math.max(max[1], world[1]), Math.max(max[2], world[2])];
    }
    return { min, max };
  });
}
function modelColliderVisibilityPoints(colliderPlan, modelPosition, rotationY, modelScale, maxBoxes = 10) {
  const scaleValue = Number.isFinite(modelScale) && modelScale > 0 ? modelScale : 1;
  const boxes = colliderPlan.boxes.filter((box) => [...box.min, ...box.max].every(Number.isFinite)).sort((a, b) => boxVolume(b) - boxVolume(a)).slice(0, Math.max(1, Math.round(maxBoxes)));
  const points = [];
  for (const box of boxes) {
    const center = [
      (box.min[0] + box.max[0]) / 2,
      (box.min[1] + box.max[1]) / 2,
      (box.min[2] + box.max[2]) / 2
    ];
    const localPoints = [
      center,
      [box.min[0], center[1], center[2]],
      [box.max[0], center[1], center[2]],
      [center[0], box.min[1], center[2]],
      [center[0], box.max[1], center[2]],
      [center[0], center[1], box.min[2]],
      [center[0], center[1], box.max[2]]
    ];
    for (const point of localPoints) {
      const rotated = rotateY(scaleVec3(point, scaleValue), rotationY);
      points.push([
        rotated[0] + modelPosition[0],
        rotated[1] + modelPosition[1],
        rotated[2] + modelPosition[2]
      ]);
    }
  }
  return points;
}
function collectModelMeshBounds(modelJson) {
  const data = modelJson;
  const nodes = Array.isArray(data?.nodes) ? data.nodes : [];
  const nodeById = /* @__PURE__ */ new Map();
  for (const node of nodes) {
    if (typeof node.id === "string" && node.id) nodeById.set(node.id, node);
  }
  const transformCache = /* @__PURE__ */ new Map();
  const visiting = /* @__PURE__ */ new Set();
  const meshes = [];
  let rawBounds = null;
  for (const node of nodes) {
    if (!node.mesh) continue;
    const localBounds = localMeshBounds(node.mesh.type ?? "box", node.mesh.params ?? {});
    const transform = worldTransformFor(node, nodeById, transformCache, visiting);
    let meshBounds = null;
    for (const corner of boundsCorners$1(localBounds)) {
      const point = transformPoint(corner, transform);
      meshBounds = includePoint$1(meshBounds, point);
      rawBounds = includePoint$1(rawBounds, point);
    }
    if (meshBounds) meshes.push({ bounds: meshBounds, sourceNodeId: node.id });
  }
  return { meshes, rawBounds };
}
function candidateRank(candidate, rankBy) {
  if (rankBy === "height") return candidate.height;
  if (rankBy === "planArea") return candidate.planArea;
  return candidate.volume;
}
function normalizeChildLikeClient(bounds, assetBounds) {
  const centerX = (assetBounds.min[0] + assetBounds.max[0]) / 2;
  const centerZ = (assetBounds.min[2] + assetBounds.max[2]) / 2;
  return {
    min: [bounds.min[0] - centerX, bounds.min[1] - assetBounds.min[1], bounds.min[2] - centerZ],
    max: [bounds.max[0] - centerX, bounds.max[1] - assetBounds.min[1], bounds.max[2] - centerZ]
  };
}
function boundsSize(bounds) {
  return [
    Math.max(0, bounds.max[0] - bounds.min[0]),
    Math.max(0, bounds.max[1] - bounds.min[1]),
    Math.max(0, bounds.max[2] - bounds.min[2])
  ];
}
function boxVolume(bounds) {
  const size = boundsSize(bounds);
  return size[0] * size[1] * size[2];
}
function expandBounds(bounds, padding) {
  const safePadding = Math.max(0, finiteNumber$3(padding, 0));
  return {
    min: [bounds.min[0] - safePadding, bounds.min[1] - safePadding, bounds.min[2] - safePadding],
    max: [bounds.max[0] + safePadding, bounds.max[1] + safePadding, bounds.max[2] + safePadding]
  };
}
function sanitizeColliderBox(value) {
  const data = value;
  const min = strictVec3(data?.min);
  const max = strictVec3(data?.max);
  if (!min || !max || max[0] <= min[0] || max[1] <= min[1] || max[2] <= min[2]) return null;
  return {
    min,
    max,
    sourceNodeId: typeof data?.sourceNodeId === "string" && data.sourceNodeId ? data.sourceNodeId : void 0
  };
}
function strictVec3(value) {
  if (!Array.isArray(value) || value.length < 3) return null;
  const vector = [Number(value[0]), Number(value[1]), Number(value[2])];
  return vector.every(Number.isFinite) ? vector : null;
}
function worldTransformFor(node, nodeById, cache, visiting) {
  const cached = cache.get(node);
  if (cached) return cached;
  if (visiting.has(node)) return localTransform(node);
  visiting.add(node);
  const local = localTransform(node);
  const parent = typeof node.parent === "string" ? nodeById.get(node.parent) : void 0;
  const transform = parent ? composeTransform(worldTransformFor(parent, nodeById, cache, visiting), local) : local;
  visiting.delete(node);
  cache.set(node, transform);
  return transform;
}
function localTransform(node) {
  const transform = node.transform ?? {};
  return {
    pos: validVec3$1(transform.pos, [0, 0, 0]),
    quat: validQuat(transform.quat, IDENTITY_QUAT),
    scale: positiveVec3$1(transform.scale, [1, 1, 1])
  };
}
function composeTransform(parent, local) {
  return {
    pos: addVec3$1(parent.pos, rotateByQuat(mulVec3$1(parent.scale, local.pos), parent.quat)),
    quat: normalizeQuat(multiplyQuat(parent.quat, local.quat)),
    scale: mulVec3$1(parent.scale, local.scale)
  };
}
function transformPoint(point, transform) {
  return addVec3$1(transform.pos, rotateByQuat(mulVec3$1(transform.scale, point), transform.quat));
}
function normalizeLikeClient(bounds) {
  const centerX = (bounds.min[0] + bounds.max[0]) / 2;
  const centerZ = (bounds.min[2] + bounds.max[2]) / 2;
  return {
    min: [bounds.min[0] - centerX, 0, bounds.min[2] - centerZ],
    max: [bounds.max[0] - centerX, Math.max(0, bounds.max[1] - bounds.min[1]), bounds.max[2] - centerZ]
  };
}
function expandHitBounds(bounds) {
  const centerX = (bounds.min[0] + bounds.max[0]) / 2;
  const centerZ = (bounds.min[2] + bounds.max[2]) / 2;
  const halfX = Math.max((bounds.max[0] - bounds.min[0]) / 2, MIN_HALF_EXTENT_XZ);
  const halfZ = Math.max((bounds.max[2] - bounds.min[2]) / 2, MIN_HALF_EXTENT_XZ);
  const height = Math.max(bounds.max[1] - bounds.min[1], MIN_HEIGHT);
  return {
    min: [centerX - halfX - HITBOX_PADDING, 0, centerZ - halfZ - HITBOX_PADDING],
    max: [centerX + halfX + HITBOX_PADDING, height + HITBOX_PADDING, centerZ + halfZ + HITBOX_PADDING]
  };
}
function localMeshBounds(type, params) {
  const num = (key, fallback) => finiteNumber$3(params[key], fallback);
  switch (type) {
    case "box":
    case "wedge": {
      const width = Math.max(0.01, num("width", 1));
      const height = Math.max(0.01, num("height", 1));
      const depth = Math.max(0.01, num("depth", 1));
      return centeredBounds(width / 2, height / 2, depth / 2);
    }
    case "sphere":
    case "icosahedron":
    case "dodecahedron":
    case "octahedron": {
      const radius = Math.max(0.01, num("radius", 1));
      return centeredBounds(radius, radius, radius);
    }
    case "cylinder": {
      const radius = Math.max(Math.abs(num("radiusTop", 1)), Math.abs(num("radiusBottom", 1)), 0.01);
      return centeredBounds(radius, Math.max(0.01, num("height", 1)) / 2, radius);
    }
    case "cone": {
      const radius = Math.max(0.01, Math.abs(num("radius", 1)));
      return centeredBounds(radius, Math.max(0.01, num("height", 1)) / 2, radius);
    }
    case "torus": {
      const radius = Math.max(0.01, Math.abs(num("radius", 1)));
      const tube = Math.max(0.01, Math.abs(num("tube", 0.3)));
      return centeredBounds(radius + tube, tube, radius + tube);
    }
    case "tri":
      return vertexBounds([
        validVec3$1(params.a, [0, 0, 0]),
        validVec3$1(params.b, [1, 0, 0]),
        validVec3$1(params.c, [0, 1, 0])
      ], Math.max(0, num("d", 0)) / 2);
    case "patch":
      return patchBounds(params.vertices, Math.max(0, num("d", 0)) / 2);
    default:
      return centeredBounds(0.5, 0.5, 0.5);
  }
}
function patchBounds(vertices, thickness) {
  if (!Array.isArray(vertices)) return centeredBounds(0.5, 0.5, 0.5);
  const points = [];
  for (let index = 0; index + 2 < vertices.length; index += 3) {
    points.push([
      finiteNumber$3(vertices[index], 0),
      finiteNumber$3(vertices[index + 1], 0),
      finiteNumber$3(vertices[index + 2], 0)
    ]);
  }
  return points.length > 0 ? vertexBounds(points, thickness) : centeredBounds(0.5, 0.5, 0.5);
}
function vertexBounds(points, thickness) {
  let bounds = null;
  for (const point of points) bounds = includePoint$1(bounds, point);
  const box = bounds ?? centeredBounds(0.5, 0.5, 0.5);
  const expand = Math.max(thickness, 0.02);
  return {
    min: [box.min[0] - expand, box.min[1] - expand, box.min[2] - expand],
    max: [box.max[0] + expand, box.max[1] + expand, box.max[2] + expand]
  };
}
function centeredBounds(x, y, z) {
  return { min: [-x, -y, -z], max: [x, y, z] };
}
function boundsCorners$1(bounds) {
  const corners = [];
  for (const x of [bounds.min[0], bounds.max[0]]) {
    for (const y of [bounds.min[1], bounds.max[1]]) {
      for (const z of [bounds.min[2], bounds.max[2]]) corners.push([x, y, z]);
    }
  }
  return corners;
}
function includePoint$1(bounds, point) {
  if (!bounds) return { min: [...point], max: [...point] };
  return {
    min: [
      Math.min(bounds.min[0], point[0]),
      Math.min(bounds.min[1], point[1]),
      Math.min(bounds.min[2], point[2])
    ],
    max: [
      Math.max(bounds.max[0], point[0]),
      Math.max(bounds.max[1], point[1]),
      Math.max(bounds.max[2], point[2])
    ]
  };
}
function rotateY(vector, yaw) {
  const cos = Math.cos(yaw);
  const sin = Math.sin(yaw);
  return [
    vector[0] * cos + vector[2] * sin,
    vector[1],
    -vector[0] * sin + vector[2] * cos
  ];
}
function rotateByQuat(vector, quat) {
  const [x, y, z, w] = quat;
  const tx = 2 * (y * vector[2] - z * vector[1]);
  const ty = 2 * (z * vector[0] - x * vector[2]);
  const tz = 2 * (x * vector[1] - y * vector[0]);
  return [
    vector[0] + w * tx + (y * tz - z * ty),
    vector[1] + w * ty + (z * tx - x * tz),
    vector[2] + w * tz + (x * ty - y * tx)
  ];
}
function multiplyQuat(a, b) {
  return [
    a[3] * b[0] + a[0] * b[3] + a[1] * b[2] - a[2] * b[1],
    a[3] * b[1] - a[0] * b[2] + a[1] * b[3] + a[2] * b[0],
    a[3] * b[2] + a[0] * b[1] - a[1] * b[0] + a[2] * b[3],
    a[3] * b[3] - a[0] * b[0] - a[1] * b[1] - a[2] * b[2]
  ];
}
function normalizeQuat(quat) {
  const length2 = Math.hypot(quat[0], quat[1], quat[2], quat[3]);
  if (length2 <= 1e-5) return IDENTITY_QUAT;
  return [quat[0] / length2, quat[1] / length2, quat[2] / length2, quat[3] / length2];
}
function addVec3$1(a, b) {
  return [a[0] + b[0], a[1] + b[1], a[2] + b[2]];
}
function mulVec3$1(a, b) {
  return [a[0] * b[0], a[1] * b[1], a[2] * b[2]];
}
function scaleVec3(vector, amount) {
  return [vector[0] * amount, vector[1] * amount, vector[2] * amount];
}
function validVec3$1(value, fallback) {
  if (!Array.isArray(value) || value.length < 3) return [...fallback];
  return [
    finiteNumber$3(value[0], fallback[0]),
    finiteNumber$3(value[1], fallback[1]),
    finiteNumber$3(value[2], fallback[2])
  ];
}
function positiveVec3$1(value, fallback) {
  const vector = validVec3$1(value, fallback);
  return [
    vector[0] > 0 ? vector[0] : fallback[0],
    vector[1] > 0 ? vector[1] : fallback[1],
    vector[2] > 0 ? vector[2] : fallback[2]
  ];
}
function validQuat(value, fallback) {
  if (!Array.isArray(value) || value.length < 4) return [...fallback];
  return normalizeQuat([
    finiteNumber$3(value[0], fallback[0]),
    finiteNumber$3(value[1], fallback[1]),
    finiteNumber$3(value[2], fallback[2]),
    finiteNumber$3(value[3], fallback[3])
  ]);
}
function finiteNumber$3(value, fallback) {
  const numberValue2 = Number(value);
  return Number.isFinite(numberValue2) ? numberValue2 : fallback;
}
function cloneBounds(bounds) {
  return { min: [...bounds.min], max: [...bounds.max] };
}
function seedFromString(value) {
  let hash = 2166136261;
  for (let index = 0; index < value.length; index += 1) {
    hash ^= value.charCodeAt(index);
    hash = Math.imul(hash, 16777619);
  }
  return hash >>> 0;
}
function normalizeAssetTags(value) {
  if (!Array.isArray(value)) return void 0;
  const tags = [...new Set(value.filter((tag) => typeof tag === "string").map((tag) => tag.trim().toLowerCase().replace(/[^a-z0-9_-]/g, "").slice(0, 48)).filter(Boolean))].slice(0, 16);
  return tags.length > 0 ? tags : void 0;
}
function assetFootprintRadius(plan) {
  if (plan.boxes.length === 0) return 0.5;
  return Math.max(0.1, ...plan.boxes.map((box) => Math.max(
    Math.abs(box.min[0]),
    Math.abs(box.max[0]),
    Math.abs(box.min[2]),
    Math.abs(box.max[2])
  )));
}
function assetSizeClass(radius) {
  if (radius < 0.8) return "small";
  if (radius < 2.5) return "medium";
  return "large";
}
const MODEL_GENERATION_MODES = [
  { key: "standard", label: "PRO" },
  { key: "lite", label: "LITE" },
  { key: "voxel", label: "VOXEL" },
  { key: "voxel-pro", label: "VOXEL-PRO" },
  { key: "curve", label: "CURVE" },
  { key: "wire", label: "WIRE" },
  { key: "math", label: "MATH" }
];
const MODE_KEYS = new Set(MODEL_GENERATION_MODES.map((mode) => mode.key));
function normalizeModelGenerationMode(value, fallback = "voxel") {
  return typeof value === "string" && MODE_KEYS.has(value) ? value : fallback;
}
const MAX_GRASS_LAYERS = 8;
const DEFAULT_GRASS_MIX = { short: 0.76, tall: 0.2, flowers: 0.04 };
function normalizeGrassLayers(value, resolutionX, resolutionZ) {
  if (!Array.isArray(value)) return [];
  const seen = /* @__PURE__ */ new Set();
  const layers = [];
  for (const raw of value.slice(0, MAX_GRASS_LAYERS)) {
    if (!raw || typeof raw !== "object") continue;
    const input = raw;
    const id = cleanText$1(input.id, "") || createGrassId();
    if (seen.has(id)) continue;
    seen.add(id);
    const sourceX = positiveInt(input.resolutionX, resolutionX);
    const sourceZ = positiveInt(input.resolutionZ, resolutionZ);
    const source = normalizeDensityArray(input.densities, sourceX * sourceZ);
    layers.push({
      id,
      name: cleanText$1(input.name, `草地 ${layers.length + 1}`),
      visible: input.visible !== false,
      seed: finiteSeed(input.seed, layers.length + 1),
      resolutionX,
      resolutionZ,
      densities: sourceX === resolutionX && sourceZ === resolutionZ ? normalizeDensityArray(source, resolutionX * resolutionZ) : resampleDensity(source, sourceX, sourceZ, resolutionX, resolutionZ),
      mix: normalizeGrassMix(input.mix)
    });
  }
  return layers;
}
function createGrassLayer(input, resolutionX, resolutionZ, fallbackSeed = 1) {
  return normalizeGrassLayers([{
    ...input,
    id: cleanText$1(input.id, "") || createGrassId(),
    seed: finiteSeed(input.seed, fallbackSeed),
    resolutionX,
    resolutionZ
  }], resolutionX, resolutionZ)[0];
}
function updateGrassLayer(layer, patch) {
  return {
    ...layer,
    name: patch.name === void 0 ? layer.name : cleanText$1(patch.name, layer.name),
    visible: patch.visible === void 0 ? layer.visible : patch.visible !== false,
    seed: patch.seed === void 0 ? layer.seed : finiteSeed(patch.seed, layer.seed),
    mix: patch.mix === void 0 ? layer.mix : normalizeGrassMix({ ...layer.mix, ...patch.mix })
  };
}
function fillGrassLayerInPlace(map, layerId, density) {
  const layer = requireLayer(map, layerId);
  layer.densities.fill(clamp01(density));
}
function applyGrassBrushInPlace(map, layerId, mode, point, size = 3, strength = 0.35, targetDensity = 0.6) {
  const layer = requireLayer(map, layerId);
  const [width, , depth] = map.box.size;
  const radius = Math.max(0.1, finite(size, 3));
  const amount = clamp01(strength);
  const xMin = worldToIndex(point[0] - radius, width, layer.resolutionX);
  const xMax = worldToIndex(point[0] + radius, width, layer.resolutionX);
  const zMin = worldToIndex(point[1] - radius, depth, layer.resolutionZ);
  const zMax = worldToIndex(point[1] + radius, depth, layer.resolutionZ);
  const source = mode === "smooth" ? [...layer.densities] : layer.densities;
  for (let z = zMin; z <= zMax; z += 1) {
    for (let x = xMin; x <= xMax; x += 1) {
      const worldX = indexToWorld(x, width, layer.resolutionX);
      const worldZ = indexToWorld(z, depth, layer.resolutionZ);
      const distance2 = Math.hypot(worldX - point[0], worldZ - point[1]);
      if (distance2 > radius) continue;
      const falloff = (1 - (distance2 / radius) ** 2) ** 2;
      const index = z * layer.resolutionX + x;
      const current = source[index] ?? 0;
      if (mode === "add") layer.densities[index] = clamp01(current + amount * falloff);
      else if (mode === "erase") layer.densities[index] = clamp01(current - amount * falloff);
      else if (mode === "density") layer.densities[index] = mix(current, clamp01(targetDensity), amount * falloff);
      else layer.densities[index] = mix(current, neighborhoodAverage(source, layer, x, z), amount * falloff);
    }
  }
}
function generateGrassRegionInPlace(map, layerId, region, density = 0.7, variation = 0.25, softness = 0.2, seed) {
  const layer = requireLayer(map, layerId);
  const [width, , depth] = map.box.size;
  const baseDensity = clamp01(density);
  const densityVariation = clamp01(variation);
  const edgeSoftness = clamp01(softness);
  const effectiveSeed = finiteSeed(seed, layer.seed);
  for (let z = 0; z < layer.resolutionZ; z += 1) {
    for (let x = 0; x < layer.resolutionX; x += 1) {
      const worldX = indexToWorld(x, width, layer.resolutionX);
      const worldZ = indexToWorld(z, depth, layer.resolutionZ);
      const regionWeight = grassRegionWeight(region, worldX, worldZ, edgeSoftness);
      if (regionWeight <= 0) continue;
      const slopeWeight = grassSlopeWeight(map, x, z);
      const noise = hash01(x, z, effectiveSeed) * 2 - 1;
      const generated = clamp01(baseDensity * (1 + noise * densityVariation) * regionWeight * slopeWeight);
      const index = z * layer.resolutionX + x;
      layer.densities[index] = Math.max(layer.densities[index] ?? 0, generated);
    }
  }
}
function sampleGrassDensity(layer, map, x, z) {
  if (!layer.visible) return 0;
  const [width, , depth] = map.box.size;
  const u = clamp01(x / Math.max(width, 1e-3) + 0.5) * (layer.resolutionX - 1);
  const v = clamp01(z / Math.max(depth, 1e-3) + 0.5) * (layer.resolutionZ - 1);
  return bilinear(layer.densities, layer.resolutionX, layer.resolutionZ, u, v);
}
function combinedGrassDensity(map, x, z) {
  let remaining = 1;
  for (const layer of map.grassLayers) remaining *= 1 - sampleGrassDensity(layer, map, x, z);
  return 1 - remaining;
}
function normalizeGrassMix(value) {
  const short = Math.max(0, finite(value?.short, DEFAULT_GRASS_MIX.short));
  const tall = Math.max(0, finite(value?.tall, DEFAULT_GRASS_MIX.tall));
  const flowers = Math.max(0, finite(value?.flowers, DEFAULT_GRASS_MIX.flowers));
  const total = short + tall + flowers;
  if (total <= 1e-4) return { ...DEFAULT_GRASS_MIX };
  return { short: short / total, tall: tall / total, flowers: flowers / total };
}
function grassSlopeWeight(map, x, z) {
  const terrain = map.terrain;
  const left = terrain.heights[z * terrain.resolutionX + Math.max(0, x - 1)] ?? 0;
  const right = terrain.heights[z * terrain.resolutionX + Math.min(terrain.resolutionX - 1, x + 1)] ?? 0;
  const down = terrain.heights[Math.max(0, z - 1) * terrain.resolutionX + x] ?? 0;
  const up = terrain.heights[Math.min(terrain.resolutionZ - 1, z + 1) * terrain.resolutionX + x] ?? 0;
  const stepX = map.box.size[0] / Math.max(1, terrain.resolutionX - 1);
  const stepZ = map.box.size[2] / Math.max(1, terrain.resolutionZ - 1);
  const slope = Math.atan(Math.hypot((right - left) / Math.max(stepX * 2, 1e-3), (up - down) / Math.max(stepZ * 2, 1e-3))) * 180 / Math.PI;
  if (slope <= 20) return 1;
  if (slope >= 55) return 0;
  const t = (slope - 20) / 35;
  return 1 - t * t * (3 - 2 * t);
}
function grassRegionWeight(region, x, z, softness) {
  if (region.kind === "circle") {
    const radius = Math.max(0.1, finite(region.radius, 1));
    const normalized = Math.hypot(x - region.center[0], z - region.center[1]) / radius;
    if (normalized >= 1) return 0;
    const inner = Math.max(0, 1 - softness);
    return normalized <= inner ? 1 : 1 - smoothstep$1(inner, 1, normalized);
  }
  if (region.points.length < 3 || !pointInPolygon$1(x, z, region.points)) return 0;
  if (softness <= 0) return 1;
  const distance2 = distanceToPolygon(x, z, region.points);
  const bounds = polygonBounds(region.points);
  const fadeDistance = Math.max(0.1, Math.min(bounds.width, bounds.depth) * 0.5 * softness);
  return smoothstep$1(0, fadeDistance, distance2);
}
function requireLayer(map, layerId) {
  const layer = map.grassLayers.find((item) => item.id === layerId);
  if (!layer) throw new Error("grass_layer_not_found");
  return layer;
}
function normalizeDensityArray(value, length2) {
  const source = Array.isArray(value) ? value : [];
  return Array.from({ length: length2 }, (_, index) => clamp01(finite(source[index], 0)));
}
function resampleDensity(source, sourceX, sourceZ, targetX, targetZ) {
  return Array.from({ length: targetX * targetZ }, (_, index) => {
    const x = index % targetX;
    const z = Math.floor(index / targetX);
    return bilinear(
      source,
      sourceX,
      sourceZ,
      x / Math.max(1, targetX - 1) * Math.max(0, sourceX - 1),
      z / Math.max(1, targetZ - 1) * Math.max(0, sourceZ - 1)
    );
  });
}
function bilinear(values, width, height, x, z) {
  const x0 = Math.max(0, Math.min(width - 1, Math.floor(x)));
  const z0 = Math.max(0, Math.min(height - 1, Math.floor(z)));
  const x1 = Math.min(width - 1, x0 + 1);
  const z1 = Math.min(height - 1, z0 + 1);
  const tx = x - x0;
  const tz = z - z0;
  const top = mix(values[z0 * width + x0] ?? 0, values[z0 * width + x1] ?? 0, tx);
  const bottom = mix(values[z1 * width + x0] ?? 0, values[z1 * width + x1] ?? 0, tx);
  return clamp01(mix(top, bottom, tz));
}
function neighborhoodAverage(values, layer, x, z) {
  let total = 0;
  let count = 0;
  for (let dz = -1; dz <= 1; dz += 1) {
    for (let dx = -1; dx <= 1; dx += 1) {
      const px = Math.max(0, Math.min(layer.resolutionX - 1, x + dx));
      const pz = Math.max(0, Math.min(layer.resolutionZ - 1, z + dz));
      total += values[pz * layer.resolutionX + px] ?? 0;
      count += 1;
    }
  }
  return total / count;
}
function worldToIndex(value, size, resolution) {
  return Math.max(0, Math.min(resolution - 1, Math.floor((value / Math.max(size, 1e-3) + 0.5) * (resolution - 1))));
}
function indexToWorld(index, size, resolution) {
  return -size / 2 + index / Math.max(1, resolution - 1) * size;
}
function pointInPolygon$1(x, z, points) {
  let inside = false;
  for (let i = 0, j = points.length - 1; i < points.length; j = i, i += 1) {
    const [xi, zi] = points[i];
    const [xj, zj] = points[j];
    if (zi > z !== zj > z && x < (xj - xi) * (z - zi) / (zj - zi || 1e-9) + xi) inside = !inside;
  }
  return inside;
}
function distanceToPolygon(x, z, points) {
  let distance2 = Number.POSITIVE_INFINITY;
  for (let index = 0; index < points.length; index += 1) {
    const a = points[index];
    const b = points[(index + 1) % points.length];
    const dx = b[0] - a[0];
    const dz = b[1] - a[1];
    const t = Math.max(0, Math.min(1, ((x - a[0]) * dx + (z - a[1]) * dz) / Math.max(1e-9, dx * dx + dz * dz)));
    distance2 = Math.min(distance2, Math.hypot(x - (a[0] + dx * t), z - (a[1] + dz * t)));
  }
  return distance2;
}
function polygonBounds(points) {
  const xs = points.map((point) => point[0]);
  const zs = points.map((point) => point[1]);
  return { width: Math.max(...xs) - Math.min(...xs), depth: Math.max(...zs) - Math.min(...zs) };
}
function hash01(x, z, seed) {
  let value = Math.imul(x + 2654435769, 2246822507) ^ Math.imul(z + seed, 3266489909);
  value ^= value >>> 16;
  value = Math.imul(value, 2146121005);
  value ^= value >>> 15;
  return (value >>> 0) / 4294967295;
}
function createGrassId() {
  const random = globalThis.crypto?.randomUUID?.() ?? `${Date.now().toString(36)}-${Math.random().toString(36).slice(2)}`;
  return `grass-${random.slice(0, 18)}`;
}
function cleanText$1(value, fallback) {
  return typeof value === "string" && value.trim() ? value.trim().slice(0, 80) : fallback;
}
function positiveInt(value, fallback) {
  const parsed = Math.round(finite(value, fallback));
  return parsed > 0 ? parsed : fallback;
}
function finiteSeed(value, fallback) {
  return Number.isFinite(Number(value)) ? Math.trunc(Number(value)) >>> 0 : Math.trunc(fallback) >>> 0;
}
function finite(value, fallback) {
  const parsed = Number(value);
  return Number.isFinite(parsed) ? parsed : fallback;
}
function clamp01(value) {
  return Math.min(1, Math.max(0, value));
}
function mix(a, b, t) {
  return a + (b - a) * clamp01(t);
}
function smoothstep$1(edge0, edge1, value) {
  if (edge1 <= edge0) return value < edge0 ? 0 : 1;
  const t = clamp01((value - edge0) / (edge1 - edge0));
  return t * t * (3 - 2 * t);
}
const DEFAULT_DISABLED_MATERIAL_TAGS = ["base:fur"];
function normalizeMaterialTagPolicy(value) {
  if (!value || typeof value !== "object") {
    return { disabled: [...DEFAULT_DISABLED_MATERIAL_TAGS] };
  }
  const disabled = Array.isArray(value.disabled) ? value.disabled.map(normalizeMaterialTagSelector).filter((selector) => Boolean(selector)) : [...DEFAULT_DISABLED_MATERIAL_TAGS];
  return { disabled: [...new Set(disabled)].sort() };
}
function materialTagSelector(value) {
  if (typeof value === "string") return normalizeMaterialTagSelector(value);
  if (!value || typeof value !== "object") return null;
  const input = value;
  const tag = normalizeMaterialTagSelector(input.tag);
  if (!tag) return null;
  const enumValue2 = typeof input.value === "string" ? normalizeMaterialTagSelector(input.value) : null;
  return enumValue2 && (tag === "base" || tag === "water") ? `${tag}:${enumValue2}` : tag;
}
function isMaterialTagEnabled(value, policy) {
  const selector = materialTagSelector(value);
  return !selector || !policy.disabled.includes(selector);
}
function filterMaterialTags(tags, policy) {
  return Array.isArray(tags) ? tags.filter((tag) => isMaterialTagEnabled(tag, policy)) : [];
}
function normalizeMaterialTagSelector(value) {
  if (typeof value !== "string") return null;
  const selector = value.trim().toLowerCase();
  return /^[a-z0-9][a-z0-9._-]*(?::[a-z0-9][a-z0-9._-]*)?$/.test(selector) ? selector : null;
}
const VISUAL_DIRECTION_VERSION = 1;
const CONTRAST_MODES = ["bright-cartoon", "colored-shadow", "dramatic"];
const VISUAL_TIMES_OF_DAY = ["morning", "noon", "evening"];
const VISUAL_TEMPERATURES = ["cool", "warm"];
const VISUAL_ZONE_TAGS = ["grass", "forest", "water", "lowland", "dry", "settlement", "rocky"];
const DEFAULT_PALETTE = {
  sky: "#9cc7d5",
  keyLight: "#fff0ce",
  fillLight: "#eaf6ff",
  shadow: "#405066",
  fog: "#a9c8ce",
  waterBias: "#77aebc",
  accent: "#d8ef75"
};
const DEFAULT_VISUAL_DIRECTION = Object.freeze({
  version: VISUAL_DIRECTION_VERSION,
  contrastMode: "bright-cartoon",
  timeOfDay: "noon",
  temperature: "warm",
  palette: Object.freeze({ ...DEFAULT_PALETTE }),
  atmosphereFx: Object.freeze({
    masterStrength: 0.35,
    sunShafts: 0,
    pollen: 0,
    vapor: 0,
    dust: 0,
    windStreaks: 0
  })
});
const DEFAULT_MAP_VISUAL_SEMANTICS = Object.freeze({
  version: VISUAL_DIRECTION_VERSION,
  zones: [],
  wind: Object.freeze({
    direction: [1, 0.25],
    speed: 0.22,
    gustStrength: 0.18,
    gustFrequency: 0.12
  })
});
function normalizeVisualDirection(input) {
  const raw = objectValue(input);
  const palette = objectValue(raw.palette);
  const atmosphereFx = objectValue(raw.atmosphereFx);
  return {
    version: VISUAL_DIRECTION_VERSION,
    contrastMode: enumValue$1(raw.contrastMode, CONTRAST_MODES, DEFAULT_VISUAL_DIRECTION.contrastMode),
    timeOfDay: enumValue$1(raw.timeOfDay, VISUAL_TIMES_OF_DAY, DEFAULT_VISUAL_DIRECTION.timeOfDay),
    temperature: enumValue$1(raw.temperature, VISUAL_TEMPERATURES, DEFAULT_VISUAL_DIRECTION.temperature),
    palette: {
      sky: colorValue(palette.sky, DEFAULT_PALETTE.sky),
      keyLight: colorValue(palette.keyLight, DEFAULT_PALETTE.keyLight),
      fillLight: colorValue(palette.fillLight, DEFAULT_PALETTE.fillLight),
      shadow: colorValue(palette.shadow, DEFAULT_PALETTE.shadow),
      fog: colorValue(palette.fog, DEFAULT_PALETTE.fog),
      waterBias: colorValue(palette.waterBias, DEFAULT_PALETTE.waterBias),
      accent: colorValue(palette.accent, DEFAULT_PALETTE.accent)
    },
    atmosphereFx: {
      masterStrength: numberValue(atmosphereFx.masterStrength, DEFAULT_VISUAL_DIRECTION.atmosphereFx.masterStrength, 0, 1),
      sunShafts: numberValue(atmosphereFx.sunShafts, 0, 0, 1),
      pollen: numberValue(atmosphereFx.pollen, 0, 0, 1),
      vapor: numberValue(atmosphereFx.vapor, 0, 0, 1),
      dust: numberValue(atmosphereFx.dust, 0, 0, 1),
      windStreaks: numberValue(atmosphereFx.windStreaks, 0, 0, 1)
    }
  };
}
function normalizeMapVisualSemantics(input) {
  const raw = objectValue(input);
  const wind = objectValue(raw.wind);
  const zones = Array.isArray(raw.zones) ? raw.zones.map(normalizeVisualZone).filter((zone) => Boolean(zone)).slice(0, 24) : [];
  return {
    version: VISUAL_DIRECTION_VERSION,
    zones,
    wind: {
      direction: unitDirection(wind.direction, DEFAULT_MAP_VISUAL_SEMANTICS.wind.direction),
      speed: numberValue(wind.speed, DEFAULT_MAP_VISUAL_SEMANTICS.wind.speed, 0, 2),
      gustStrength: numberValue(wind.gustStrength, DEFAULT_MAP_VISUAL_SEMANTICS.wind.gustStrength, 0, 1),
      gustFrequency: numberValue(wind.gustFrequency, DEFAULT_MAP_VISUAL_SEMANTICS.wind.gustFrequency, 0.01, 2)
    }
  };
}
function compileVisualDirection(input) {
  const direction = normalizeVisualDirection(input);
  const temperature = direction.temperature === "warm" ? 0.14 : -0.14;
  const mode = direction.contrastMode;
  const timingRecipe = direction.timeOfDay === "morning" ? "soft-morning" : direction.timeOfDay === "evening" ? "sunset" : "hard-day";
  if (mode === "dramatic") {
    return {
      contrastMode: mode,
      lightRig: { recipe: direction.timeOfDay === "evening" ? "sunset" : "backlit", strength: 1.08, warmth: temperature, shadowSoftness: 0.2 },
      colorGrade: { contrast: 1.18, saturation: 1.02, shadowLift: 0.025, temperature, tint: direction.palette.accent },
      surfaceShadowFloor: 0.24,
      palette: direction.palette,
      atmosphereFx: direction.atmosphereFx
    };
  }
  if (mode === "colored-shadow") {
    return {
      contrastMode: mode,
      lightRig: { recipe: timingRecipe, strength: 1.02, warmth: temperature, shadowSoftness: 0.34 },
      colorGrade: { contrast: 1.12, saturation: 1.08, shadowLift: 0.05, temperature, tint: direction.palette.shadow },
      surfaceShadowFloor: 0.34,
      palette: direction.palette,
      atmosphereFx: direction.atmosphereFx
    };
  }
  return {
    contrastMode: mode,
    lightRig: { recipe: timingRecipe, strength: 1, warmth: temperature, shadowSoftness: 0.42 },
    colorGrade: { contrast: 1.08, saturation: 1.06, shadowLift: 0.07, temperature, tint: direction.palette.accent },
    surfaceShadowFloor: 0.42,
    palette: direction.palette,
    atmosphereFx: direction.atmosphereFx
  };
}
function normalizeVisualZone(value) {
  const raw = objectValue(value);
  const id = typeof raw.id === "string" ? raw.id.trim().slice(0, 80) : "";
  if (!id) return null;
  const tags = Array.isArray(raw.tags) ? [...new Set(raw.tags.filter((tag) => VISUAL_ZONE_TAGS.includes(tag)))].slice(0, 8) : [];
  return {
    id,
    tags,
    center: pairValue(raw.center, [0, 0]),
    radius: numberValue(raw.radius, 8, 0.5, 512),
    intensity: numberValue(raw.intensity, 1, 0, 1)
  };
}
function objectValue(value) {
  return value && typeof value === "object" ? value : {};
}
function enumValue$1(value, values, fallback) {
  return typeof value === "string" && values.includes(value) ? value : fallback;
}
function colorValue(value, fallback) {
  return typeof value === "string" && /^#[0-9a-f]{6}$/i.test(value.trim()) ? value.trim().toLowerCase() : fallback;
}
function numberValue(value, fallback, min, max) {
  const parsed = Number(value);
  return Math.min(max, Math.max(min, Number.isFinite(parsed) ? parsed : fallback));
}
function pairValue(value, fallback) {
  if (!Array.isArray(value) || value.length < 2) return [...fallback];
  return [numberValue(value[0], fallback[0], -512, 512), numberValue(value[1], fallback[1], -512, 512)];
}
function unitDirection(value, fallback) {
  const pair = pairValue(value, fallback);
  const length2 = Math.hypot(pair[0], pair[1]);
  return length2 > 1e-4 ? [pair[0] / length2, pair[1] / length2] : [...fallback];
}
const PLAYER_RADIUS = 0.45;
const PLAYER_HEIGHT = 2.7;
const PLAYER_SPAWN_OBJECT_ID = "__player_spawn__";
const SUN_OBJECT_ID = "__sun__";
const DEFAULT_SUN_POSITION = [-18, 24, 14];
const DEFAULT_TERRAIN_RESOLUTION = 33;
const MAX_TERRAIN_RESOLUTION = 129;
const TERRAIN_MIN_HEIGHT = -16;
const MAX_WATER_DEPTH = 12;
const DEFAULT_WATER_DEPTH = 1.5;
const DEFAULT_BOX_COLORS = {
  floor: "#3b4741",
  ceiling: "#273235",
  north: "#303b3d",
  south: "#303b3d",
  east: "#344144",
  west: "#344144"
};
const MAP_SIZE_PRESETS = [
  { key: "small", label: "小", size: [48, 12, 48], terrain: 33 },
  { key: "medium", label: "中", size: [96, 16, 96], terrain: 65 },
  { key: "large", label: "大", size: [192, 24, 192], terrain: 129 }
];
const DEFAULT_MAP_SIZE = [...MAP_SIZE_PRESETS[0].size];
const DEFAULT_TRANSFORM = {
  position: [0, 0, 0],
  rotation: [0, 0, 0],
  scale: [1, 1, 1],
  size: [1, 1, 1]
};
const FALLBACK_OBJECT_BOUNDS = {
  min: [-0.5, 0, -0.5],
  max: [0.5, 1, 0.5]
};
const MAP_COLLISION_BAKE_VERSION = 1;
const MAP_COLLISION_CELL_SIZE = 4;
const MAP_COLLISION_EPSILON = 1e-5;
const BAKED_MAP_OBJECT_ID = "__baked_map__";
function createEmptyMap(name = "未命名地图", id = createId("map"), size = DEFAULT_MAP_SIZE, assetGenerationMode = "voxel") {
  const now = Date.now();
  const safeSize = positiveVec3(size, DEFAULT_MAP_SIZE);
  const terrainResolution = terrainResolutionForSize(safeSize);
  const terrain = createFlatTerrain(terrainResolution, terrainResolution);
  return normalizeMap({
    id,
    name,
    assetGenerationMode,
    version: 1,
    createdAt: now,
    updatedAt: now,
    box: {
      size: safeSize,
      colors: { ...DEFAULT_BOX_COLORS }
    },
    lighting: {
      sunPosition: [...DEFAULT_SUN_POSITION]
    },
    terrain,
    paintStrokes: [],
    objects: [],
    spawnPoints: defaultSpawnPoints()
  });
}
function createMapObject(name = "新物体", assetId = null) {
  return {
    id: createId("obj"),
    name,
    parentId: null,
    assetId,
    transform: cloneTransform(DEFAULT_TRANSFORM),
    visible: true,
    locked: false
  };
}
function createPaintStroke(input) {
  const uv = input.uv ?? [0.5, 0.5];
  return {
    id: input.id ?? createId("paint"),
    surface: input.surface,
    point: validVec3(input.point, [0, 0, 0]),
    uv: [finiteNumber$2(uv[0], 0.5), finiteNumber$2(uv[1], 0.5)],
    color: normalizeColor(input.color, "#d8ef75"),
    size: clamp$4(finiteNumber$2(input.size, 1.2), 0.1, 20),
    softness: clamp$4(finiteNumber$2(input.softness, 0.35), 0, 1),
    opacity: clamp$4(finiteNumber$2(input.opacity, 0.95), 0.05, 1),
    createdAt: finiteNumber$2(input.createdAt, Date.now())
  };
}
function normalizeMap(input) {
  const id = typeof input.id === "string" && input.id ? input.id : createId("map");
  const boxSize = positiveVec3(input.box?.size, DEFAULT_MAP_SIZE);
  const terrainFallback = terrainResolutionForSize(boxSize);
  const terrain = normalizeTerrain(input.terrain, terrainFallback, terrainFallback);
  const map = {
    id,
    seed: Number.isFinite(Number(input.seed)) ? Math.trunc(Number(input.seed)) >>> 0 : seedFromString(id),
    name: cleanName(input.name, "未命名地图"),
    assetGenerationMode: normalizeModelGenerationMode(input.assetGenerationMode),
    version: Math.max(1, Math.round(finiteNumber$2(input.version, 1))),
    createdAt: finiteNumber$2(input.createdAt, Date.now()),
    updatedAt: finiteNumber$2(input.updatedAt, Date.now()),
    box: {
      size: boxSize,
      colors: {
        floor: normalizeColor(input.box?.colors?.floor, DEFAULT_BOX_COLORS.floor),
        ceiling: normalizeColor(input.box?.colors?.ceiling, DEFAULT_BOX_COLORS.ceiling),
        north: normalizeColor(input.box?.colors?.north, DEFAULT_BOX_COLORS.north),
        south: normalizeColor(input.box?.colors?.south, DEFAULT_BOX_COLORS.south),
        east: normalizeColor(input.box?.colors?.east, DEFAULT_BOX_COLORS.east),
        west: normalizeColor(input.box?.colors?.west, DEFAULT_BOX_COLORS.west)
      }
    },
    lighting: normalizeLighting(input.lighting),
    terrain,
    grassLayers: normalizeGrassLayers(input.grassLayers, terrain.resolutionX, terrain.resolutionZ),
    waterBodies: normalizeWaterBodies(input.waterBodies, boxSize),
    paintStrokes: Array.isArray(input.paintStrokes) ? input.paintStrokes.map((stroke) => createPaintStroke(stroke)).slice(-1200) : [],
    objects: Array.isArray(input.objects) ? input.objects.map(normalizeObject) : [],
    spawnPoints: normalizeSpawnPoints(input.spawnPoints, boxSize),
    spawnYaw: wrapAngle(finiteNumber$2(input.spawnYaw, 0)),
    confirmedAt: typeof input.confirmedAt === "number" && Number.isFinite(input.confirmedAt) && input.confirmedAt > 0 ? input.confirmedAt : null,
    renderSchemeId: typeof input.renderSchemeId === "string" && input.renderSchemeId.trim() ? input.renderSchemeId.trim().slice(0, 80) : null,
    renderPromptSuggestions: normalizeTextList(input.renderPromptSuggestions, 8, 80),
    materialTagPolicy: normalizeMaterialTagPolicy(input.materialTagPolicy),
    visualSemantics: normalizeMapVisualSemantics(input.visualSemantics),
    assets: Array.isArray(input.assets) ? input.assets.map(normalizeAsset) : void 0,
    collisionBake: normalizeMapCollisionBake(input.collisionBake)
  };
  return map;
}
function normalizeWaterBodies(value, boxSize) {
  if (!Array.isArray(value)) return [];
  const halfWidth = boxSize[0] / 2;
  const halfDepth = boxSize[2] / 2;
  const maxLevel = Math.max(0.05, boxSize[1] - 0.05);
  const maxRiverWidth = Math.max(0.3, Math.min(boxSize[0], boxSize[2]) / 2);
  const seen = /* @__PURE__ */ new Set();
  const result = [];
  for (const raw of value.slice(0, 64)) {
    if (!raw || typeof raw !== "object") continue;
    const input = raw;
    const type = input.type === "river" ? "river" : input.type === "lake" ? "lake" : null;
    if (!type || !Array.isArray(input.points)) continue;
    const points = input.points.slice(0, 64).filter((point) => Array.isArray(point) && point.length >= 2 && Number.isFinite(Number(point[0])) && Number.isFinite(Number(point[1]))).map((point) => [
      clamp$4(Number(point[0]), -halfWidth, halfWidth),
      clamp$4(Number(point[1]), -halfDepth, halfDepth)
    ]);
    if (points.length < (type === "lake" ? 3 : 2)) continue;
    const id = typeof input.id === "string" && input.id.trim() ? input.id.trim().slice(0, 80) : createId("water");
    if (seen.has(id)) continue;
    seen.add(id);
    result.push({
      id,
      name: cleanName(input.name, type === "lake" ? "湖泊" : "河流"),
      type,
      level: clamp$4(finiteNumber$2(input.level, 0.2), 0.02, maxLevel),
      depth: clamp$4(finiteNumber$2(input.depth, DEFAULT_WATER_DEPTH), 0.1, MAX_WATER_DEPTH),
      width: clamp$4(finiteNumber$2(input.width, 1.2), 0.3, maxRiverWidth),
      points
    });
  }
  return result;
}
function mapToSummary(map) {
  return {
    id: map.id,
    name: map.name,
    version: map.version,
    updatedAt: map.updatedAt,
    width: map.box.size[0],
    height: map.box.size[1],
    depth: map.box.size[2],
    objectCount: map.objects.length,
    assetGenerationMode: map.assetGenerationMode,
    confirmedAt: map.confirmedAt,
    renderSchemeId: map.renderSchemeId
  };
}
function getMapBounds(map) {
  const [width, height, depth] = map.box.size;
  return {
    minX: -width / 2,
    maxX: width / 2,
    minY: 0,
    maxY: height,
    minZ: -depth / 2,
    maxZ: depth / 2
  };
}
function getSpawnPoints(map) {
  const point = map.spawnPoints[0] ?? defaultSpawnPoints(map.box.size)[0];
  const terrainY = sampleTerrainHeight(map, point[0], point[2]);
  return [[point[0], Math.max(point[1], terrainY), point[2]]];
}
function getPlayerSpawnYaw(map) {
  return wrapAngle(map.spawnYaw);
}
function getSunPosition(map) {
  return validVec3(map.lighting?.sunPosition, DEFAULT_SUN_POSITION);
}
function sampleTerrainHeight(map, x, z) {
  const terrain = map.terrain;
  const [width, , depth] = map.box.size;
  const u = clamp$4((x + width / 2) / width, 0, 1);
  const v = clamp$4((z + depth / 2) / depth, 0, 1);
  const gx = u * (terrain.resolutionX - 1);
  const gz = v * (terrain.resolutionZ - 1);
  const x0 = Math.floor(gx);
  const z0 = Math.floor(gz);
  const x1 = Math.min(terrain.resolutionX - 1, x0 + 1);
  const z1 = Math.min(terrain.resolutionZ - 1, z0 + 1);
  const tx = gx - x0;
  const tz = gz - z0;
  const h00 = terrain.heights[terrainIndex(terrain, x0, z0)] ?? 0;
  const h10 = terrain.heights[terrainIndex(terrain, x1, z0)] ?? 0;
  const h01 = terrain.heights[terrainIndex(terrain, x0, z1)] ?? 0;
  const h11 = terrain.heights[terrainIndex(terrain, x1, z1)] ?? 0;
  return lerp$1(lerp$1(h00, h10, tx), lerp$1(h01, h11, tx), tz);
}
function applyTerrainBrush(map, mode, point, radius, strength, targetHeight) {
  const next = {
    ...map,
    terrain: {
      ...map.terrain,
      heights: [...map.terrain.heights]
    }
  };
  applyTerrainBrushInPlace(next, mode, point, radius, strength, targetHeight);
  return next;
}
function applyTerrainBrushInPlace(map, mode, point, radius, strength, targetHeight) {
  const next = map;
  const terrain = next.terrain;
  const [width, height, depth] = next.box.size;
  const brushRadius = clamp$4(Math.abs(radius), 0.15, Math.max(width, depth));
  const amount = clamp$4(Math.abs(strength), 0.01, height);
  const target = clamp$4(finiteNumber$2(targetHeight, point[1]), TERRAIN_MIN_HEIGHT, height - 0.1);
  const minX = clamp$4(Math.floor(worldToTerrainIndex(point[0] - brushRadius, width, terrain.resolutionX)), 0, terrain.resolutionX - 1);
  const maxX = clamp$4(Math.ceil(worldToTerrainIndex(point[0] + brushRadius, width, terrain.resolutionX)), 0, terrain.resolutionX - 1);
  const minZ = clamp$4(Math.floor(worldToTerrainIndex(point[2] - brushRadius, depth, terrain.resolutionZ)), 0, terrain.resolutionZ - 1);
  const maxZ = clamp$4(Math.ceil(worldToTerrainIndex(point[2] + brushRadius, depth, terrain.resolutionZ)), 0, terrain.resolutionZ - 1);
  for (let zIndex = minZ; zIndex <= maxZ; zIndex += 1) {
    for (let xIndex = minX; xIndex <= maxX; xIndex += 1) {
      const world = terrainPointAt(next, xIndex, zIndex);
      const dist = Math.hypot(world[0] - point[0], world[2] - point[2]);
      if (dist > brushRadius) continue;
      const weight = terrainBrushFalloff(dist / brushRadius);
      const index = terrainIndex(terrain, xIndex, zIndex);
      const current = terrain.heights[index] ?? 0;
      if (mode === "raise") terrain.heights[index] = clamp$4(current + amount * weight, TERRAIN_MIN_HEIGHT, height - 0.1);
      else if (mode === "lower") terrain.heights[index] = clamp$4(current - amount * weight, TERRAIN_MIN_HEIGHT, height - 0.1);
      else terrain.heights[index] = lerp$1(current, target, clamp$4(weight * amount, 0, 1));
    }
  }
  next.updatedAt = Date.now();
  next.version += 1;
}
function worldToTerrainIndex(value, extent, resolution) {
  return (value + extent / 2) / extent * (resolution - 1);
}
function terrainResolutionForSize(size) {
  const extent = Math.max(size[0], size[2]);
  if (extent <= MAP_SIZE_PRESETS[0].size[0]) return MAP_SIZE_PRESETS[0].terrain;
  if (extent <= MAP_SIZE_PRESETS[1].size[0]) return MAP_SIZE_PRESETS[1].terrain;
  return MAP_SIZE_PRESETS[2].terrain;
}
function addPaintStroke(map, stroke) {
  const next = normalizeMap(map);
  next.paintStrokes.push(createPaintStroke(stroke));
  next.paintStrokes = next.paintStrokes.slice(-1200);
  next.updatedAt = Date.now();
  next.version += 1;
  return next;
}
function surfaceUvFromPoint(map, surface, point) {
  const bounds = getMapBounds(map);
  const xU = (point[0] - bounds.minX) / (bounds.maxX - bounds.minX);
  const yU = (point[1] - bounds.minY) / (bounds.maxY - bounds.minY);
  const zU = (point[2] - bounds.minZ) / (bounds.maxZ - bounds.minZ);
  switch (surface) {
    case "ceiling":
    case "floor":
    case "terrain":
      return [clamp$4(xU, 0, 1), clamp$4(zU, 0, 1)];
    case "north":
      return [clamp$4(xU, 0, 1), clamp$4(yU, 0, 1)];
    case "south":
      return [clamp$4(1 - xU, 0, 1), clamp$4(yU, 0, 1)];
    case "east":
      return [clamp$4(zU, 0, 1), clamp$4(yU, 0, 1)];
    case "west":
      return [clamp$4(1 - zU, 0, 1), clamp$4(yU, 0, 1)];
  }
}
function resolvePlayerPositionForMap(position, map, obstacles = getMapCollisionBake(map)) {
  const bounds = getMapBounds(map);
  let x = clamp$4(position[0], bounds.minX + PLAYER_RADIUS, bounds.maxX - PLAYER_RADIUS);
  let z = clamp$4(position[2], bounds.minZ + PLAYER_RADIUS, bounds.maxZ - PLAYER_RADIUS);
  const playerBottom = Math.max(position[1], sampleTerrainHeight(map, x, z));
  const candidates = queryMapCollisionObstacles(
    obstacles,
    x - PLAYER_RADIUS * 2,
    x + PLAYER_RADIUS * 2,
    z - PLAYER_RADIUS * 2,
    z + PLAYER_RADIUS * 2
  );
  for (const obstacle of candidates) {
    if (!overlapsPlayerVertically(obstacle, playerBottom)) continue;
    const minX = obstacle.min[0] - PLAYER_RADIUS;
    const maxX = obstacle.max[0] + PLAYER_RADIUS;
    const minZ = obstacle.min[2] - PLAYER_RADIUS;
    const maxZ = obstacle.max[2] + PLAYER_RADIUS;
    if (x <= minX || x >= maxX || z <= minZ || z >= maxZ) continue;
    const pushLeft = Math.abs(x - minX);
    const pushRight = Math.abs(maxX - x);
    const pushDown = Math.abs(z - minZ);
    const pushUp = Math.abs(maxZ - z);
    const smallest = Math.min(pushLeft, pushRight, pushDown, pushUp);
    if (smallest === pushLeft) x = minX;
    else if (smallest === pushRight) x = maxX;
    else if (smallest === pushDown) z = minZ;
    else z = maxZ;
  }
  return [x, getPlayerSupportHeightForMap([x, position[1], z], map, obstacles), z];
}
function getPlayerSupportHeightForMap(position, map, obstacles = getMapCollisionBake(map)) {
  let supportY = sampleTerrainHeight(map, position[0], position[2]);
  const maxSupportY = position[1] + 0.05;
  const candidates = queryMapCollisionObstacles(
    obstacles,
    position[0] - PLAYER_RADIUS,
    position[0] + PLAYER_RADIUS,
    position[2] - PLAYER_RADIUS,
    position[2] + PLAYER_RADIUS
  );
  for (const obstacle of candidates) {
    const top = obstacle.max[1];
    if (top <= supportY || top > maxSupportY) continue;
    if (!playerFootprintOverlapsObstacle(position[0], position[2], obstacle)) continue;
    supportY = top;
  }
  return supportY;
}
function stepPlayerVerticalMotionForMap(position, velocity, dt, jumpRequested, map, obstacles = getMapCollisionBake(map)) {
  const groundY = getPlayerSupportHeightForMap(position, map, obstacles);
  const vertical = stepVerticalMotion(position[1], groundY, velocity, dt, jumpRequested);
  if (vertical.y <= position[1] + MAP_COLLISION_EPSILON) return vertical;
  const headStart = Math.max(position[1], groundY) + PLAYER_HEIGHT;
  const headEnd = vertical.y + PLAYER_HEIGHT;
  const candidates = queryMapCollisionObstacles(
    obstacles,
    position[0] - PLAYER_RADIUS,
    position[0] + PLAYER_RADIUS,
    position[2] - PLAYER_RADIUS,
    position[2] + PLAYER_RADIUS
  );
  let ceilingY = Number.POSITIVE_INFINITY;
  for (const obstacle of candidates) {
    if (!playerFootprintOverlapsObstacle(position[0], position[2], obstacle)) continue;
    const underside = obstacle.min[1];
    if (underside < headStart - MAP_COLLISION_EPSILON || underside > headEnd + MAP_COLLISION_EPSILON) continue;
    ceilingY = Math.min(ceilingY, underside);
  }
  if (!Number.isFinite(ceilingY)) return vertical;
  return {
    y: Math.max(groundY, ceilingY - PLAYER_HEIGHT - MAP_COLLISION_EPSILON),
    velocity: 0,
    grounded: false
  };
}
function movePlayerPositionForMap(position, delta, map, obstacles = getMapCollisionBake(map), verticalMotion) {
  const start = resolvePlayerPositionForMap(position, map, obstacles);
  let x = start[0];
  let z = start[2];
  const distance2 = Math.hypot(delta[0], delta[2]);
  const steps = Math.max(1, Math.ceil(distance2 / (PLAYER_RADIUS * 0.5)));
  const stepX = delta[0] / steps;
  const stepZ = delta[2] / steps;
  const playerY = Math.max(position[1], start[1]);
  const initialSupportY = verticalMotion ? getPlayerSupportHeightForMap([x, position[1], z], map, obstacles) : start[1];
  const duration = verticalMotion && Number.isFinite(verticalMotion.duration) ? Math.max(0, verticalMotion.duration) : 0;
  const stepDuration = duration / steps;
  for (let step = 0; step < steps; step += 1) {
    const stepStartsAt = step * stepDuration;
    x = sweepPlayerAxis(
      x,
      z,
      playerY,
      stepX,
      "x",
      map,
      obstacles,
      verticalMotion,
      initialSupportY,
      stepStartsAt,
      stepDuration
    );
    z = sweepPlayerAxis(
      z,
      x,
      playerY,
      stepZ,
      "z",
      map,
      obstacles,
      verticalMotion,
      initialSupportY,
      stepStartsAt,
      stepDuration
    );
  }
  return [x, getPlayerSupportHeightForMap([x, playerY, z], map, obstacles), z];
}
function sweepPlayerAxis(primary, secondary, playerY, delta, axis, map, obstacles, verticalMotion, initialSupportY, stepStartsAt, stepDuration) {
  const bounds = getMapBounds(map);
  const worldMin = axis === "x" ? bounds.minX : bounds.minZ;
  const worldMax = axis === "x" ? bounds.maxX : bounds.maxZ;
  const requestedTarget = clamp$4(primary + delta, worldMin + PLAYER_RADIUS, worldMax - PLAYER_RADIUS);
  if (Math.abs(requestedTarget - primary) <= 1e-6) return requestedTarget;
  let target = requestedTarget;
  const minPrimary = Math.min(primary, requestedTarget) - PLAYER_RADIUS;
  const maxPrimary = Math.max(primary, requestedTarget) + PLAYER_RADIUS;
  const candidates = axis === "x" ? queryMapCollisionObstacles(obstacles, minPrimary, maxPrimary, secondary - PLAYER_RADIUS, secondary + PLAYER_RADIUS) : queryMapCollisionObstacles(obstacles, secondary - PLAYER_RADIUS, secondary + PLAYER_RADIUS, minPrimary, maxPrimary);
  for (const obstacle of candidates) {
    const obstacleMin = (axis === "x" ? obstacle.min[0] : obstacle.min[2]) - PLAYER_RADIUS;
    const obstacleMax = (axis === "x" ? obstacle.max[0] : obstacle.max[2]) + PLAYER_RADIUS;
    const secondaryMin = (axis === "x" ? obstacle.min[2] : obstacle.min[0]) - PLAYER_RADIUS;
    const secondaryMax = (axis === "x" ? obstacle.max[2] : obstacle.max[0]) + PLAYER_RADIUS;
    if (secondary <= secondaryMin || secondary >= secondaryMax) continue;
    let contactPrimary;
    if (requestedTarget > primary && primary <= obstacleMin && requestedTarget > obstacleMin) {
      contactPrimary = obstacleMin;
    } else if (requestedTarget < primary && primary >= obstacleMax && requestedTarget < obstacleMax) {
      contactPrimary = obstacleMax;
    } else {
      continue;
    }
    const contactFraction = clamp$4(
      (contactPrimary - primary) / (requestedTarget - primary),
      0,
      1
    );
    const contactX = axis === "x" ? contactPrimary : secondary;
    const contactZ = axis === "z" ? contactPrimary : secondary;
    const contactTime = stepStartsAt + stepDuration * contactFraction;
    const sweptPlayerY = verticalMotion ? stepVerticalMotion(
      playerY,
      initialSupportY,
      verticalMotion.velocity,
      contactTime,
      verticalMotion.jumpRequested
    ).y : playerY;
    const playerBottom = Math.max(sweptPlayerY, sampleTerrainHeight(map, contactX, contactZ));
    if (!overlapsPlayerVertically(obstacle, playerBottom)) continue;
    if (requestedTarget > primary) {
      target = Math.min(target, obstacleMin);
    } else {
      target = Math.max(target, obstacleMax);
    }
  }
  return target;
}
function overlapsPlayerVertically(obstacle, playerBottom) {
  const epsilon = 0.05;
  return obstacle.max[1] > playerBottom + epsilon && obstacle.min[1] < playerBottom + PLAYER_HEIGHT - epsilon;
}
function playerFootprintOverlapsObstacle(x, z, obstacle) {
  const closestX = clamp$4(x, obstacle.min[0], obstacle.max[0]);
  const closestZ = clamp$4(z, obstacle.min[2], obstacle.max[2]);
  const dx = x - closestX;
  const dz = z - closestZ;
  return dx * dx + dz * dz < (PLAYER_RADIUS - MAP_COLLISION_EPSILON) ** 2;
}
function spectatorPositionForMap(position, map) {
  const bounds = getMapBounds(map);
  return [
    clamp$4(position[0], bounds.minX + PLAYER_RADIUS, bounds.maxX - PLAYER_RADIUS),
    clamp$4(position[1] + PLAYER_HEIGHT * 0.85, 0.8, bounds.maxY - 0.2),
    clamp$4(position[2], bounds.minZ + PLAYER_RADIUS, bounds.maxZ - PLAYER_RADIUS)
  ];
}
function getMapObjectAabbs(map) {
  const assets = new Map((map.assets ?? []).map((asset) => [asset.id, asset]));
  const transforms = getObjectWorldTransforms(map);
  const boxes = [];
  for (const object of map.objects) {
    if (!object.visible) continue;
    const world = transforms.get(object.id);
    if (!world) continue;
    const asset = object.assetId ? assets.get(object.assetId) : void 0;
    const localBoxes = asset ? asset.colliderPlan?.boxes.length > 0 ? asset.colliderPlan.boxes : buildModelColliderPlan(asset.modelJson, MAP_ASSET_COLLIDER_PROFILE).boxes : [FALLBACK_OBJECT_BOUNDS];
    for (const local of localBoxes) {
      const transformed = transformBounds(local, world);
      boxes.push({ objectId: object.id, min: transformed.min, max: transformed.max });
    }
  }
  return boxes;
}
function bakeMapCollisions(map) {
  const sourceBoxes = getMapObjectAabbs(map);
  return bakeCollisionBoxes(sourceBoxes, mapCollisionSourceHash(map));
}
function bakeCollisionBoxes(sourceBoxes, sourceHash = "dynamic") {
  const boxes = mergeAlignedCollisionBoxes(sourceBoxes);
  return {
    version: MAP_COLLISION_BAKE_VERSION,
    sourceHash,
    sourceBoxCount: sourceBoxes.length,
    boxes,
    cellSize: MAP_COLLISION_CELL_SIZE,
    cells: buildCollisionCells(boxes, MAP_COLLISION_CELL_SIZE)
  };
}
function getMapCollisionBake(map) {
  const existing = map.collisionBake;
  if (existing?.version === MAP_COLLISION_BAKE_VERSION && existing.sourceHash === mapCollisionSourceHash(map)) {
    return existing;
  }
  return bakeMapCollisions(map);
}
function queryMapCollisionObstacles(obstacles, minX, maxX, minZ, maxZ) {
  if (Array.isArray(obstacles)) return obstacles;
  if ("base" in obstacles) {
    return [
      ...queryMapCollisionObstacles(obstacles.base, minX, maxX, minZ, maxZ),
      ...obstacles.dynamic.filter((obstacle) => obstacle.max[0] >= minX && obstacle.min[0] <= maxX && obstacle.max[2] >= minZ && obstacle.min[2] <= maxZ)
    ];
  }
  const cellSize = obstacles.cellSize;
  const startX = Math.floor((minX - MAP_COLLISION_EPSILON) / cellSize);
  const endX = Math.floor((maxX + MAP_COLLISION_EPSILON) / cellSize);
  const startZ = Math.floor((minZ - MAP_COLLISION_EPSILON) / cellSize);
  const endZ = Math.floor((maxZ + MAP_COLLISION_EPSILON) / cellSize);
  const cellCount = (endX - startX + 1) * (endZ - startZ + 1);
  if (!Number.isFinite(cellCount) || cellCount > 4096) return obstacles.boxes;
  const indices = new Set(obstacles.cells["*"] ?? []);
  for (let z = startZ; z <= endZ; z += 1) {
    for (let x = startX; x <= endX; x += 1) {
      for (const index of obstacles.cells[collisionCellKey(x, z)] ?? []) indices.add(index);
    }
  }
  return [...indices].map((index) => obstacles.boxes[index]).filter((box) => Boolean(box) && box.max[0] >= minX - MAP_COLLISION_EPSILON && box.min[0] <= maxX + MAP_COLLISION_EPSILON && box.max[2] >= minZ - MAP_COLLISION_EPSILON && box.min[2] <= maxZ + MAP_COLLISION_EPSILON);
}
function buildCollisionCells(boxes, cellSize) {
  const cells = {};
  boxes.forEach((box, index) => {
    const startX = Math.floor(box.min[0] / cellSize);
    const endX = Math.floor(box.max[0] / cellSize);
    const startZ = Math.floor(box.min[2] / cellSize);
    const endZ = Math.floor(box.max[2] / cellSize);
    const cellCount = (endX - startX + 1) * (endZ - startZ + 1);
    if (!Number.isFinite(cellCount) || cellCount > 1024) {
      (cells["*"] ??= []).push(index);
      return;
    }
    for (let z = startZ; z <= endZ; z += 1) {
      for (let x = startX; x <= endX; x += 1) {
        (cells[collisionCellKey(x, z)] ??= []).push(index);
      }
    }
  });
  return cells;
}
function collisionCellKey(x, z) {
  return `${x},${z}`;
}
function mergeAlignedCollisionBoxes(input) {
  const unique = /* @__PURE__ */ new Map();
  for (const box of input) {
    if (!validCollisionBox(box)) continue;
    const key = [...box.min, ...box.max].map(collisionCoordinateKey).join("|");
    if (!unique.has(key)) unique.set(key, cloneCollisionBox(box));
  }
  let boxes = [...unique.values()];
  for (let pass = 0; pass < 4; pass += 1) {
    const before = boxes.length;
    boxes = mergeCollisionBoxesAlongAxis(boxes, 0);
    boxes = mergeCollisionBoxesAlongAxis(boxes, 1);
    boxes = mergeCollisionBoxesAlongAxis(boxes, 2);
    if (boxes.length === before) break;
  }
  return boxes;
}
function mergeCollisionBoxesAlongAxis(boxes, axis) {
  const otherAxes = [0, 1, 2].filter((candidate) => candidate !== axis);
  const groups = /* @__PURE__ */ new Map();
  for (const box of boxes) {
    const key = otherAxes.flatMap((other) => [box.min[other], box.max[other]]).map(collisionCoordinateKey).join("|");
    (groups.get(key) ?? groups.set(key, []).get(key)).push(box);
  }
  const merged = [];
  for (const group of groups.values()) {
    group.sort((a, b) => a.min[axis] - b.min[axis] || a.max[axis] - b.max[axis]);
    let current = cloneCollisionBox(group[0]);
    for (let index = 1; index < group.length; index += 1) {
      const next = group[index];
      if (next.min[axis] <= current.max[axis] + MAP_COLLISION_EPSILON) {
        current.max[axis] = Math.max(current.max[axis], next.max[axis]);
        if (current.objectId !== next.objectId) current.objectId = BAKED_MAP_OBJECT_ID;
      } else {
        merged.push(current);
        current = cloneCollisionBox(next);
      }
    }
    merged.push(current);
  }
  return merged;
}
function collisionCoordinateKey(value) {
  return (Math.round(value / MAP_COLLISION_EPSILON) * MAP_COLLISION_EPSILON).toFixed(5);
}
function cloneCollisionBox(box) {
  return { objectId: box.objectId, min: [...box.min], max: [...box.max] };
}
function validCollisionBox(box) {
  return [...box.min, ...box.max].every(Number.isFinite) && box.max[0] - box.min[0] > MAP_COLLISION_EPSILON && box.max[1] - box.min[1] > MAP_COLLISION_EPSILON && box.max[2] - box.min[2] > MAP_COLLISION_EPSILON;
}
function mapCollisionSourceHash(map) {
  const referencedAssetIds = new Set(map.objects.map((object) => object.assetId).filter((id) => Boolean(id)));
  const assets = (map.assets ?? []).filter((asset) => referencedAssetIds.has(asset.id)).map((asset) => [asset.id, asset.colliderPlan.version, asset.colliderPlan.boxes]);
  const source = JSON.stringify({
    objects: map.objects.map((object) => [
      object.id,
      object.parentId,
      object.assetId,
      object.visible,
      object.transform.position,
      object.transform.rotation,
      object.transform.scale,
      object.transform.size
    ]),
    assets
  });
  let hash = 2166136261;
  for (let index = 0; index < source.length; index += 1) {
    hash ^= source.charCodeAt(index);
    hash = Math.imul(hash, 16777619);
  }
  return (hash >>> 0).toString(36);
}
function firstMapRayHitDistance(origin, direction, map, maxDistance, obstacles = getMapCollisionBake(map)) {
  let closest = null;
  const targetX = origin[0] + direction[0] * maxDistance;
  const targetZ = origin[2] + direction[2] * maxDistance;
  const candidates = queryMapCollisionObstacles(
    obstacles,
    Math.min(origin[0], targetX),
    Math.max(origin[0], targetX),
    Math.min(origin[2], targetZ),
    Math.max(origin[2], targetZ)
  );
  for (const obstacle of candidates) {
    const t = rayAabbIntersection(origin, direction, obstacle.min, obstacle.max);
    if (t === null || t <= 0.05 || t > maxDistance) continue;
    if (closest === null || t < closest) closest = t;
  }
  return closest;
}
function isLineBlockedByMap(origin, target, map, obstacles = getMapCollisionBake(map)) {
  const delta = [target[0] - origin[0], target[1] - origin[1], target[2] - origin[2]];
  const maxDistance = Math.hypot(delta[0], delta[1], delta[2]);
  if (maxDistance <= 1e-5) return false;
  const dir = [delta[0] / maxDistance, delta[1] / maxDistance, delta[2] / maxDistance];
  const candidates = queryMapCollisionObstacles(
    obstacles,
    Math.min(origin[0], target[0]),
    Math.max(origin[0], target[0]),
    Math.min(origin[2], target[2]),
    Math.max(origin[2], target[2])
  );
  for (const obstacle of candidates) {
    const hit = rayAabbIntersection(origin, dir, obstacle.min, obstacle.max);
    if (hit !== null && hit > 0.05 && hit < maxDistance - 0.1) return true;
  }
  return false;
}
function getObjectWorldTransforms(map) {
  const byId = new Map(map.objects.map((object) => [object.id, object]));
  const cache = /* @__PURE__ */ new Map();
  const visiting = /* @__PURE__ */ new Set();
  const resolve = (object) => {
    const cached = cache.get(object.id);
    if (cached) return cloneWorldTransform(cached);
    if (visiting.has(object.id)) return localWorldTransform(object);
    visiting.add(object.id);
    const parent = object.parentId ? byId.get(object.parentId) : void 0;
    const world = parent ? composeWorldTransform(resolve(parent), object) : localWorldTransform(object);
    visiting.delete(object.id);
    cache.set(object.id, cloneWorldTransform(world));
    return world;
  };
  for (const object of map.objects) resolve(object);
  return cache;
}
function terrainIndex(terrain, x, z) {
  return z * terrain.resolutionX + x;
}
function terrainPointAt(map, xIndex, zIndex) {
  const terrain = map.terrain;
  const [width, , depth] = map.box.size;
  const x = -width / 2 + xIndex / Math.max(1, terrain.resolutionX - 1) * width;
  const z = -depth / 2 + zIndex / Math.max(1, terrain.resolutionZ - 1) * depth;
  const y = terrain.heights[terrainIndex(terrain, xIndex, zIndex)] ?? 0;
  return [x, y, z];
}
function terrainBrushFalloff(normalizedDistance) {
  const t = clamp$4(normalizedDistance, 0, 1);
  return (1 - t * t) ** 2;
}
function createId(prefix) {
  const random = globalThis.crypto?.randomUUID?.() ?? `${Date.now().toString(36)}-${Math.random().toString(36).slice(2)}`;
  return `${prefix}-${random.slice(0, 18)}`;
}
function normalizeObject(input) {
  return {
    id: typeof input.id === "string" && input.id ? input.id : createId("obj"),
    name: cleanName(input.name, "未命名物体"),
    parentId: typeof input.parentId === "string" && input.parentId ? input.parentId : null,
    assetId: typeof input.assetId === "string" && input.assetId ? input.assetId : null,
    transform: normalizeTransform(input.transform),
    visible: input.visible !== false,
    locked: input.locked === true
  };
}
function normalizeAsset(input) {
  const now = Date.now();
  const colliderPlan = normalizeModelColliderPlan(input.colliderPlan, input.modelJson, MAP_ASSET_COLLIDER_PROFILE);
  const footprintRadius = Number.isFinite(Number(input.footprintRadius)) ? Math.max(0.1, Number(input.footprintRadius)) : assetFootprintRadius(colliderPlan);
  return {
    id: typeof input.id === "string" && input.id ? input.id : createId("asset"),
    name: cleanName(input.name, "未命名资产"),
    prompt: typeof input.prompt === "string" ? input.prompt : "",
    tags: normalizeAssetTags(input.tags),
    modelJson: input.modelJson ?? null,
    colliderPlan,
    footprintRadius,
    sizeClass: input.sizeClass === "small" || input.sizeClass === "medium" || input.sizeClass === "large" ? input.sizeClass : assetSizeClass(footprintRadius),
    mode: typeof input.mode === "string" && input.mode ? input.mode : "voxel",
    provider: typeof input.provider === "string" && input.provider ? input.provider : void 0,
    createdAt: finiteNumber$2(input.createdAt, now),
    updatedAt: finiteNumber$2(input.updatedAt, now)
  };
}
function normalizeTextList(value, maxItems, maxLength) {
  if (!Array.isArray(value)) return [];
  return [...new Set(value.filter((item) => typeof item === "string").map((item) => item.trim().slice(0, maxLength)).filter(Boolean))].slice(0, maxItems);
}
function normalizeMapCollisionBake(input) {
  if (input?.version !== MAP_COLLISION_BAKE_VERSION || typeof input.sourceHash !== "string" || !Array.isArray(input.boxes)) return void 0;
  const boxes = input.boxes.map((box) => ({
    objectId: typeof box?.objectId === "string" ? box.objectId : BAKED_MAP_OBJECT_ID,
    min: validVec3(box?.min, [0, 0, 0]),
    max: validVec3(box?.max, [0, 0, 0])
  })).filter(validCollisionBox);
  const cellSize = clamp$4(finiteNumber$2(input.cellSize, MAP_COLLISION_CELL_SIZE), 1, 32);
  return {
    version: MAP_COLLISION_BAKE_VERSION,
    sourceHash: input.sourceHash,
    sourceBoxCount: Math.max(boxes.length, Math.round(finiteNumber$2(input.sourceBoxCount, boxes.length))),
    boxes,
    cellSize,
    cells: buildCollisionCells(boxes, cellSize)
  };
}
function normalizeTransform(transform) {
  return {
    position: validVec3(transform?.position, DEFAULT_TRANSFORM.position),
    rotation: validVec3(transform?.rotation, DEFAULT_TRANSFORM.rotation),
    scale: positiveVec3(transform?.scale, DEFAULT_TRANSFORM.scale),
    size: positiveVec3(transform?.size, DEFAULT_TRANSFORM.size)
  };
}
function createFlatTerrain(resolutionX, resolutionZ) {
  return {
    resolutionX,
    resolutionZ,
    heights: Array.from({ length: resolutionX * resolutionZ }, () => 0)
  };
}
function normalizeLighting(input) {
  return {
    sunPosition: validVec3(input?.sunPosition, DEFAULT_SUN_POSITION)
  };
}
function normalizeTerrain(input, fallbackX, fallbackZ) {
  const sourceX = clamp$4(Math.round(finiteNumber$2(input?.resolutionX, fallbackX)), 2, MAX_TERRAIN_RESOLUTION);
  const sourceZ = clamp$4(Math.round(finiteNumber$2(input?.resolutionZ, fallbackZ)), 2, MAX_TERRAIN_RESOLUTION);
  const resolutionX = clamp$4(Math.max(sourceX, fallbackX), 2, MAX_TERRAIN_RESOLUTION);
  const resolutionZ = clamp$4(Math.max(sourceZ, fallbackZ), 2, MAX_TERRAIN_RESOLUTION);
  const sourceLength = sourceX * sourceZ;
  const sourceHeights = Array.isArray(input?.heights) ? input.heights.slice(0, sourceLength).map((value) => clamp$4(finiteNumber$2(value, 0), TERRAIN_MIN_HEIGHT, 64)) : [];
  while (sourceHeights.length < sourceLength) sourceHeights.push(0);
  const heights = sourceX === resolutionX && sourceZ === resolutionZ ? sourceHeights : resampleTerrainHeights(sourceHeights, sourceX, sourceZ, resolutionX, resolutionZ);
  return { resolutionX, resolutionZ, heights };
}
function resampleTerrainHeights(source, sourceX, sourceZ, targetX, targetZ) {
  const heights = [];
  for (let z = 0; z < targetZ; z += 1) {
    const gz = z / Math.max(1, targetZ - 1) * (sourceZ - 1);
    const z0 = Math.floor(gz);
    const z1 = Math.min(sourceZ - 1, z0 + 1);
    const tz = gz - z0;
    for (let x = 0; x < targetX; x += 1) {
      const gx = x / Math.max(1, targetX - 1) * (sourceX - 1);
      const x0 = Math.floor(gx);
      const x1 = Math.min(sourceX - 1, x0 + 1);
      const tx = gx - x0;
      const h00 = source[z0 * sourceX + x0] ?? 0;
      const h10 = source[z0 * sourceX + x1] ?? 0;
      const h01 = source[z1 * sourceX + x0] ?? 0;
      const h11 = source[z1 * sourceX + x1] ?? 0;
      heights.push(lerp$1(lerp$1(h00, h10, tx), lerp$1(h01, h11, tx), tz));
    }
  }
  return heights;
}
function normalizeSpawnPoints(points, size) {
  const [width, height, depth] = size;
  const source = Array.isArray(points) && points.length > 0 ? points[0] : defaultSpawnPoints()[0];
  const point = validVec3(source, [0, 0, 0]);
  return [[
    clamp$4(point[0], -width / 2 + PLAYER_RADIUS, width / 2 - PLAYER_RADIUS),
    clamp$4(point[1], 0, Math.max(0, height - PLAYER_HEIGHT)),
    clamp$4(point[2], -depth / 2 + PLAYER_RADIUS, depth / 2 - PLAYER_RADIUS)
  ]];
}
function defaultSpawnPoints(size) {
  return [[0, 0, 0]];
}
function composeWorldTransform(parent, object) {
  const local = object.transform;
  const localScale = mulVec3(local.scale, local.size);
  return {
    position: addVec3(parent.position, rotateEuler(mulVec3(parent.scale, local.position), parent.rotation)),
    rotation: addVec3(parent.rotation, local.rotation),
    scale: mulVec3(parent.scale, localScale)
  };
}
function localWorldTransform(object) {
  return {
    position: [...object.transform.position],
    rotation: [...object.transform.rotation],
    scale: mulVec3(object.transform.scale, object.transform.size)
  };
}
function transformBounds(bounds, transform) {
  let result = null;
  for (const corner of boundsCorners(bounds)) {
    result = includePoint(result, addVec3(transform.position, rotateEuler(mulVec3(transform.scale, corner), transform.rotation)));
  }
  return result ?? { min: [0, 0, 0], max: [0, 0, 0] };
}
function boundsCorners(bounds) {
  const corners = [];
  for (const x of [bounds.min[0], bounds.max[0]]) {
    for (const y of [bounds.min[1], bounds.max[1]]) {
      for (const z of [bounds.min[2], bounds.max[2]]) corners.push([x, y, z]);
    }
  }
  return corners;
}
function includePoint(bounds, point) {
  if (!bounds) return { min: [...point], max: [...point] };
  return {
    min: [
      Math.min(bounds.min[0], point[0]),
      Math.min(bounds.min[1], point[1]),
      Math.min(bounds.min[2], point[2])
    ],
    max: [
      Math.max(bounds.max[0], point[0]),
      Math.max(bounds.max[1], point[1]),
      Math.max(bounds.max[2], point[2])
    ]
  };
}
function rotateEuler(vector, rotation) {
  const [rx, ry, rz] = rotation;
  const cx = Math.cos(rx);
  const sx = Math.sin(rx);
  const cy = Math.cos(ry);
  const sy = Math.sin(ry);
  const cz = Math.cos(rz);
  const sz = Math.sin(rz);
  let x = vector[0];
  let y = vector[1];
  let z = vector[2];
  const y1 = y * cx - z * sx;
  const z1 = y * sx + z * cx;
  y = y1;
  z = z1;
  const x2 = x * cy + z * sy;
  const z2 = -x * sy + z * cy;
  x = x2;
  z = z2;
  const x3 = x * cz - y * sz;
  const y3 = x * sz + y * cz;
  return [x3, y3, z];
}
function normalizeColor(value, fallback) {
  if (typeof value !== "string") return fallback;
  const trimmed = value.trim();
  if (/^#[0-9a-fA-F]{6}$/.test(trimmed)) return trimmed.toLowerCase();
  if (/^0x[0-9a-fA-F]{6}$/.test(trimmed)) return `#${trimmed.slice(2).toLowerCase()}`;
  return fallback;
}
function cleanName(value, fallback) {
  if (typeof value !== "string") return fallback;
  const cleaned = value.trim().slice(0, 48);
  return cleaned || fallback;
}
function cloneTransform(transform) {
  return {
    position: [...transform.position],
    rotation: [...transform.rotation],
    scale: [...transform.scale],
    size: [...transform.size]
  };
}
function cloneWorldTransform(transform) {
  return {
    position: [...transform.position],
    rotation: [...transform.rotation],
    scale: [...transform.scale]
  };
}
function validVec3(value, fallback) {
  if (!Array.isArray(value) || value.length < 3) return [...fallback];
  return [
    finiteNumber$2(value[0], fallback[0]),
    finiteNumber$2(value[1], fallback[1]),
    finiteNumber$2(value[2], fallback[2])
  ];
}
function positiveVec3(value, fallback) {
  const vector = validVec3(value, fallback);
  return [
    vector[0] > 0 ? vector[0] : fallback[0],
    vector[1] > 0 ? vector[1] : fallback[1],
    vector[2] > 0 ? vector[2] : fallback[2]
  ];
}
function addVec3(a, b) {
  return [a[0] + b[0], a[1] + b[1], a[2] + b[2]];
}
function mulVec3(a, b) {
  return [a[0] * b[0], a[1] * b[1], a[2] * b[2]];
}
function finiteNumber$2(value, fallback) {
  const numberValue2 = Number(value);
  return Number.isFinite(numberValue2) ? numberValue2 : fallback;
}
function clamp$4(value, min, max) {
  return Math.min(max, Math.max(min, value));
}
function lerp$1(a, b, t) {
  return a + (b - a) * t;
}
function terrainSlopeDegrees(map, x, z) {
  const stepX = map.box.size[0] / Math.max(1, map.terrain.resolutionX - 1);
  const stepZ = map.box.size[2] / Math.max(1, map.terrain.resolutionZ - 1);
  const riseX = (sampleTerrainHeight(map, x + stepX, z) - sampleTerrainHeight(map, x - stepX, z)) / (2 * stepX);
  const riseZ = (sampleTerrainHeight(map, x, z + stepZ) - sampleTerrainHeight(map, x, z - stepZ)) / (2 * stepZ);
  return Math.atan(Math.hypot(riseX, riseZ)) * 180 / Math.PI;
}
const SHORE_SLOPE = 1.5;
const SHORE_RIM = 0.05;
function carveWaterBasinInPlace(map, water) {
  if (water.type !== "lake" || water.points.length < 3) return;
  const terrain = map.terrain;
  const [boxWidth, , boxDepth] = map.box.size;
  const top = water.level - SHORE_RIM;
  const bottom = Math.max(TERRAIN_MIN_HEIGHT, water.level - water.depth);
  const shore = Math.max(0.5, water.depth * SHORE_SLOPE);
  const xs = water.points.map((point) => point[0]);
  const zs = water.points.map((point) => point[1]);
  const minX = gridFloor(Math.min(...xs), boxWidth, terrain.resolutionX);
  const maxX = gridCeil(Math.max(...xs), boxWidth, terrain.resolutionX);
  const minZ = gridFloor(Math.min(...zs), boxDepth, terrain.resolutionZ);
  const maxZ = gridCeil(Math.max(...zs), boxDepth, terrain.resolutionZ);
  for (let zIndex = minZ; zIndex <= maxZ; zIndex += 1) {
    for (let xIndex = minX; xIndex <= maxX; xIndex += 1) {
      const world = terrainPointAt(map, xIndex, zIndex);
      if (!pointInPolygon(world[0], world[2], water.points)) continue;
      const t = Math.min(1, polygonEdgeDistance(world[0], world[2], water.points) / shore);
      const ceiling = top + (bottom - top) * (t * t * (3 - 2 * t));
      const index = terrainIndex(terrain, xIndex, zIndex);
      terrain.heights[index] = Math.min(terrain.heights[index] ?? 0, ceiling);
    }
  }
}
function isNearWater(map, x, z, padding) {
  return map.waterBodies.some((water) => {
    if (water.type === "river") {
      const safeDistance = Math.max(0, water.width / 2 + padding);
      return water.points.slice(1).some(
        (point, index) => distanceToSegment(x, z, water.points[index], point) <= safeDistance
      );
    }
    if (pointInPolygon(x, z, water.points)) return true;
    return polygonEdgeDistance(x, z, water.points) <= padding;
  });
}
function isPointInsideWaterBody(water, x, z) {
  if (water.type === "river") {
    return water.points.slice(1).some(
      (point, index) => distanceToSegment(x, z, water.points[index], point) <= water.width / 2
    );
  }
  return pointInPolygon(x, z, water.points);
}
function polygonEdgeDistance(x, z, points) {
  let closest = Number.POSITIVE_INFINITY;
  for (let index = 0; index < points.length; index += 1) {
    closest = Math.min(
      closest,
      distanceToSegment(x, z, points[index], points[(index + 1) % points.length])
    );
  }
  return closest;
}
function pointInPolygon(x, z, points) {
  let inside = false;
  for (let index = 0, previous = points.length - 1; index < points.length; previous = index, index += 1) {
    const [xi, zi] = points[index];
    const [xj, zj] = points[previous];
    if (zi > z !== zj > z && x < (xj - xi) * (z - zi) / (zj - zi) + xi) {
      inside = !inside;
    }
  }
  return inside;
}
function distanceToSegment(x, z, start, end) {
  const dx = end[0] - start[0];
  const dz = end[1] - start[1];
  const lengthSquared = dx * dx + dz * dz;
  if (lengthSquared <= 1e-6) return Math.hypot(x - start[0], z - start[1]);
  const t = Math.min(1, Math.max(0, ((x - start[0]) * dx + (z - start[1]) * dz) / lengthSquared));
  return Math.hypot(x - (start[0] + t * dx), z - (start[1] + t * dz));
}
function gridFloor(world, extent, resolution) {
  return Math.max(0, Math.floor((world + extent / 2) / extent * (resolution - 1)));
}
function gridCeil(world, extent, resolution) {
  return Math.min(resolution - 1, Math.ceil((world + extent / 2) / extent * (resolution - 1)));
}
function isSpawnPositionSafe(map, x, z) {
  const bounds = getMapBounds(map);
  if (x < bounds.minX + PLAYER_RADIUS || x > bounds.maxX - PLAYER_RADIUS) return false;
  if (z < bounds.minZ + PLAYER_RADIUS || z > bounds.maxZ - PLAYER_RADIUS) return false;
  if (isNearWater(map, x, z, PLAYER_RADIUS + 0.2)) return false;
  if (terrainSlopeDegrees(map, x, z) > 35) return false;
  return !getMapObjectAabbs(map).some((obstacle) => {
    const closestX = clamp$3(x, obstacle.min[0], obstacle.max[0]);
    const closestZ = clamp$3(z, obstacle.min[2], obstacle.max[2]);
    return Math.hypot(x - closestX, z - closestZ) < PLAYER_RADIUS + 0.1;
  });
}
function findSafeSpawnPosition(map, requestedX, requestedZ) {
  const bounds = getMapBounds(map);
  const terrainStep = Math.max(
    1,
    Math.min(
      map.box.size[0] / Math.max(1, map.terrain.resolutionX - 1),
      map.box.size[2] / Math.max(1, map.terrain.resolutionZ - 1)
    )
  );
  const maxRadius = Math.min(map.box.size[0], map.box.size[2]) / 3;
  for (let radius = 0; radius <= maxRadius; radius += terrainStep) {
    const candidateCount = radius === 0 ? 1 : Math.max(8, Math.ceil(Math.PI * 2 * radius / terrainStep));
    for (let index = 0; index < candidateCount; index += 1) {
      const angle = candidateCount === 1 ? 0 : index / candidateCount * Math.PI * 2;
      const x = clamp$3(
        requestedX + Math.cos(angle) * radius,
        bounds.minX + PLAYER_RADIUS,
        bounds.maxX - PLAYER_RADIUS
      );
      const z = clamp$3(
        requestedZ + Math.sin(angle) * radius,
        bounds.minZ + PLAYER_RADIUS,
        bounds.maxZ - PLAYER_RADIUS
      );
      if (isSpawnPositionSafe(map, x, z)) return [x, z];
    }
  }
  return [
    clamp$3(requestedX, bounds.minX + PLAYER_RADIUS, bounds.maxX - PLAYER_RADIUS),
    clamp$3(requestedZ, bounds.minZ + PLAYER_RADIUS, bounds.maxZ - PLAYER_RADIUS)
  ];
}
function clamp$3(value, min, max) {
  return Math.min(max, Math.max(min, value));
}
const TERRAIN_GENERATION_PRESETS = ["plain", "hills", "valley", "island", "canyon"];
function normalizeTerrainGenerationParams(value, map) {
  if (!value || typeof value !== "object") throw new Error("invalid_terrain_generation");
  const input = value;
  if (!TERRAIN_GENERATION_PRESETS.includes(input.preset)) {
    throw new Error("invalid_terrain_generation");
  }
  const preset = input.preset;
  const defaultAmplitude = preset === "plain" ? 0 : map.box.size[1] * 0.42;
  return {
    preset,
    seed: normalizeSeed(input.seed, map.seed),
    amplitude: clamp$2(finiteNumber$1(input.amplitude, defaultAmplitude), 0, map.box.size[1] - 0.05),
    roughness: clamp$2(finiteNumber$1(input.roughness, 0.55), 0, 1)
  };
}
function generateTerrainInPlace(map, value) {
  const params = normalizeTerrainGenerationParams(value, map);
  const terrain = map.terrain;
  const maxHeight = map.box.size[1] - 0.05;
  const rotateAxis = (params.seed & 1) === 1;
  for (let z = 0; z < terrain.resolutionZ; z += 1) {
    const nz = z / Math.max(1, terrain.resolutionZ - 1) * 2 - 1;
    for (let x = 0; x < terrain.resolutionX; x += 1) {
      const nx = x / Math.max(1, terrain.resolutionX - 1) * 2 - 1;
      const axis = rotateAxis ? nz : nx;
      const crossAxis = rotateAxis ? nx : nz;
      const noise = fbm((nx + 1) * 1.7, (nz + 1) * 1.7, params.seed, params.roughness);
      const detail = (noise + 1) / 2;
      let height = 0;
      switch (params.preset) {
        case "plain":
          height = 0;
          break;
        case "hills":
          height = params.amplitude * (0.12 + detail * 0.78);
          break;
        case "valley": {
          const valleyAxis = Math.abs(axis + noise * 0.16);
          height = params.amplitude * (0.08 + Math.pow(valleyAxis, 1.55) * 0.72 + detail * 0.12);
          break;
        }
        case "island": {
          const radius = Math.min(1.25, Math.hypot(nx, nz));
          const falloff = smoothstep(1.08, 0.16, radius);
          height = params.amplitude * (falloff * (0.55 + detail * 0.38) - (1 - falloff) * 0.08);
          break;
        }
        case "canyon": {
          const wanderingAxis = Math.abs(axis + noise * 0.2 + Math.sin(crossAxis * 2.4) * 0.06);
          const wall = smoothstep(0.12, 0.52, wanderingAxis);
          height = params.amplitude * (0.06 + wall * 0.82 + detail * 0.08);
          break;
        }
      }
      terrain.heights[z * terrain.resolutionX + x] = clamp$2(height, TERRAIN_MIN_HEIGHT, maxHeight);
    }
  }
  return params;
}
function fbm(x, z, seed, roughness) {
  let value = 0;
  let amplitude = 1;
  let frequency = 1;
  let total = 0;
  const gain = 0.34 + roughness * 0.28;
  const lacunarity = 1.8 + roughness * 0.7;
  for (let octave = 0; octave < 4; octave += 1) {
    value += valueNoise(x * frequency, z * frequency, seed + octave * 1013) * amplitude;
    total += amplitude;
    amplitude *= gain;
    frequency *= lacunarity;
  }
  return total > 0 ? value / total : 0;
}
function valueNoise(x, z, seed) {
  const x0 = Math.floor(x);
  const z0 = Math.floor(z);
  const tx = smooth(x - x0);
  const tz = smooth(z - z0);
  const a = hashNoise(x0, z0, seed);
  const b = hashNoise(x0 + 1, z0, seed);
  const c = hashNoise(x0, z0 + 1, seed);
  const d = hashNoise(x0 + 1, z0 + 1, seed);
  return lerp(lerp(a, b, tx), lerp(c, d, tx), tz);
}
function hashNoise(x, z, seed) {
  let value = Math.imul(x, 374761393) + Math.imul(z, 668265263) + Math.imul(seed, 69069);
  value = Math.imul(value ^ value >>> 13, 1274126177);
  return ((value ^ value >>> 16) >>> 0) / 21474836475e-1 - 1;
}
function normalizeSeed(value, fallback) {
  const number = Number(value);
  return Number.isFinite(number) ? Math.trunc(number) >>> 0 : fallback >>> 0;
}
function finiteNumber$1(value, fallback) {
  const number = Number(value);
  return Number.isFinite(number) ? number : fallback;
}
function smooth(value) {
  return value * value * (3 - 2 * value);
}
function smoothstep(edge0, edge1, value) {
  const t = clamp$2((value - edge0) / (edge1 - edge0), 0, 1);
  return t * t * (3 - 2 * t);
}
function lerp(a, b, t) {
  return a + (b - a) * t;
}
function clamp$2(value, min, max) {
  return Math.min(max, Math.max(min, value));
}
const HDRI_EXTENSIONS = ["hdr", "exr", "jpg", "jpeg", "png"];
const HDRI_CATALOG_FILE = "catalog.json";
function parseHdriCatalog(value) {
  const raw = value && typeof value === "object" ? value : {};
  const entries = Array.isArray(raw.textures) ? raw.textures : [];
  const catalog = /* @__PURE__ */ new Map();
  for (const item of entries) {
    if (!item || typeof item !== "object") continue;
    const entry = item;
    const file = typeof entry.file === "string" ? entry.file.trim() : "";
    if (!file || !hdriExtensionOf(file)) continue;
    const tags = Array.isArray(entry.tags) ? [...new Set(entry.tags.filter((tag) => typeof tag === "string").map((tag) => tag.trim().toLowerCase().replace(/[^a-z0-9-]/g, "-").slice(0, 32)).filter(Boolean))].slice(0, 12) : [];
    const color2 = (candidate) => typeof candidate === "string" && /^#[0-9a-f]{6}$/i.test(candidate) ? candidate.toLowerCase() : void 0;
    catalog.set(file, { file, tags, skyColor: color2(entry.skyColor), groundColor: color2(entry.groundColor) });
  }
  return catalog;
}
function hdriExtensionOf(file) {
  const extension = file.split(".").pop()?.toLowerCase() ?? "";
  return HDRI_EXTENSIONS.includes(extension) ? extension : null;
}
function compileVisualEnvironment(direction) {
  const compiled = compileVisualDirection(direction);
  const palette = compiled.palette;
  return {
    background: palette.sky,
    fogColor: mixHexColors(palette.fillLight, palette.fog, 0.68),
    hemisphereSkyColor: palette.fillLight,
    hemisphereGroundColor: mixHexColors(palette.shadow, palette.fillLight, 0.18),
    hemisphereIntensity: compiled.contrastMode === "dramatic" ? 1.1 : 1.45,
    sunColor: palette.keyLight,
    sunIntensity: compiled.contrastMode === "dramatic" ? 3.1 : 2.7,
    exposure: direction.timeOfDay === "evening" ? 1.04 : 1
  };
}
function compileVisualWaterPalette(direction) {
  const { palette } = compileVisualDirection(direction);
  return {
    color: palette.waterBias,
    shallowColor: mixHexColors(palette.waterBias, palette.fillLight, 0.42),
    depthColor: mixHexColors(palette.waterBias, palette.shadow, 0.62)
  };
}
function visualMaterialTint(direction, tag = "") {
  const palette = compileVisualDirection(direction).palette;
  const normalized = tag.toLowerCase();
  if (/stone|rock|metal/.test(normalized)) return { color: palette.shadow, strength: 0.12 };
  if (/wood|bark/.test(normalized)) return { color: mixHexColors(palette.shadow, palette.keyLight, 0.24), strength: 0.1 };
  return { color: palette.accent, strength: 0.1 };
}
function mixHexColors(base, tint, amount) {
  const t = clamp$1(amount, 0, 1);
  const a = channels(base);
  const b = channels(tint);
  return `#${a.map((value, index) => Math.round(value + ((b[index] ?? value) - value) * t).toString(16).padStart(2, "0")).join("")}`;
}
function channels(value) {
  const safe = /^#[0-9a-f]{6}$/i.test(value) ? value : "#000000";
  return [1, 3, 5].map((offset) => Number.parseInt(safe.slice(offset, offset + 2), 16));
}
function clamp$1(value, min, max) {
  return Math.min(max, Math.max(min, value));
}
const DEFAULT_RUNTIME_GRASS_STYLE = {
  rootColor: "#72ad49",
  tipColor: "#b7df76",
  paletteVariation: 0.1,
  bands: 3,
  bladeHeight: 0.95,
  bladeWidth: 0.18,
  windStrength: 0.22,
  windDirection: [1, 0.25],
  normalFlatten: 0.8,
  rootDarken: 0.8,
  gradientBias: 0.7,
  cellSize: 0.8,
  fadeStart: 72,
  fadeEnd: 140,
  maxInstances: 15e3,
  groundTint: true,
  groundColor: "#669746",
  groundTintStrength: 0.82
};
const RENDER_CAPABILITIES = [
  {
    id: "environment.palette",
    label: "环境色板",
    params: { background: { type: "color" }, fogColor: { type: "color" } }
  },
  {
    id: "environment.hdri",
    label: "HDRI 天空",
    priority: "P1",
    availability: "ready",
    availabilityNote: "贴图取自 data/map-editor/hdri 目录，同时作为背景天空球与 PMREM 环境光。",
    params: {
      // ponytail: `code` type means "free string, developer only" — exactly the
      // access rule wanted here, so the AI cannot invent a filename.
      texture: { type: "code", maxLength: 120, default: "", control: "select" },
      rotation: { type: "number", min: -180, max: 180, default: 0 },
      exposure: { type: "number", min: 0.05, max: 4, default: 1 },
      saturation: { type: "number", min: 0, max: 2, default: 1 },
      intensity: { type: "number", min: 0, max: 4, default: 1 },
      tint: { type: "color", default: "#ffffff" },
      tintStrength: { type: "number", min: 0, max: 1, default: 0 },
      useAsEnvironment: { type: "enum", values: ["on", "off"], default: "on" }
    }
  },
  {
    id: "atmosphere.fog",
    label: "全局雾",
    params: {
      visibilityDistance: { type: "number", min: 40, max: 800, default: 300 },
      density: { type: "number", min: 0, max: 0.045, default: 6e-3 }
    }
  },
  {
    id: "lighting.hemisphere",
    label: "环境光",
    params: {
      skyColor: { type: "color" },
      groundColor: { type: "color" },
      intensity: { type: "number", min: 0, max: 8 }
    }
  },
  {
    id: "lighting.sun",
    label: "太阳光",
    params: { color: { type: "color" }, intensity: { type: "number", min: 0, max: 12 } }
  },
  {
    id: "presentation.exposure",
    label: "画面曝光",
    params: { value: { type: "number", min: 0.2, max: 3 } }
  },
  {
    id: "runtime.surface-style",
    label: "Runtime 表面风格",
    params: {
      mode: { type: "enum", values: ["pbr", "cel"] },
      bands: { type: "number", min: 2, max: 8 },
      shadowFloor: { type: "number", min: 0.2, max: 0.6 },
      highlightFactor: { type: "number", min: 0.5, max: 1.5 },
      rampStrength: { type: "number", min: 0, max: 1 },
      transitionSoftness: { type: "number", min: 0, max: 1 }
    }
  },
  {
    id: "runtime.outline-style",
    label: "Runtime 统一描边",
    params: {
      mode: { type: "enum", values: ["none", "clean", "ink", "echo", "curvature"] },
      strength: { type: "number", min: 0.25, max: 2 },
      threshold: { type: "number", min: 0.02, max: 0.3 },
      width: { type: "number", min: 0.5, max: 5 },
      color: { type: "color" },
      depthWeight: { type: "number", min: 0, max: 2 },
      normalWeight: { type: "number", min: 0, max: 2 },
      objectWeight: { type: "number", min: 0, max: 2 },
      materialWeight: { type: "number", min: 0, max: 2 },
      noiseStrength: { type: "number", min: 0, max: 0.8 },
      strokeVariation: { type: "number", min: 0, max: 1 },
      echoCount: { type: "number", min: 0, max: 3 },
      echoSpacing: { type: "number", min: 1, max: 6 },
      echoAngle: { type: "number", min: -180, max: 180 },
      echoStrength: { type: "number", min: 0, max: 1 },
      echoColor: { type: "color" },
      fadeStart: { type: "number", min: 20, max: 400, default: 120 },
      fadeEnd: { type: "number", min: 30, max: 600, default: 260 }
    }
  },
  {
    id: "runtime.presentation-style",
    label: "Runtime 画面风格",
    params: {
      mode: { type: "enum", values: ["none", "sketch", "comic-clean", "comic-print"] },
      coordinateSpace: { type: "enum", values: ["world", "screen"] },
      worldScale: { type: "number", min: 0.25, max: 12 },
      strength: { type: "number", min: 0.25, max: 1 },
      hatchSpacing: { type: "number", min: 3, max: 16 },
      hatchAngle: { type: "number", min: 0, max: 180 },
      lineWidth: { type: "number", min: 0.08, max: 0.5 },
      jitter: { type: "number", min: 0, max: 0.5 },
      colorMode: { type: "enum", values: ["color", "monochrome"] },
      toneStrength: { type: "number", min: 0, max: 1 },
      toneBias: { type: "number", min: -0.5, max: 0.5 },
      denseSpacing: { type: "number", min: 0.15, max: 1 },
      darkFill: { type: "number", min: 0, max: 1 },
      break: { type: "number", min: 0, max: 0.6 },
      lineColor: { type: "color" },
      paperColor: { type: "color" },
      paperStrength: { type: "number", min: 0, max: 0.5 },
      paperScale: { type: "number", min: 0.5, max: 8 },
      paperTint: { type: "color" },
      halftoneStrength: { type: "number", min: 0, max: 0.7 },
      halftoneCellSize: { type: "number", min: 3, max: 16 },
      printOffset: { type: "number", min: 0, max: 1 },
      comicLineBoost: { type: "number", min: 0, max: 0.6 },
      comicLineWidth: { type: "number", min: 0.5, max: 4 },
      comicInkColor: { type: "color" }
    }
  },
  {
    id: "runtime.color-grade",
    label: "色彩分级",
    priority: "P1",
    availability: "ready",
    params: {
      recipe: {
        type: "enum",
        values: ["neutral", "warm", "cool", "misty", "cinematic", "pastel"],
        default: "neutral"
      },
      temperature: { type: "number", min: -1, max: 1, default: 0 },
      contrast: { type: "number", min: 0.5, max: 1.6, default: 1 },
      saturation: { type: "number", min: 0, max: 1.8, default: 1 },
      shadowLift: { type: "number", min: 0, max: 0.35, default: 0 },
      tint: { type: "color", default: "#ffffff" }
    }
  },
  {
    id: "runtime.water-style",
    label: "水体风格",
    priority: "P1",
    repeatable: true,
    availability: "ready",
    availabilityNote: "作用于结构化湖泊/河流和带 water 标签的模型水面。",
    params: {
      recipe: {
        type: "enum",
        values: ["calm-lake", "clear-river", "stylized", "stormy"],
        default: "calm-lake"
      },
      opacity: { type: "number", min: 0.25, max: 1, default: 0.88 },
      color: { type: "color", default: "#4f96a8" },
      shallowColor: { type: "color", default: "#71b8bd" },
      depthColor: { type: "color", default: "#173b50" },
      waveStrength: { type: "number", min: 0, max: 1.5, default: 0.35 },
      waveSpeed: { type: "number", min: 0, max: 2, default: 0.3 },
      foamStrength: { type: "number", min: 0, max: 1.5, default: 0.45 },
      reflectionStrength: { type: "number", min: 0, max: 1.5, default: 0.6 },
      environmentReflectionStrength: { type: "number", min: 0, max: 1, default: 0.3 },
      environmentReflectionExposure: { type: "number", min: 0.1, max: 1.5, default: 0.55 },
      reflectionDistortion: { type: "number", min: 0, max: 0.2, default: 0.04 },
      reflectionFresnel: { type: "number", min: 0, max: 3, default: 1 }
    }
  },
  {
    id: "runtime.grass-style",
    label: "卡通草地风格",
    priority: "P1",
    availability: "ready",
    availabilityNote: "草地分布属于地图；这里调整所有草层的叶片、风与远景地表染色。",
    params: {
      rootColor: { type: "color", default: DEFAULT_RUNTIME_GRASS_STYLE.rootColor },
      tipColor: { type: "color", default: DEFAULT_RUNTIME_GRASS_STYLE.tipColor },
      paletteVariation: { type: "number", min: 0, max: 0.5, default: DEFAULT_RUNTIME_GRASS_STYLE.paletteVariation },
      bands: { type: "enum", values: ["2", "3"], default: "3" },
      bladeHeight: { type: "number", min: 0.5, max: 1.4, default: DEFAULT_RUNTIME_GRASS_STYLE.bladeHeight },
      bladeWidth: { type: "number", min: 0.1, max: 0.28, default: DEFAULT_RUNTIME_GRASS_STYLE.bladeWidth },
      windStrength: { type: "number", min: 0, max: 0.65, default: DEFAULT_RUNTIME_GRASS_STYLE.windStrength },
      windAngle: { type: "number", min: -180, max: 180, default: 14 },
      normalFlatten: { type: "number", min: 0, max: 1, default: DEFAULT_RUNTIME_GRASS_STYLE.normalFlatten },
      rootDarken: { type: "number", min: 0.15, max: 1, default: DEFAULT_RUNTIME_GRASS_STYLE.rootDarken },
      gradientBias: { type: "number", min: 0.2, max: 2, default: DEFAULT_RUNTIME_GRASS_STYLE.gradientBias },
      cellSize: { type: "number", min: 0.55, max: 1.4, default: DEFAULT_RUNTIME_GRASS_STYLE.cellSize },
      fadeStart: { type: "number", min: 10, max: 120, default: DEFAULT_RUNTIME_GRASS_STYLE.fadeStart },
      fadeEnd: { type: "number", min: 15, max: 180, default: DEFAULT_RUNTIME_GRASS_STYLE.fadeEnd },
      maxInstances: { type: "number", min: 1e3, max: 3e4, default: DEFAULT_RUNTIME_GRASS_STYLE.maxInstances },
      groundTint: { type: "enum", values: ["on", "off"], default: "on", control: "toggle" },
      groundColor: { type: "color", default: DEFAULT_RUNTIME_GRASS_STYLE.groundColor },
      groundTintStrength: { type: "number", min: 0, max: 1, default: DEFAULT_RUNTIME_GRASS_STYLE.groundTintStrength }
    }
  },
  {
    id: "runtime.material-theme",
    label: "标签材质主题",
    priority: "P1",
    repeatable: true,
    availability: "ready",
    params: {
      recipe: {
        type: "enum",
        values: ["natural", "autumn", "winter", "weathered", "polished", "pastel"],
        default: "natural"
      },
      strength: { type: "number", min: 0, max: 1, default: 1 },
      color: { type: "color", default: "#ffffff" },
      roughness: { type: "number", min: 0, max: 1, default: 0.72 },
      metalness: { type: "number", min: 0, max: 1, default: 0.04 }
    }
  },
  {
    id: "runtime.light-rig",
    label: "灯光配方",
    priority: "P2",
    availability: "ready",
    params: {
      recipe: {
        type: "enum",
        values: ["neutral", "soft-morning", "hard-day", "backlit", "overcast", "sunset"],
        default: "neutral"
      },
      strength: { type: "number", min: 0.25, max: 2, default: 1 },
      warmth: { type: "number", min: -1, max: 1, default: 0 },
      shadowSoftness: { type: "number", min: 0, max: 1, default: 0.65 }
    }
  },
  {
    id: "runtime.post-quality",
    label: "后处理质量",
    priority: "P2",
    availability: "limited",
    availabilityNote: "Bloom 与 SSAO 已接通；景深保留高层契约，当前宿主暂不执行。",
    params: {
      bloom: { type: "enum", values: ["off", "soft", "strong"], default: "off" },
      bloomStrength: { type: "number", min: 0, max: 1.5, default: 0.4 },
      ssao: { type: "enum", values: ["off", "soft", "strong"], default: "off" },
      depthOfField: { type: "enum", values: ["off", "soft", "portrait"], default: "off" }
    }
  },
  {
    id: "runtime.atmosphere-fx",
    label: "环境动态特效",
    priority: "P2",
    availability: "ready",
    availabilityNote: "语义自动触发保持微弱；这里调节总量与各通道上限。",
    params: {
      masterStrength: { type: "number", min: 0, max: 1, default: 0.35 },
      semanticStrength: { type: "number", min: 0, max: 1, default: 1 },
      sunShafts: { type: "number", min: 0, max: 1, default: 0 },
      pollen: { type: "number", min: 0, max: 1, default: 0 },
      vapor: { type: "number", min: 0, max: 1, default: 0 },
      dust: { type: "number", min: 0, max: 1, default: 0 },
      windStreaks: { type: "number", min: 0, max: 1, default: 0 }
    }
  },
  {
    id: "runtime.effect-recipe",
    label: "标签特效配方",
    priority: "P3",
    repeatable: true,
    availability: "ready",
    params: {
      recipe: {
        type: "enum",
        values: ["glow", "fresnel", "flame", "magic", "aura", "sway"],
        default: "glow"
      },
      intensity: { type: "number", min: 0, max: 2.5, default: 1 },
      speed: { type: "number", min: 0, max: 5, default: 1 },
      color: { type: "color", default: "#88bbff" }
    }
  },
  {
    id: "runtime.shader-extension",
    label: "Shader 扩展",
    priority: "pro",
    developerOnly: true,
    availability: "limited",
    availabilityNote: "基础版 AI 禁止使用；完整 GLSL 仅保存为隔离扩展，不修改核心源码。",
    params: {
      mode: {
        type: "enum",
        values: ["off", "whitelist-fragment", "isolated-glsl"],
        default: "off"
      },
      fragmentId: {
        type: "enum",
        values: ["rim-light", "color-wash", "vertex-sway"],
        default: "rim-light"
      },
      code: { type: "code", maxLength: 12e3, default: "", control: "code" }
    }
  }
];
const CAPABILITY_BY_ID = new Map(RENDER_CAPABILITIES.map((capability) => [capability.id, capability]));
function normalizeRenderPlan(input, allowedBaseIds, accessPolicy, actor = "developer") {
  if (!input || typeof input !== "object") throw new Error("invalid_render_plan");
  const raw = input;
  if (raw.version !== 1 && raw.version !== 2) throw new Error("unsupported_render_plan_version");
  const baseSchemeId = typeof raw.baseSchemeId === "string" ? raw.baseSchemeId.trim() : "";
  if (!baseSchemeId) throw new Error("missing_render_base_scheme");
  if (allowedBaseIds && !allowedBaseIds.includes(baseSchemeId)) throw new Error("unknown_render_scheme");
  if (raw.modules !== void 0 && !Array.isArray(raw.modules)) throw new Error("invalid_render_modules");
  const modules = [];
  const seen = /* @__PURE__ */ new Set();
  for (const item of raw.modules ?? []) {
    if (!item || typeof item !== "object") throw new Error("invalid_render_module");
    const moduleInput = item;
    const rawId = typeof moduleInput.id === "string" ? moduleInput.id : "";
    const capability = CAPABILITY_BY_ID.get(rawId);
    if (!capability) throw new Error(`unknown_render_module:${rawId || "missing"}`);
    if (actor === "ai" && capability.developerOnly) {
      throw new Error(`render_module_forbidden:${capability.id}`);
    }
    const scope = normalizeScope(moduleInput.scope, capability);
    const key = cleanModuleKey(moduleInput.key, capability, scope, modules.length);
    const identity = capability.repeatable && raw.version === 2 ? key : capability.id;
    if (seen.has(identity)) throw new Error(`duplicate_render_module:${identity}`);
    seen.add(identity);
    modules.push({
      ...capability.repeatable && raw.version === 2 ? { key } : {},
      id: capability.id,
      ...scope.target === "scene" ? {} : { scope },
      params: normalizeParams(moduleInput.params, capability, accessPolicy, actor)
    });
  }
  return {
    version: raw.version,
    baseSchemeId,
    modules,
    ...raw.visualDirection === void 0 ? {} : { visualDirection: normalizeVisualDirection(raw.visualDirection) }
  };
}
function compileRenderPlan(plan) {
  const settings = plan.visualDirection ? compileVisualEnvironment(plan.visualDirection) : {};
  for (const module of plan.modules) {
    const params = module.params;
    switch (module.id) {
      case "environment.palette":
        if (typeof params.background === "string") settings.background = params.background;
        if (typeof params.fogColor === "string") settings.fogColor = params.fogColor;
        break;
      case "atmosphere.fog":
        if (typeof params.visibilityDistance === "number") {
          settings.fogDensity = fogDensityForVisibilityDistance(params.visibilityDistance);
        } else if (typeof params.density === "number") settings.fogDensity = params.density;
        break;
      case "lighting.hemisphere":
        if (typeof params.skyColor === "string") settings.hemisphereSkyColor = params.skyColor;
        if (typeof params.groundColor === "string") settings.hemisphereGroundColor = params.groundColor;
        if (typeof params.intensity === "number") settings.hemisphereIntensity = params.intensity;
        break;
      case "lighting.sun":
        if (typeof params.color === "string") settings.sunColor = params.color;
        if (typeof params.intensity === "number") settings.sunIntensity = params.intensity;
        break;
      case "presentation.exposure":
        if (typeof params.value === "number") settings.exposure = params.value;
        break;
    }
  }
  return settings;
}
function fogDensityForVisibilityDistance(distance2) {
  const safeDistance = Math.max(1, Number.isFinite(distance2) ? distance2 : 300);
  return Math.sqrt(-Math.log(0.05)) / safeDistance;
}
function compileRuntimeStyle(plan) {
  const module = plan.modules.find((item) => item.id === "runtime.surface-style");
  const params = module?.params ?? {};
  const cartoon = plan.visualDirection ? { shadowFloor: compileVisualDirection(plan.visualDirection).surfaceShadowFloor } : {};
  for (const key of ["bands", "shadowFloor", "highlightFactor", "rampStrength", "transitionSoftness"]) {
    if (typeof params[key] === "number") cartoon[key] = params[key];
  }
  return {
    mode: params.mode === "cel" ? "cel" : "pbr",
    cartoon
  };
}
function compileRuntimeOutline(plan) {
  const module = plan.modules.find((item) => item.id === "runtime.outline-style");
  const params = module?.params ?? {};
  const compiled = {};
  for (const key of [
    "strength",
    "threshold",
    "width",
    "depthWeight",
    "normalWeight",
    "objectWeight",
    "materialWeight",
    "noiseStrength",
    "strokeVariation",
    "echoCount",
    "echoSpacing",
    "echoAngle",
    "echoStrength",
    "fadeStart",
    "fadeEnd"
  ]) {
    if (typeof params[key] === "number") compiled[key] = params[key];
  }
  if (typeof params.color === "string") compiled.color = params.color;
  if (typeof params.echoColor === "string") compiled.echoColor = params.echoColor;
  const modes = ["none", "clean", "ink", "echo", "curvature"];
  return {
    mode: modes.includes(params.mode) ? params.mode : "none",
    params: compiled
  };
}
function compileRuntimePresentation(plan) {
  const module = plan.modules.find((item) => item.id === "runtime.presentation-style");
  const params = module?.params ?? {};
  const sketch = {};
  for (const key of [
    "worldScale",
    "strength",
    "hatchSpacing",
    "hatchAngle",
    "lineWidth",
    "jitter",
    "toneStrength",
    "toneBias",
    "denseSpacing",
    "darkFill",
    "break"
  ]) {
    if (typeof params[key] === "number") sketch[key] = params[key];
  }
  if (params.coordinateSpace === "world" || params.coordinateSpace === "screen") {
    sketch.coordinateSpace = params.coordinateSpace;
  }
  if (typeof params.lineColor === "string") sketch.lineColor = params.lineColor;
  if (typeof params.paperColor === "string") sketch.paperColor = params.paperColor;
  if (params.colorMode === "color" || params.colorMode === "monochrome") {
    sketch.preserveColor = params.colorMode === "color";
  }
  const paper = {};
  if (typeof params.paperStrength === "number") paper.strength = params.paperStrength;
  if (typeof params.paperScale === "number") paper.scale = params.paperScale;
  if (typeof params.paperTint === "string") paper.tint = params.paperTint;
  const comic = {};
  if (typeof params.halftoneStrength === "number") comic.halftoneStrength = params.halftoneStrength;
  if (typeof params.halftoneCellSize === "number") comic.cellSize = params.halftoneCellSize;
  if (typeof params.printOffset === "number") comic.printOffset = params.printOffset;
  if (typeof params.comicLineBoost === "number") comic.lineBoost = params.comicLineBoost;
  if (typeof params.comicLineWidth === "number") comic.lineWidth = params.comicLineWidth;
  if (typeof params.comicInkColor === "string") comic.inkColor = params.comicInkColor;
  const modes = [
    "none",
    "sketch",
    "comic-clean",
    "comic-print"
  ];
  return {
    mode: modes.includes(params.mode) ? params.mode : "none",
    sketch,
    paper,
    comic
  };
}
function compileRuntimeColorGrade(plan) {
  const params = plan.modules.find((item) => item.id === "runtime.color-grade")?.params ?? {};
  const directed = plan.visualDirection ? compileVisualDirection(plan.visualDirection).colorGrade : void 0;
  return {
    recipe: enumValue(params.recipe, ["neutral", "warm", "cool", "misty", "cinematic", "pastel"], "neutral"),
    temperature: numericValue(params.temperature) ?? directed?.temperature,
    contrast: numericValue(params.contrast) ?? directed?.contrast,
    saturation: numericValue(params.saturation) ?? directed?.saturation,
    shadowLift: numericValue(params.shadowLift) ?? directed?.shadowLift,
    tint: stringValue(params.tint) ?? directed?.tint
  };
}
function compileRuntimeWaterStyles(plan) {
  const directed = plan.visualDirection ? compileVisualWaterPalette(plan.visualDirection) : void 0;
  const modules = plan.modules.filter((item) => item.id === "runtime.water-style");
  if (modules.length === 0 && directed) {
    return [{ scope: { target: "water", tag: "water" }, recipe: "calm-lake", ...directed }];
  }
  return modules.map((item) => ({
    scope: item.scope ?? { target: "water", tag: "water" },
    recipe: enumValue(item.params.recipe, ["calm-lake", "clear-river", "stylized", "stormy"], "calm-lake"),
    opacity: numericValue(item.params.opacity),
    color: stringValue(item.params.color) ?? directed?.color,
    shallowColor: stringValue(item.params.shallowColor) ?? directed?.shallowColor,
    depthColor: stringValue(item.params.depthColor) ?? directed?.depthColor,
    waveStrength: numericValue(item.params.waveStrength),
    waveSpeed: numericValue(item.params.waveSpeed),
    foamStrength: numericValue(item.params.foamStrength),
    reflectionStrength: numericValue(item.params.reflectionStrength),
    environmentReflectionStrength: numericValue(item.params.environmentReflectionStrength),
    environmentReflectionExposure: numericValue(item.params.environmentReflectionExposure),
    reflectionDistortion: numericValue(item.params.reflectionDistortion),
    reflectionFresnel: numericValue(item.params.reflectionFresnel)
  }));
}
function compileRuntimeGrassStyle(plan) {
  const params = plan.modules.find((item) => item.id === "runtime.grass-style")?.params ?? {};
  const angle = (numericValue(params.windAngle) ?? 14) * Math.PI / 180;
  return {
    ...DEFAULT_RUNTIME_GRASS_STYLE,
    rootColor: stringValue(params.rootColor) ?? DEFAULT_RUNTIME_GRASS_STYLE.rootColor,
    tipColor: stringValue(params.tipColor) ?? DEFAULT_RUNTIME_GRASS_STYLE.tipColor,
    paletteVariation: numericValue(params.paletteVariation) ?? DEFAULT_RUNTIME_GRASS_STYLE.paletteVariation,
    bands: params.bands === "2" ? 2 : 3,
    bladeHeight: numericValue(params.bladeHeight) ?? DEFAULT_RUNTIME_GRASS_STYLE.bladeHeight,
    bladeWidth: numericValue(params.bladeWidth) ?? DEFAULT_RUNTIME_GRASS_STYLE.bladeWidth,
    windStrength: numericValue(params.windStrength) ?? DEFAULT_RUNTIME_GRASS_STYLE.windStrength,
    windDirection: [Math.cos(angle), Math.sin(angle)],
    normalFlatten: numericValue(params.normalFlatten) ?? DEFAULT_RUNTIME_GRASS_STYLE.normalFlatten,
    rootDarken: numericValue(params.rootDarken) ?? DEFAULT_RUNTIME_GRASS_STYLE.rootDarken,
    gradientBias: numericValue(params.gradientBias) ?? DEFAULT_RUNTIME_GRASS_STYLE.gradientBias,
    cellSize: numericValue(params.cellSize) ?? DEFAULT_RUNTIME_GRASS_STYLE.cellSize,
    fadeStart: numericValue(params.fadeStart) ?? DEFAULT_RUNTIME_GRASS_STYLE.fadeStart,
    fadeEnd: numericValue(params.fadeEnd) ?? DEFAULT_RUNTIME_GRASS_STYLE.fadeEnd,
    maxInstances: numericValue(params.maxInstances) ?? DEFAULT_RUNTIME_GRASS_STYLE.maxInstances,
    groundTint: params.groundTint !== "off",
    groundColor: stringValue(params.groundColor) ?? DEFAULT_RUNTIME_GRASS_STYLE.groundColor,
    groundTintStrength: numericValue(params.groundTintStrength) ?? DEFAULT_RUNTIME_GRASS_STYLE.groundTintStrength
  };
}
function compileRuntimeMaterialThemes(plan) {
  return plan.modules.filter((item) => item.id === "runtime.material-theme").map((item, index) => {
    const scope = item.scope ?? { target: "material-tag", tag: "base" };
    const directed = plan.visualDirection ? visualMaterialTint(plan.visualDirection, scope.tag) : void 0;
    return {
      key: item.key ?? `material-theme-${index}`,
      scope,
      recipe: enumValue(item.params.recipe, ["natural", "autumn", "winter", "weathered", "polished", "pastel"], "natural"),
      strength: numericValue(item.params.strength) ?? directed?.strength,
      color: stringValue(item.params.color) ?? directed?.color,
      roughness: numericValue(item.params.roughness),
      metalness: numericValue(item.params.metalness)
    };
  });
}
function compileRuntimeLightRig(plan) {
  const params = plan.modules.find((item) => item.id === "runtime.light-rig")?.params ?? {};
  const directed = plan.visualDirection ? compileVisualDirection(plan.visualDirection).lightRig : void 0;
  return {
    recipe: enumValue(params.recipe, ["neutral", "soft-morning", "hard-day", "backlit", "overcast", "sunset"], directed?.recipe ?? "neutral"),
    strength: numericValue(params.strength) ?? directed?.strength,
    warmth: numericValue(params.warmth) ?? directed?.warmth,
    shadowSoftness: numericValue(params.shadowSoftness) ?? directed?.shadowSoftness
  };
}
function compileRuntimePostQuality(plan) {
  const params = plan.modules.find((item) => item.id === "runtime.post-quality")?.params ?? {};
  return {
    bloom: enumValue(params.bloom, ["off", "soft", "strong"], "off"),
    bloomStrength: numericValue(params.bloomStrength),
    ssao: enumValue(params.ssao, ["off", "soft", "strong"], "off"),
    depthOfField: enumValue(params.depthOfField, ["off", "soft", "portrait"], "off")
  };
}
function compileRuntimeEffectRecipes(plan) {
  return plan.modules.filter((item) => item.id === "runtime.effect-recipe").map((item, index) => ({
    key: item.key ?? `effect-recipe-${index}`,
    scope: item.scope ?? { target: "material-tag", tag: "emissive" },
    recipe: enumValue(item.params.recipe, ["glow", "fresnel", "flame", "magic", "aura", "sway"], "glow"),
    intensity: numericValue(item.params.intensity),
    speed: numericValue(item.params.speed),
    color: stringValue(item.params.color)
  }));
}
function compileRuntimeHdriSky(plan) {
  const params = plan.modules.find((item) => item.id === "environment.hdri")?.params ?? {};
  return {
    texture: stringValue(params.texture)?.trim() ?? "",
    rotation: numericValue(params.rotation) ?? 0,
    exposure: numericValue(params.exposure) ?? 1,
    saturation: numericValue(params.saturation) ?? 1,
    intensity: numericValue(params.intensity) ?? 1,
    tint: stringValue(params.tint),
    tintStrength: numericValue(params.tintStrength) ?? 0,
    useAsEnvironment: params.useAsEnvironment !== "off"
  };
}
function compileRuntimeShaderExtension(plan) {
  const params = plan.modules.find((item) => item.id === "runtime.shader-extension")?.params ?? {};
  return {
    mode: enumValue(params.mode, ["off", "whitelist-fragment", "isolated-glsl"], "off"),
    fragmentId: stringValue(params.fragmentId),
    code: stringValue(params.code)
  };
}
function createDefaultRenderAccessPolicy() {
  return {
    version: 1,
    parameters: RENDER_CAPABILITIES.flatMap((capability) => Object.entries(capability.params).map(([parameter, rule]) => {
      const control = rule.control ?? (rule.type === "number" ? "range" : rule.type === "enum" ? "select" : rule.type === "color" ? "color" : "code");
      const range = {
        enabled: !capability.developerOnly && !(capability.id === "runtime.post-quality" && parameter === "depthOfField") && !(capability.id === "runtime.outline-style" && ["fadeStart", "fadeEnd"].includes(parameter)) && !(capability.id === "runtime.grass-style" && [
          "normalFlatten",
          "rootDarken",
          "gradientBias",
          "cellSize",
          "fadeStart",
          "fadeEnd",
          "maxInstances"
        ].includes(parameter)),
        ...rule.type === "number" ? { min: rule.min, max: rule.max } : {},
        ...rule.type === "enum" ? { values: [...rule.values] } : {}
      };
      return {
        moduleId: capability.id,
        parameter,
        control,
        ai: { ...range },
        developer: {
          ...range,
          enabled: true
        }
      };
    }))
  };
}
function normalizeRenderAccessPolicy(input) {
  const defaults = createDefaultRenderAccessPolicy();
  if (!input || typeof input !== "object") return defaults;
  const raw = input;
  if (raw.version !== 1 || !Array.isArray(raw.parameters)) return defaults;
  const provided = /* @__PURE__ */ new Map();
  for (const item of raw.parameters) {
    if (!item || typeof item !== "object") continue;
    const entry = item;
    if (typeof entry.moduleId !== "string" || typeof entry.parameter !== "string") continue;
    provided.set(`${entry.moduleId}:${entry.parameter}`, entry);
  }
  return {
    version: 1,
    parameters: defaults.parameters.map((fallback) => {
      const entry = provided.get(`${fallback.moduleId}:${fallback.parameter}`);
      if (!entry) return fallback;
      const controls = ["range", "number", "select", "color", "toggle", "code"];
      return {
        ...fallback,
        control: controls.includes(entry.control) ? entry.control : fallback.control,
        ai: normalizeAccessRange(entry.ai, fallback.ai),
        developer: normalizeAccessRange(entry.developer, fallback.developer)
      };
    })
  };
}
function renderCapabilitySummary() {
  return RENDER_CAPABILITIES.map((capability) => ({
    id: capability.id,
    label: capability.label,
    priority: capability.priority,
    repeatable: capability.repeatable === true,
    developerOnly: capability.developerOnly === true,
    availability: capability.availability ?? "ready",
    availabilityNote: capability.availabilityNote,
    params: capability.params
  }));
}
function renderModuleLabel(id) {
  return CAPABILITY_BY_ID.get(id)?.label ?? id;
}
function normalizeParams(value, capability, accessPolicy, actor = "developer") {
  if (value === void 0) return {};
  if (!value || typeof value !== "object") throw new Error(`invalid_render_params:${capability.id}`);
  const input = value;
  const output = {};
  for (const key of Object.keys(input)) {
    const rule = capability.params[key];
    if (!rule) throw new Error(`unknown_render_parameter:${capability.id}.${key}`);
    const access = accessPolicy?.parameters.find((entry) => entry.moduleId === capability.id && entry.parameter === key)?.[actor];
    if (access && !access.enabled) {
      throw new Error(`render_parameter_forbidden:${capability.id}.${key}`);
    }
    if (rule.type === "color") {
      if (typeof input[key] !== "string" || !/^#[0-9a-f]{6}$/i.test(input[key])) {
        throw new Error(`invalid_render_color:${capability.id}.${key}`);
      }
      output[key] = input[key];
      continue;
    }
    if (rule.type === "enum") {
      const allowedValues = access?.values?.length ? rule.values.filter((item) => access.values?.includes(item)) : rule.values;
      if (typeof input[key] !== "string" || !allowedValues.includes(input[key])) {
        throw new Error(`invalid_render_enum:${capability.id}.${key}`);
      }
      output[key] = input[key];
      continue;
    }
    if (rule.type === "code") {
      const candidate = input[key];
      const isApprovedAiLibraryValue = actor === "ai" && typeof candidate === "string" && (access?.values ?? []).includes(candidate);
      if (actor !== "developer" && !isApprovedAiLibraryValue || typeof candidate !== "string") {
        throw new Error(`invalid_render_code:${capability.id}.${key}`);
      }
      output[key] = candidate.slice(0, rule.maxLength);
      continue;
    }
    const number = Number(input[key]);
    if (!Number.isFinite(number)) throw new Error(`invalid_render_number:${capability.id}.${key}`);
    const min = Math.max(rule.min, access?.min ?? rule.min);
    const max = Math.min(rule.max, access?.max ?? rule.max);
    output[key] = Math.min(max, Math.max(min, number));
  }
  return output;
}
function normalizeScope(value, capability) {
  const fallback = capability.id === "runtime.water-style" ? { target: "water", tag: "water" } : capability.repeatable ? { target: "material-tag", tag: capability.id === "runtime.effect-recipe" ? "emissive" : "base" } : { target: "scene" };
  if (!value || typeof value !== "object") return fallback;
  const raw = value;
  const targets = ["scene", "water", "material-tag", "asset-tag"];
  const target = targets.includes(raw.target) ? raw.target : fallback.target;
  const tag = typeof raw.tag === "string" ? raw.tag.trim().toLowerCase().replace(/[^a-z0-9_-]/g, "").slice(0, 48) : fallback.tag;
  if ((target === "material-tag" || target === "asset-tag") && !tag) {
    throw new Error(`missing_render_scope_tag:${capability.id}`);
  }
  return { target, ...tag ? { tag } : {} };
}
function cleanModuleKey(value, capability, scope, index) {
  const raw = typeof value === "string" ? value.trim() : "";
  const clean = raw.replace(/[^a-zA-Z0-9_-]/g, "").slice(0, 64);
  return clean || `${capability.id.replaceAll(".", "-")}-${scope.tag ?? scope.target}-${index}`;
}
function normalizeAccessRange(value, fallback) {
  if (!value || typeof value !== "object") return { ...fallback };
  const raw = value;
  const min = numericValue(raw.min);
  const max = numericValue(raw.max);
  const fallbackValues = fallback.values ?? [];
  const values = Array.isArray(raw.values) ? raw.values.filter((item) => typeof item === "string" && fallbackValues.includes(item)) : fallback.values;
  const nextMin = min === void 0 ? fallback.min : Math.max(fallback.min ?? min, min);
  const nextMax = max === void 0 ? fallback.max : Math.min(fallback.max ?? max, max);
  return {
    enabled: typeof raw.enabled === "boolean" ? raw.enabled : fallback.enabled,
    ...nextMin === void 0 ? {} : { min: nextMin },
    ...nextMax === void 0 ? {} : { max: Math.max(nextMin ?? nextMax, nextMax) },
    ...values === void 0 ? {} : { values: [...values] }
  };
}
function numericValue(value) {
  const number = Number(value);
  return Number.isFinite(number) ? number : void 0;
}
function stringValue(value) {
  return typeof value === "string" ? value : void 0;
}
function enumValue(value, values, fallback) {
  return typeof value === "string" && values.includes(value) ? value : fallback;
}
const BUILTIN_RENDER_SCHEMES = [
  builtinScheme("render-natural-day", "自然日光", "清晰、中性的日间光照，适合继续编辑地图。", {
    background: "#9cc7d5",
    fogColor: "#9cc7d5",
    fogDensity: 4e-3,
    hemisphereSkyColor: "#eaf6ff",
    hemisphereGroundColor: "#30382f",
    hemisphereIntensity: 1.6,
    sunColor: "#fff0ce",
    sunIntensity: 2.5,
    exposure: 1
  }),
  builtinScheme("render-morning-mist", "薄雾晨光", "低对比度的冷色晨雾，适合田园和森林场景。", {
    background: "#a8bec0",
    fogColor: "#b9c9c5",
    fogDensity: 0.018,
    hemisphereSkyColor: "#dceff1",
    hemisphereGroundColor: "#3b4740",
    hemisphereIntensity: 1.35,
    sunColor: "#ffe1ad",
    sunIntensity: 1.7,
    exposure: 0.94
  }),
  builtinScheme("render-golden-hour", "金色黄昏", "暖色主光和轻微雾化，突出轮廓与空间层次。", {
    background: "#8e6f69",
    fogColor: "#b58a71",
    fogDensity: 0.011,
    hemisphereSkyColor: "#d5a47f",
    hemisphereGroundColor: "#352f32",
    hemisphereIntensity: 1.15,
    sunColor: "#ffb45c",
    sunIntensity: 3.1,
    exposure: 1.08
  }),
  builtinScheme("render-moonlit-night", "月夜", "冷色低照度环境，用于夜景氛围预览。", {
    background: "#101a2d",
    fogColor: "#18243a",
    fogDensity: 9e-3,
    hemisphereSkyColor: "#728bb8",
    hemisphereGroundColor: "#101521",
    hemisphereIntensity: 0.72,
    sunColor: "#b9d2ff",
    sunIntensity: 1.25,
    exposure: 0.78
  }),
  builtinScheme("render-runtime-cel-day", "卡通日光", "使用 Voxel Render Runtime 的色阶卡通明暗，适合低多边形场景。", {
    background: "#a9d3df",
    fogColor: "#b8d6d9",
    fogDensity: 6e-3,
    hemisphereSkyColor: "#edf9ff",
    hemisphereGroundColor: "#39483b",
    hemisphereIntensity: 1.55,
    sunColor: "#fff0c7",
    sunIntensity: 2.7,
    exposure: 1
  }, {
    version: 1,
    baseSchemeId: "render-runtime-cel-day",
    modules: [{
      id: "runtime.surface-style",
      params: {
        mode: "cel",
        bands: 4,
        shadowFloor: 0.34,
        highlightFactor: 1.05,
        rampStrength: 0.88,
        transitionSoftness: 0.16
      }
    }]
  }),
  builtinScheme("render-runtime-sketch-mist", "淡彩素描晨雾", "程序化交叉排线与柔和晨雾，保留少量原始色彩。", {
    background: "#c9d2cf",
    fogColor: "#d7ddd8",
    fogDensity: 0.019,
    hemisphereSkyColor: "#e8efec",
    hemisphereGroundColor: "#555b55",
    hemisphereIntensity: 1.2,
    sunColor: "#f5e8cf",
    sunIntensity: 1.55,
    exposure: 0.93
  }, {
    version: 1,
    baseSchemeId: "render-runtime-sketch-mist",
    modules: [
      {
        id: "runtime.outline-style",
        params: {
          mode: "ink",
          strength: 0.9,
          width: 1.35,
          color: "#34363d",
          noiseStrength: 0.16,
          strokeVariation: 0.45
        }
      },
      {
        id: "runtime.presentation-style",
        params: {
          mode: "sketch",
          coordinateSpace: "world",
          worldScale: 3.5,
          strength: 0.72,
          hatchSpacing: 7,
          hatchAngle: 35,
          lineWidth: 0.16,
          jitter: 0.18,
          colorMode: "color",
          toneStrength: 0.5,
          darkFill: 0.4,
          break: 0.1,
          lineColor: "#34363d",
          paperColor: "#f4f0e6",
          paperStrength: 0.12,
          paperScale: 2,
          paperTint: "#f4f0e6"
        }
      }
    ]
  }),
  builtinScheme("render-runtime-comic-clean", "清线漫画", "干净的共享轮廓与克制的漫画印刷处理，保留原有色彩层次。", {
    background: "#a9d3df",
    fogColor: "#b8d6d9",
    fogDensity: 6e-3,
    hemisphereSkyColor: "#edf9ff",
    hemisphereGroundColor: "#39483b",
    hemisphereIntensity: 1.55,
    sunColor: "#fff0c7",
    sunIntensity: 2.7,
    exposure: 1
  }, {
    version: 1,
    baseSchemeId: "render-runtime-comic-clean",
    modules: [
      {
        id: "runtime.surface-style",
        params: { mode: "cel", bands: 4, rampStrength: 0.82, transitionSoftness: 0.16 }
      },
      {
        id: "runtime.outline-style",
        params: { mode: "clean", strength: 1, width: 1.25, color: "#171824" }
      },
      {
        id: "runtime.presentation-style",
        params: { mode: "comic-clean" }
      }
    ]
  }),
  builtinScheme("render-runtime-comic-print", "套色漫画", "共享轮廓、克制网点和轻微套印偏移组成的印刷漫画效果。", {
    background: "#d5d0c2",
    fogColor: "#d5d0c2",
    fogDensity: 4e-3,
    hemisphereSkyColor: "#fff5df",
    hemisphereGroundColor: "#4a443c",
    hemisphereIntensity: 1.45,
    sunColor: "#ffe2a3",
    sunIntensity: 2.6,
    exposure: 0.98
  }, {
    version: 1,
    baseSchemeId: "render-runtime-comic-print",
    modules: [
      {
        id: "runtime.surface-style",
        params: { mode: "cel", bands: 4, rampStrength: 0.84, transitionSoftness: 0.14 }
      },
      {
        id: "runtime.outline-style",
        params: { mode: "clean", strength: 1, width: 1.25, color: "#17131c" }
      },
      {
        id: "runtime.presentation-style",
        params: { mode: "comic-print" }
      }
    ]
  })
];
function createRenderScheme(input) {
  const now = Date.now();
  return normalizeRenderScheme({
    ...input,
    id: createId("render"),
    kind: "custom",
    createdAt: now,
    updatedAt: now
  });
}
function normalizeRenderScheme(input) {
  const fallback = BUILTIN_RENDER_SCHEMES[0]?.settings ?? defaultSettings();
  const now = Date.now();
  const accessPolicy = normalizeRenderAccessPolicy(input.accessPolicy);
  return {
    id: cleanText(input.id, createId("render"), 80),
    name: cleanText(input.name, "未命名渲染方案", 48),
    description: cleanText(input.description, "", 160),
    sourcePrompt: cleanText(input.sourcePrompt, "", 1e3),
    styleTags: normalizeStyleTags(input.styleTags),
    provider: cleanText(input.provider, "", 40) || void 0,
    renderPlan: safeRenderPlan(input.renderPlan),
    accessPolicy,
    schemaVersion: 1,
    kind: input.kind === "builtin" ? "builtin" : "custom",
    settings: normalizeSettings(input.settings, fallback),
    createdAt: finiteNumber(input.createdAt, now),
    updatedAt: finiteNumber(input.updatedAt, now)
  };
}
function safeRenderPlan(value) {
  if (value === void 0) return void 0;
  try {
    return normalizeRenderPlan(value);
  } catch {
    return void 0;
  }
}
function builtinScheme(id, name, description, settings, renderPlan) {
  return {
    id,
    name,
    description,
    sourcePrompt: "",
    styleTags: [],
    renderPlan,
    accessPolicy: createDefaultRenderAccessPolicy(),
    schemaVersion: 1,
    kind: "builtin",
    settings,
    createdAt: 0,
    updatedAt: 0
  };
}
function normalizeSettings(input, fallback) {
  return {
    background: color(input?.background, fallback.background),
    fogColor: color(input?.fogColor, fallback.fogColor),
    fogDensity: clamp(finiteNumber(input?.fogDensity, fallback.fogDensity), 0, 0.08),
    hemisphereSkyColor: color(input?.hemisphereSkyColor, fallback.hemisphereSkyColor),
    hemisphereGroundColor: color(input?.hemisphereGroundColor, fallback.hemisphereGroundColor),
    hemisphereIntensity: clamp(finiteNumber(input?.hemisphereIntensity, fallback.hemisphereIntensity), 0, 8),
    sunColor: color(input?.sunColor, fallback.sunColor),
    sunIntensity: clamp(finiteNumber(input?.sunIntensity, fallback.sunIntensity), 0, 12),
    exposure: clamp(finiteNumber(input?.exposure, fallback.exposure), 0.2, 3)
  };
}
function defaultSettings() {
  return {
    background: "#9cc7d5",
    fogColor: "#9cc7d5",
    fogDensity: 4e-3,
    hemisphereSkyColor: "#eaf6ff",
    hemisphereGroundColor: "#30382f",
    hemisphereIntensity: 1.6,
    sunColor: "#fff0ce",
    sunIntensity: 2.5,
    exposure: 1
  };
}
function color(value, fallback) {
  return typeof value === "string" && /^#[0-9a-f]{6}$/i.test(value) ? value : fallback;
}
function cleanText(value, fallback, maxLength) {
  return typeof value === "string" && value.trim() ? value.trim().slice(0, maxLength) : fallback;
}
function normalizeStyleTags(value) {
  if (!Array.isArray(value)) return [];
  return [...new Set(value.filter((tag) => typeof tag === "string").map((tag) => tag.trim().slice(0, 24)).filter(Boolean))].slice(0, 8);
}
function finiteNumber(value, fallback) {
  const numberValue2 = Number(value);
  return Number.isFinite(numberValue2) ? numberValue2 : fallback;
}
function clamp(value, min, max) {
  return Math.min(max, Math.max(min, value));
}
export {
  BUILTIN_RENDER_SCHEMES,
  DEFAULT_DISABLED_MATERIAL_TAGS,
  DEFAULT_GRASS_MIX,
  DEFAULT_RUNTIME_GRASS_STYLE,
  DEFAULT_SUN_POSITION,
  DEFAULT_TERRAIN_RESOLUTION,
  DEFAULT_WATER_DEPTH,
  HDRI_CATALOG_FILE,
  HDRI_EXTENSIONS,
  MAP_ASSET_COLLIDER_PROFILE,
  MAP_SIZE_PRESETS,
  MAX_GRASS_LAYERS,
  MAX_WATER_DEPTH,
  PLAYER_HEIGHT,
  PLAYER_MODEL_COLLIDER_PROFILE,
  PLAYER_RADIUS,
  PLAYER_SPAWN_OBJECT_ID,
  RENDER_CAPABILITIES,
  SUN_OBJECT_ID,
  TERRAIN_GENERATION_PRESETS,
  TERRAIN_MIN_HEIGHT,
  addPaintStroke,
  applyGrassBrushInPlace,
  applyTerrainBrush,
  applyTerrainBrushInPlace,
  assetFootprintRadius,
  assetSizeClass,
  bakeCollisionBoxes,
  bakeMapCollisions,
  buildModelColliderPlan,
  calculateModelHitBounds,
  carveWaterBasinInPlace,
  combinedGrassDensity,
  compileRenderPlan,
  compileRuntimeColorGrade,
  compileRuntimeEffectRecipes,
  compileRuntimeGrassStyle,
  compileRuntimeHdriSky,
  compileRuntimeLightRig,
  compileRuntimeMaterialThemes,
  compileRuntimeOutline,
  compileRuntimePostQuality,
  compileRuntimePresentation,
  compileRuntimeShaderExtension,
  compileRuntimeStyle,
  compileRuntimeWaterStyles,
  createDefaultRenderAccessPolicy,
  createEmptyMap,
  createGrassLayer,
  createId,
  createMapObject,
  createPaintStroke,
  createRenderScheme,
  fillGrassLayerInPlace,
  filterMaterialTags,
  findSafeSpawnPosition,
  firstMapRayHitDistance,
  fogDensityForVisibilityDistance,
  generateGrassRegionInPlace,
  generateTerrainInPlace,
  getMapBounds,
  getMapCollisionBake,
  getMapObjectAabbs,
  getObjectWorldTransforms,
  getPlayerSpawnYaw,
  getPlayerSupportHeightForMap,
  getSpawnPoints,
  getSunPosition,
  hdriExtensionOf,
  isLineBlockedByMap,
  isMaterialTagEnabled,
  isNearWater,
  isPointInsideWaterBody,
  isSpawnPositionSafe,
  mapToSummary,
  materialTagSelector,
  modelColliderBoundingVolume,
  modelColliderVisibilityPoints,
  modelColliderWorldAabbs,
  modelScaleForVolume,
  modelVolumeAtScale,
  movePlayerPositionForMap,
  normalizeAssetTags,
  normalizeGrassLayers,
  normalizeGrassMix,
  normalizeMap,
  normalizeMaterialTagPolicy,
  normalizeModelColliderPlan,
  normalizeRenderAccessPolicy,
  normalizeRenderPlan,
  normalizeRenderScheme,
  normalizeTerrainGenerationParams,
  parseHdriCatalog,
  rayModelHitboxIntersection,
  renderCapabilitySummary,
  renderModuleLabel,
  resolvePlayerPositionForMap,
  sampleGrassDensity,
  sampleTerrainHeight,
  spectatorPositionForMap,
  stepPlayerVerticalMotionForMap,
  surfaceUvFromPoint,
  terrainIndex,
  terrainPointAt,
  terrainResolutionForSize,
  updateGrassLayer,
  math as vectorMath
};
