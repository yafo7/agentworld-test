export interface MapMaterialTagPolicy {
    /** Canonical selectors such as `base:fur`, `base:wood`, or `vegetation`. */
    disabled: string[];
}
export declare const DEFAULT_DISABLED_MATERIAL_TAGS: readonly ["base:fur"];
export declare function normalizeMaterialTagPolicy(value: unknown): MapMaterialTagPolicy;
export declare function materialTagSelector(value: unknown): string | null;
export declare function isMaterialTagEnabled(value: unknown, policy: MapMaterialTagPolicy): boolean;
export declare function filterMaterialTags(tags: unknown, policy: MapMaterialTagPolicy): unknown[];
