export declare function seedFromString(value: string): number;
