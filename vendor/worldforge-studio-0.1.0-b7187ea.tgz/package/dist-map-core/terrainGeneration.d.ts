import { type EditableMap } from './map';
export declare const TERRAIN_GENERATION_PRESETS: readonly ["plain", "hills", "valley", "island", "canyon"];
export type TerrainGenerationPreset = typeof TERRAIN_GENERATION_PRESETS[number];
export interface TerrainGenerationParams {
    preset: TerrainGenerationPreset;
    seed: number;
    amplitude: number;
    roughness: number;
}
export declare function normalizeTerrainGenerationParams(value: unknown, map: EditableMap): TerrainGenerationParams;
export declare function generateTerrainInPlace(map: EditableMap, value: unknown): TerrainGenerationParams;
