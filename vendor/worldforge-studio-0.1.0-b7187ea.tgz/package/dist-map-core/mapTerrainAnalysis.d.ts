import { type EditableMap } from './map';
export declare function terrainSlopeDegrees(map: EditableMap, x: number, z: number): number;
