import { type EditableMap } from './map';
export declare function isSpawnPositionSafe(map: EditableMap, x: number, z: number): boolean;
export declare function findSafeSpawnPosition(map: EditableMap, requestedX: number, requestedZ: number): [number, number];
