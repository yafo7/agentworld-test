/** Panorama formats the packaged runtime loader accepts. */
export declare const HDRI_EXTENSIONS: readonly ["hdr", "exr", "jpg", "jpeg", "png"];
export declare const HDRI_CATALOG_FILE = "catalog.json";
export type HdriExtension = typeof HDRI_EXTENSIONS[number];
export interface HdriTexture {
    /** Filename without extension. Stable id a render scheme refers to. */
    id: string;
    /** Filename as it sits on disk, used to build the download URL. */
    file: string;
    extension: HdriExtension;
    bytes: number;
    /** Curated mood labels that let the AI choose without guessing from filenames. */
    tags: string[];
    /** Average sky-facing colour, used to harmonize hemisphere light. */
    skyColor?: string;
    /** Average lower-panorama colour, used to harmonize fog and ground light. */
    groundColor?: string;
}
export interface HdriCatalogEntry {
    file: string;
    tags?: string[];
    skyColor?: string;
    groundColor?: string;
}
export declare function parseHdriCatalog(value: unknown): Map<string, Required<Pick<HdriCatalogEntry, 'tags'>> & Omit<HdriCatalogEntry, 'tags'>>;
export declare function hdriExtensionOf(file: string): HdriExtension | null;
