import { type InputState, type Vec3 } from './protocol';
export declare const MAX_PITCH: number;
export declare function clamp(value: number, min: number, max: number): number;
export declare function wrapAngle(angle: number): number;
export declare function clampPitch(pitch: number): number;
export declare function add(a: Vec3, b: Vec3): Vec3;
export declare function sub(a: Vec3, b: Vec3): Vec3;
export declare function dot(a: Vec3, b: Vec3): number;
export declare function length(v: Vec3): number;
export declare function normalize(v: Vec3): Vec3;
export declare function scale(v: Vec3, amount: number): Vec3;
export declare function distance(a: Vec3, b: Vec3): number;
export declare function forwardFromYawPitch(yaw: number, pitch?: number): Vec3;
export declare function planarForwardFromYaw(yaw: number): Vec3;
export declare function rightFromYaw(yaw: number): Vec3;
export declare function movementDelta(input: InputState, dt: number, spectating?: boolean): Vec3;
export interface VerticalMotionState {
    y: number;
    velocity: number;
    grounded: boolean;
}
export declare function stepVerticalMotion(currentY: number, groundY: number, velocity: number, dt: number, jumpRequested: boolean): VerticalMotionState;
export declare function raySphereIntersection(origin: Vec3, direction: Vec3, center: Vec3, radius: number): number | null;
export declare function rayAabbIntersection(origin: Vec3, direction: Vec3, min: Vec3, max: Vec3): number | null;
export declare function isTargetInView(origin: Vec3, yaw: number, pitch: number, target: Vec3, fovDegrees?: number, maxDistance?: number): boolean;
