import type { EditableMap } from './map';
export type GrassBrushMode = 'add' | 'erase' | 'density' | 'smooth';
export interface GrassVariantMix {
    short: number;
    tall: number;
    flowers: number;
}
export interface MapGrassLayer {
    id: string;
    name: string;
    visible: boolean;
    seed: number;
    resolutionX: number;
    resolutionZ: number;
    densities: number[];
    mix: GrassVariantMix;
}
export type GrassRegion = {
    kind: 'circle';
    center: [number, number];
    radius: number;
} | {
    kind: 'polygon';
    points: Array<[number, number]>;
};
export interface GrassLayerInput {
    id?: string;
    name?: string;
    visible?: boolean;
    seed?: number;
    densities?: number[];
    mix?: Partial<GrassVariantMix>;
}
export type GrassLayerPatch = Pick<GrassLayerInput, 'name' | 'visible' | 'seed' | 'mix'>;
export declare const MAX_GRASS_LAYERS = 8;
export declare const DEFAULT_GRASS_MIX: GrassVariantMix;
export declare function normalizeGrassLayers(value: unknown, resolutionX: number, resolutionZ: number): MapGrassLayer[];
export declare function createGrassLayer(input: GrassLayerInput, resolutionX: number, resolutionZ: number, fallbackSeed?: number): MapGrassLayer;
export declare function updateGrassLayer(layer: MapGrassLayer, patch: GrassLayerPatch): MapGrassLayer;
export declare function fillGrassLayerInPlace(map: EditableMap, layerId: string, density: number): void;
export declare function applyGrassBrushInPlace(map: EditableMap, layerId: string, mode: GrassBrushMode, point: [number, number], size?: number, strength?: number, targetDensity?: number): void;
export declare function generateGrassRegionInPlace(map: EditableMap, layerId: string, region: GrassRegion, density?: number, variation?: number, softness?: number, seed?: number): void;
export declare function sampleGrassDensity(layer: MapGrassLayer, map: Pick<EditableMap, 'box'>, x: number, z: number): number;
export declare function combinedGrassDensity(map: Pick<EditableMap, 'box' | 'grassLayers'>, x: number, z: number): number;
export declare function normalizeGrassMix(value: Partial<GrassVariantMix> | undefined): GrassVariantMix;
