import type { RenderEnvironmentSettings } from './renderScheme';
import { type VisualDirection } from './visualDirection';
export interface VisualWaterPalette {
    color: string;
    shallowColor: string;
    depthColor: string;
}
export declare function compileVisualEnvironment(direction: VisualDirection): Partial<RenderEnvironmentSettings>;
export declare function compileVisualWaterPalette(direction: VisualDirection): VisualWaterPalette;
/** A deliberately weak tint: tagged source materials remain the primary art direction. */
export declare function visualMaterialTint(direction: VisualDirection, tag?: string): {
    color: string;
    strength: number;
};
export declare function mixHexColors(base: string, tint: string, amount: number): string;
