import type * as THREE from 'three';
import { createMapHost } from './mapHost';
import { RenderSceneRuntime } from './renderSceneRuntime';
import type { EditableMap } from '../shared/map';
import type { RenderScheme } from '../shared/renderScheme';

export type { RenderSceneRuntime } from './renderSceneRuntime';

export interface MapViewerOptions {
  /** Canvas to draw into. Leave unset to let three.js create one. */
  canvas?: HTMLCanvasElement;
  map: EditableMap;
  /** `null` renders the map in the neutral editor look, with no styling. */
  scheme?: RenderScheme | null;
  /**
   * Resolves an HDRI file name from the render plan to a fetchable URL.
   * Defaults to `hdri/<file>` relative to the page.
   */
  hdriUrl?: (file: string) => string;
  pixelRatio?: number;
  /** Drive frames from your own game loop instead of `requestAnimationFrame`. */
  autoStart?: boolean;
}

export interface MapViewer {
  readonly scene: THREE.Scene;
  readonly camera: THREE.PerspectiveCamera;
  readonly renderer: THREE.WebGLRenderer;
  /** Escape hatch: lights, shadow runtime and post-process adapter. */
  readonly runtime: RenderSceneRuntime;
  setMap(map: EditableMap): Promise<void>;
  setRenderScheme(scheme: RenderScheme | null): void;
  setSize(width: number, height: number): void;
  /** One frame. Call this yourself when `autoStart` is false. */
  tick(deltaTime: number): void;
  start(): void;
  stop(): void;
  dispose(): void;
}

/**
 * Renders a WorldForge map with the exact look the editor shows.
 *
 * ```ts
 * const viewer = await createMapViewer({ canvas, map, scheme });
 * viewer.camera.position.set(20, 14, 20);
 * ```
 *
 * The map's assets travel inside `map.assets[].modelJson`, so nothing else has
 * to be fetched — except the HDRI panorama a render plan may name, which is
 * what `hdriUrl` is for.
 */
export async function createMapViewer(options: MapViewerOptions): Promise<MapViewer> {
  const host = await createMapHost({
    canvas: options.canvas,
    map: options.map,
    scheme: options.scheme,
    hdriUrl: options.hdriUrl ?? ((file) => `hdri/${encodeURIComponent(file)}`),
    pixelRatio: options.pixelRatio
  });
  const runtime = host.runtime;
  let frame = 0;
  let lastFrameAt = 0;

  const tick = (deltaTime: number): void => {
    host.tick(deltaTime);
  };

  const loop = (): void => {
    frame = requestAnimationFrame(loop);
    const now = performance.now();
    // Clamp so a backgrounded tab does not resume with a multi-second step.
    const deltaTime = Math.min(0.05, Math.max(0, now - lastFrameAt) / 1000);
    lastFrameAt = now;
    tick(deltaTime);
  };

  const start = (): void => {
    if (frame) return;
    lastFrameAt = performance.now();
    frame = requestAnimationFrame(loop);
  };

  const stop = (): void => {
    if (!frame) return;
    cancelAnimationFrame(frame);
    frame = 0;
  };

  if (options.canvas) {
    runtime.setSize(options.canvas.clientWidth || 1, options.canvas.clientHeight || 1);
  }
  if (options.autoStart !== false) start();

  return {
    scene: runtime.scene,
    camera: runtime.camera,
    renderer: runtime.renderer,
    runtime,
    setMap: host.setMap,
    setRenderScheme: host.setRenderScheme,
    setSize: (width, height) => runtime.setSize(width, height),
    tick,
    start,
    stop,
    dispose: () => {
      stop();
      host.dispose();
    }
  };
}
