import * as THREE from 'three';
import { buildEditableMapGroup, type RenderedMap } from './mapRenderer';
import { RenderSceneRuntime, type RenderSceneRuntimeOptions } from './renderSceneRuntime';
import type { EditableMap } from '../shared/map';
import type { RenderScheme } from '../shared/renderScheme';

export interface MapHostOptions extends RenderSceneRuntimeOptions {
  map: EditableMap;
  scheme?: RenderScheme | null;
}

export interface MapHost {
  readonly scene: THREE.Scene;
  readonly camera: THREE.PerspectiveCamera;
  readonly renderer: THREE.WebGLRenderer;
  readonly runtime: RenderSceneRuntime;
  readonly gameplayRoot: THREE.Group;
  readonly rendered: RenderedMap | null;
  readonly map: EditableMap;
  readonly scheme: RenderScheme | null;
  setMap(map: EditableMap): Promise<void>;
  setRenderScheme(scheme: RenderScheme | null): void;
  setSize(width: number, height: number): void;
  tick(deltaTime: number): void;
  getObject(objectId: string): THREE.Group | null;
  dispose(): void;
}

/**
 * Embeds one WorldForge environment into a host game without creating a second
 * frame loop. The environment remains editor-owned while gameplay content is
 * mounted below `gameplayRoot` and survives base-map reloads.
 */
export async function createMapHost(options: MapHostOptions): Promise<MapHost> {
  const runtime = new RenderSceneRuntime(options);
  const gameplayRoot = new THREE.Group();
  gameplayRoot.name = 'worldforge:gameplayRoot';
  gameplayRoot.userData.worldForgeGameplayRoot = true;
  let map = options.map;
  let scheme = options.scheme ?? null;
  let rendered: RenderedMap | null = null;
  let elapsedSeconds = 0;

  const loadMap = async (nextMap: EditableMap): Promise<void> => {
    const previous = rendered;
    runtime.attach(null);
    if (previous) {
      runtime.scene.remove(previous.group);
      previous.dispose();
    }
    map = nextMap;
    runtime.map = map;
    runtime.updateLighting();
    rendered = await buildEditableMapGroup(map, { scene: runtime.scene });
    rendered.modelsRoot.add(gameplayRoot);
    runtime.scene.add(rendered.group);
    runtime.attach(rendered);
    runtime.applyScheme(scheme);
  };

  await loadMap(map);

  return {
    scene: runtime.scene,
    camera: runtime.camera,
    renderer: runtime.renderer,
    runtime,
    gameplayRoot,
    get rendered() { return rendered; },
    get map() { return map; },
    get scheme() { return scheme; },
    setMap: loadMap,
    setRenderScheme: (next) => {
      scheme = next;
      runtime.applyScheme(next);
    },
    setSize: (width, height) => runtime.setSize(width, height),
    tick: (deltaTime) => {
      const delta = Math.max(0, Number(deltaTime) || 0);
      elapsedSeconds += delta;
      runtime.renderFrame(delta, elapsedSeconds);
    },
    getObject: (objectId) => rendered?.objectGroups.get(objectId) ?? null,
    dispose: () => {
      const current = rendered;
      rendered = null;
      runtime.attach(null);
      if (current) {
        runtime.scene.remove(current.group);
        current.dispose();
      }
      gameplayRoot.removeFromParent();
      runtime.dispose();
    }
  };
}
