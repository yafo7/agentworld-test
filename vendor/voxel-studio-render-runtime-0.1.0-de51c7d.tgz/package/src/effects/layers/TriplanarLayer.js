/**
 * TriplanarLayer.js — 真实 Effect Layer：程序化手绘感表面纹理（wood/stone base 用）
 *
 * v2 重写（手绘感，非卡渲——禁止色阶量化，一切过渡平滑）：旧版是均匀中频 fbm 铺满全表面，
 * 一眼程序生成。手绘风纹理的公式相反——「大面积平滑宏观色变 + 稀疏结构性特征」，跳过均匀中频：
 *   - macro：极低频 3D fbm 做整面缓慢色偏（无缝，用世界坐标三投影，避免面接缝）。
 *   - wood（pattern=grain）：沿纹方向的噪声扰动正弦木纹（平滑低对比拉丝）+ 板缝暗线 + **每块板
 *     按 index hash 的微色差**（手绘木质感第一来源）。
 *   - stone（pattern=cellular）：voronoi 元胞（胞内基本平坦 + 柔和裂缝线）+ **每块微色差** + macro 斑。
 *   结构性特征用「主轴投影」（按法线最大分量取 2D UV）而非三投影混合——体素模型面轴对齐，主轴投影
 *   天然干净且更省（三投影混合留给会 45° 斜面的 curve 风格也够用，接缝极弱）。colorLo/colorHi 仍是
 *   围绕 1.0 的乘法调制系数（不是绝对颜色），部件原本涂色/光照始终透出，纹理只叠明暗/色偏细节。
 *   wood/stone 复用同一个 layer，靠 `pattern` 枚举 + material-tags-v1.json / 风格预设的 params 区分。
 *
 * stage = 'base'，与 CartoonBase / MatcapBase 互斥（同为 base 层，见 crossSlotIncompatible）。
 *
 * 硬约束：本文件**不 import three**（继承协议层 EffectLayer，可脱离浏览器 node 自测）。
 */

import { EffectLayer } from '../EffectLayer.js';
import { Triplanar as TRIPLANAR_MANIFEST } from '../coreLayers.manifest.js';

const UNIFORM_NAMES = {
  colorLo: 'uTriplanarColorLo',
  colorHi: 'uTriplanarColorHi',
  scale: 'uTriplanarScale',
  stretch: 'uTriplanarStretch',
  strength: 'uTriplanarStrength',
  // v2 手绘感新增
  pattern: 'uTriplanarPattern',           // 0 = grain(木), 1 = cellular(石)
  grainContrast: 'uTriplanarGrainContrast',// 木纹明暗摆幅
  plankScale: 'uTriplanarPlankScale',     // 木板宽度（世界单位）
  edge: 'uTriplanarEdge',                 // 木板缝暗度 / 石缝裂纹宽度
  cellVariance: 'uTriplanarCellVariance', // 每块板/每胞的微色差幅度
  macroStrength: 'uTriplanarMacroStrength',// 宏观低频色斑强度
  fineNoise: 'uTriplanarFineNoise',       // 细颗粒强度（远低于旧版）
};

export class TriplanarLayer extends EffectLayer {
  constructor(manifest = TRIPLANAR_MANIFEST) {
    super(manifest);
  }

  /** GLSL uniform 声明 + 噪声/voronoi/投影辅助函数（全局作用域，随声明注入到 fragment 顶部）。 */
  getUniformDeclarations() {
    return [
      'uniform vec3 uTriplanarColorLo;',
      'uniform vec3 uTriplanarColorHi;',
      'uniform float uTriplanarScale;',
      'uniform float uTriplanarStretch;',
      'uniform float uTriplanarStrength;',
      'uniform float uTriplanarPattern;',
      'uniform float uTriplanarGrainContrast;',
      'uniform float uTriplanarPlankScale;',
      'uniform float uTriplanarEdge;',
      'uniform float uTriplanarCellVariance;',
      'uniform float uTriplanarMacroStrength;',
      'uniform float uTriplanarFineNoise;',
      '',
      'float triplanarHash(vec2 p) {',
      '  vec3 p3 = fract(vec3(p.xyx) * 0.1031);',
      '  p3 += dot(p3, p3.yzx + 33.33);',
      '  return fract((p3.x + p3.y) * p3.z);',
      '}',
      'float triplanarValueNoise(vec2 p) {',
      '  vec2 i = floor(p);',
      '  vec2 f = fract(p);',
      '  float a = triplanarHash(i);',
      '  float b = triplanarHash(i + vec2(1.0, 0.0));',
      '  float c = triplanarHash(i + vec2(0.0, 1.0));',
      '  float d = triplanarHash(i + vec2(1.0, 1.0));',
      '  vec2 u = f * f * (3.0 - 2.0 * f);',
      '  return mix(mix(a, b, u.x), mix(c, d, u.x), u.y);',
      '}',
      'float triplanarFbm(vec2 p) {',
      '  float sum = 0.0;',
      '  float amp = 0.5;',
      '  for (int i = 0; i < 3; i++) {',
      '    sum += triplanarValueNoise(p) * amp;',
      '    p *= 2.02;',
      '    amp *= 0.5;',
      '  }',
      '  return sum;',
      '}',
      '// 极低频宏观色变：世界空间三投影混合（无缝），返回环绕 0.5 的值。',
      'float triplanarMacro(vec3 worldPos, vec3 worldNormal, float scale) {',
      '  vec3 n = abs(normalize(worldNormal));',
      '  n = pow(n, vec3(4.0));',
      '  n /= (n.x + n.y + n.z + 1e-5);',
      '  float xP = triplanarFbm(worldPos.zy * scale);',
      '  float yP = triplanarFbm(worldPos.xz * scale);',
      '  float zP = triplanarFbm(worldPos.xy * scale);',
      '  return xP * n.x + yP * n.y + zP * n.z;',
      '}',
      '// 主轴投影：按法线最大分量取一张 2D UV（体素面轴对齐→天然无接缝、比三投影省）。',
      'vec2 triplanarDominantUv(vec3 worldPos, vec3 worldNormal) {',
      '  vec3 an = abs(normalize(worldNormal));',
      '  if (an.x >= an.y && an.x >= an.z) return worldPos.zy;',
      '  if (an.y >= an.z) return worldPos.xz;',
      '  return worldPos.xy;',
      '}',
      '// Voronoi F1 + 命中胞 id（石纹用）。',
      'void triplanarVoronoi(vec2 p, out float f1, out vec2 cellId) {',
      '  vec2 ip = floor(p);',
      '  vec2 fp = fract(p);',
      '  f1 = 8.0;',
      '  cellId = ip;',
      '  for (int y = -1; y <= 1; y++) {',
      '    for (int x = -1; x <= 1; x++) {',
      '      vec2 g = vec2(float(x), float(y));',
      '      vec2 o = vec2(triplanarHash(ip + g), triplanarHash(ip + g + 17.13));',
      '      vec2 r = g + o - fp;',
      '      float d = dot(r, r);',
      '      if (d < f1) { f1 = d; cellId = ip + g; }',
      '    }',
      '  }',
      '  f1 = sqrt(f1);',
      '}',
    ].join('\n');
  }

  /** 世界空间 varying 由 injector 统一提供（vEffLayerWorldPos / vEffLayerWorldNormal），本层 vertex 无需求。 */
  getVertexBody() {
    return '';
  }

  /**
   * 片元 body：按 pattern 分木/石/砖/大理石/鹅卵石，用主轴投影做结构性特征（拉丝/板缝/元胞/
   * 网格/脉络），叠 macro 低频色斑与微色差，全部**平滑过渡**（无色阶量化）。结果按乘法调制
   * 已有光照色，strength 控制整体强度。
   *
   * 立体感（v2.1 追加）：wood/stone 在压暗缝线/裂缝的基础上，紧贴缝线内侧再叠一条更窄的亮带
   * （复用同一个 plankFrac/f1 值，宽度由已有的 edge 派生），做出"斜切倒角"的漫画式凸起错觉。
   * 零新增 uniform、不碰法线/光照，成本是每 fragment 多几条 smoothstep，与场景内物体数量无关。
   */
  getFragmentBody() {
    return [
      'vec3 triWp = vEffLayerWorldPos;',
      'vec3 triWn = normalize(vEffLayerWorldNormal);',
      'vec2 triUv = triplanarDominantUv(triWp, triWn);',
      '',
      '// 宏观低频色斑（材质共用）：整面缓慢明暗起伏，打破重复。',
      'float triMacro = triplanarMacro(triWp, triWn, uTriplanarScale * 0.11);',
      'float triMacroShade = mix(1.0 - uTriplanarMacroStrength, 1.0 + uTriplanarMacroStrength, triMacro);',
      '',
      '// 细颗粒（低强度，避免均匀中频感——旧版病灶）。',
      'float triFine = triplanarValueNoise(triUv * uTriplanarScale * 6.0);',
      'float triFineShade = mix(1.0 - uTriplanarFineNoise, 1.0 + uTriplanarFineNoise, triFine);',
      '',
      'vec3 triTint;',
      'if (uTriplanarPattern < 0.5) {',
      '  // ===== WOOD：噪声扰动正弦木纹 + 板缝 + 每板微色差/频率抖动 =====',
      '  vec2 gUv = triUv * vec2(uTriplanarScale * uTriplanarStretch, uTriplanarScale);',
      '  // 板缝：沿纹方向的长条木板，按 triUv.y 切分；接缝处平滑压暗。先算 plankId 供频率抖动用。',
      '  float plankF = triUv.y / max(uTriplanarPlankScale, 0.01);',
      '  float plankId = floor(plankF);',
      '  float plankFrac = fract(plankF);',
      '  // 每块板独立的木纹节奏：频率/振幅按 plankId hash 轻微扰动，相邻板不再是同一节奏的复制。',
      '  float grainFreqJit = mix(0.8, 1.2, triplanarHash(vec2(plankId, 11.3)));',
      '  float warp = triplanarFbm(gUv * 0.5 * grainFreqJit) * 2.0 - 1.0;',
      '  float grain = sin(gUv.x * 3.14159 * grainFreqJit + warp * 1.8) * 0.5 + 0.5;   // 0..1 平滑',
      '  float grainShade = mix(1.0 - uTriplanarGrainContrast, 1.0 + uTriplanarGrainContrast, grain);',
      '  float seam = smoothstep(0.0, uTriplanarEdge, plankFrac) * smoothstep(0.0, uTriplanarEdge, 1.0 - plankFrac);',
      '  // 立体感：缝线内侧一条窄亮带（复用 plankFrac，宽度由 edge 派生）。',
      '  float bevelW = uTriplanarEdge * 0.5;',
      '  float bevelLo = smoothstep(uTriplanarEdge, uTriplanarEdge + bevelW, plankFrac) - smoothstep(uTriplanarEdge + bevelW, uTriplanarEdge + bevelW * 2.0, plankFrac);',
      '  float bevelHi = smoothstep(uTriplanarEdge, uTriplanarEdge + bevelW, 1.0 - plankFrac) - smoothstep(uTriplanarEdge + bevelW, uTriplanarEdge + bevelW * 2.0, 1.0 - plankFrac);',
      '  float bevel = clamp(bevelLo + bevelHi, 0.0, 1.0);',
      '  // 每块板微色差：按 plankId hash 出 ±cellVariance 的明度/色偏。',
      '  float plankJit = (triplanarHash(vec2(plankId, 3.7)) - 0.5) * 2.0 * uTriplanarCellVariance;',
      '  triTint = mix(uTriplanarColorLo, uTriplanarColorHi, grain);',
      '  triTint *= (1.0 + plankJit);',
      '  triTint *= mix(1.0 - uTriplanarEdge, 1.0, seam);   // 缝线压暗',
      '  triTint *= (1.0 + bevel * uTriplanarEdge * 0.4);   // 缝线旁亮边',
      '  triTint *= grainShade;',
      '} else if (uTriplanarPattern < 1.5) {',
      '  // ===== STONE：voronoi 元胞（碎石）+ 每胞微色差 + 柔和裂缝 =====',
      '  vec2 sUv = triUv * uTriplanarScale;',
      '  float f1; vec2 cellId;',
      '  triplanarVoronoi(sUv, f1, cellId);',
      '  float edgeW = max(uTriplanarEdge, 0.02);',
      '  float crack = smoothstep(0.0, edgeW, f1);   // 胞边→0 压暗，胞内→1',
      '  // 立体感：裂缝外侧一条窄亮带（复用 f1，宽度由 edge 派生）。',
      '  float bevelW2 = edgeW * 0.6;',
      '  float bevel2 = clamp(smoothstep(edgeW, edgeW + bevelW2, f1) - smoothstep(edgeW + bevelW2, edgeW + bevelW2 * 2.0, f1), 0.0, 1.0);',
      '  float cellJit = (triplanarHash(cellId + 5.3) - 0.5) * 2.0 * uTriplanarCellVariance;',
      '  float cellTone = triplanarHash(cellId + 9.1);',
      '  triTint = mix(uTriplanarColorLo, uTriplanarColorHi, mix(0.35, 0.75, cellTone));',
      '  triTint *= (1.0 + cellJit);',
      '  triTint *= mix(1.0 - uTriplanarEdge, 1.0, crack);   // 裂缝压暗',
      '  triTint *= (1.0 + bevel2 * uTriplanarEdge * 0.4);   // 裂缝旁亮边',
      '} else if (uTriplanarPattern < 2.5) {',
      '  // ===== BRICK：规则网格 + 隔行错缝 + 逐砖微色差 =====',
      '  float brickH = max(uTriplanarPlankScale, 0.01);',
      '  float brickW = brickH * 2.0;   // 砖宽 = 2x 砖高，常见砌砖比例',
      '  float rowF = triUv.y / brickH;',
      '  float rowId = floor(rowF);',
      '  float rowFrac = fract(rowF);',
      '  float rowOffset = mod(rowId, 2.0) * 0.5;   // 隔行错缝半砖',
      '  float colF = triUv.x / brickW + rowOffset;',
      '  float colId = floor(colF);',
      '  float colFrac = fract(colF);',
      '  float mortarH = smoothstep(0.0, uTriplanarEdge, rowFrac) * smoothstep(0.0, uTriplanarEdge, 1.0 - rowFrac);',
      '  float mortarV = smoothstep(0.0, uTriplanarEdge, colFrac) * smoothstep(0.0, uTriplanarEdge, 1.0 - colFrac);',
      '  float mortar = mortarH * mortarV;',
      '  vec2 brickId = vec2(colId, rowId);',
      '  float brickJit = (triplanarHash(brickId + 3.7) - 0.5) * 2.0 * uTriplanarCellVariance;',
      '  float brickTone = triplanarHash(brickId + 9.1);',
      '  triTint = mix(uTriplanarColorLo, uTriplanarColorHi, mix(0.35, 0.75, brickTone));',
      '  triTint *= (1.0 + brickJit);',
      '  triTint *= mix(1.0 - uTriplanarEdge, 1.0, mortar);   // 灰缝压暗',
      '} else if (uTriplanarPattern < 3.5) {',
      '  // ===== MARBLE：均匀浅色底 + 两组交叉细脉络线（不是整面色块渐变） =====',
      '  vec2 mUv = triUv * vec2(uTriplanarScale * 0.35, uTriplanarScale * 1.8);   // 沿一个方向拉长',
      '  float veinWarp = triplanarFbm(mUv * 0.4) * 2.0 - 1.0;',
      '  float veinField = triplanarFbm(vec2(mUv.x + veinWarp * 2.2, mUv.y));',
      '  // 第二组脉络：轴互换（~90°交叉），真实大理石脉络会分支交叉，不是单一方向的一条纹。',
      '  vec2 mUv2 = triUv * vec2(uTriplanarScale * 1.8, uTriplanarScale * 0.35);',
      '  float veinWarp2 = triplanarFbm(mUv2 * 0.37) * 2.0 - 1.0;',
      '  float veinField2 = triplanarFbm(vec2(mUv2.x, mUv2.y + veinWarp2 * 2.2));',
      '  // 从平滑噪声场里"抠"出一条窄线：噪声值贴近 0.5/0.55 的地方才是脉络，其余是均匀底色。',
      '  float veinLineW = 0.04 + uTriplanarEdge * 0.12;',
      '  float veinLine1 = 1.0 - smoothstep(0.0, veinLineW, abs(veinField - 0.5));',
      '  float veinLine2 = 1.0 - smoothstep(0.0, veinLineW * 0.85, abs(veinField2 - 0.55));',
      '  float veinMask = clamp(veinLine1 + veinLine2 * 0.7, 0.0, 1.0);',
      '  triTint = mix(uTriplanarColorHi, uTriplanarColorLo, veinMask);   // 底色=colorHi，脉络才掺 colorLo',
      '} else {',
      '  // ===== COBBLESTONE：放大版 voronoi + 更圆润的裂缝 + 更强 macro 色差 =====',
      '  vec2 cUv = triUv * uTriplanarScale * 0.45;   // cell 比碎石更大',
      '  float f1c; vec2 cellIdC;',
      '  triplanarVoronoi(cUv, f1c, cellIdC);',
      '  float crackC = smoothstep(0.0, max(uTriplanarEdge * 1.6, 0.03), f1c);   // 更宽裂缝→更圆润',
      '  float cellJitC = (triplanarHash(cellIdC + 5.3) - 0.5) * 2.0 * uTriplanarCellVariance * 1.4;',
      '  float cellToneC = triplanarHash(cellIdC + 9.1);',
      '  triTint = mix(uTriplanarColorLo, uTriplanarColorHi, mix(0.3, 0.85, cellToneC));',
      '  triTint *= (1.0 + cellJitC);',
      '  triTint *= mix(1.0 - uTriplanarEdge, 1.0, crackC);   // 裂缝压暗',
      '}',
      '',
      'triTint *= triMacroShade * triFineShade;',
      'vec3 triResult = gl_FragColor.rgb * triTint;',
      'gl_FragColor.rgb = mix(gl_FragColor.rgb, triResult, clamp(uTriplanarStrength, 0.0, 1.0));',
    ].join('\n');
  }

  /**
   * Runtime helper：用注入的 THREE 把 manifest 默认值转成 three uniform 对象。
   * @param {object} THREE - three 命名空间
   * @param {object} [overrides] - 可选覆盖（param 名同 manifest）
   * @returns {Object<string,{value:*}>}
   */
  getThreeUniforms(THREE, overrides = {}) {
    const d = this.getDefaultUniforms();
    const colorLo = overrides.colorLo ?? d.colorLo;
    const colorHi = overrides.colorHi ?? d.colorHi;
    const f = (name) => ({ value: overrides[name] ?? d[name] });
    return {
      [UNIFORM_NAMES.colorLo]: { value: new THREE.Color(colorLo[0], colorLo[1], colorLo[2]) },
      [UNIFORM_NAMES.colorHi]: { value: new THREE.Color(colorHi[0], colorHi[1], colorHi[2]) },
      [UNIFORM_NAMES.scale]: f('scale'),
      [UNIFORM_NAMES.stretch]: f('stretch'),
      [UNIFORM_NAMES.strength]: f('strength'),
      [UNIFORM_NAMES.pattern]: f('pattern'),
      [UNIFORM_NAMES.grainContrast]: f('grainContrast'),
      [UNIFORM_NAMES.plankScale]: f('plankScale'),
      [UNIFORM_NAMES.edge]: f('edge'),
      [UNIFORM_NAMES.cellVariance]: f('cellVariance'),
      [UNIFORM_NAMES.macroStrength]: f('macroStrength'),
      [UNIFORM_NAMES.fineNoise]: f('fineNoise'),
    };
  }

  /** param→GLSL uniform 名映射，供 builder 生成 uniformDefaults 及 runtime 调参复用。 */
  getParamUniformMap() {
    return { ...UNIFORM_NAMES };
  }

  static get UNIFORM_NAMES() {
    return { ...UNIFORM_NAMES };
  }
}
