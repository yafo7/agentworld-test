/**
 * coreLayers.manifest.js — 5 个核心层的 provisional manifest（任务书 #01）
 *
 * 仅数据，无 GLSL。params 为初版（后续实现 brief 可微调）；
 * 结构字段（id/stage/tier/channels/compat/cost/stateBindings）是契约，改动需理由。
 * 注：stage 即执行顺序大类，曾名 category，见 EffectLayer.js 术语提醒。
 *
 * 硬约束：纯数据，禁止 import three / 任何 CartoonShader 文件。
 * 这里的 `CartoonBase` 只是数据 manifest，与现有 CartoonShader GLSL **不接线**。
 */

import { OVERRIDE_LAYER_MANIFESTS } from './overrideLayers.manifest.js';

// 5 个核心层（CartoonBase 除外）共享的 base 兼容声明
const BASE_COMPATIBLE = ['CartoonBase', 'PBRBase'];

export const CartoonBase = {
  id: 'CartoonBase',
  displayName: 'Cartoon Base',
  tier: 'base',
  stage: 'base',
  channels: ['baseColor'],
  requires: { uniforms: [], varyings: [], textures: [] },
  params: {},
  cost: { instructions: 'low', textureReads: 0, drawCalls: 0 },
  compatibleWith: [], // base 层自身不声明 compatibleWith
  incompatibleWith: ['MatcapBase'], // 同为 base 层，二选一
  stateBindings: [],
};

// MatcapBase（Phase 2A）：程序化球形光泽 base 层。
//   视线空间法线 → 球面 UV → 渐变 + 高光 + 边缘光，替换标准着色，为武器/装备塑造球形光泽与体块感。
//   v1 纯程序化（无 matcap 纹理）→ requires.textures / cost.textureReads = 0。与 CartoonBase 互斥（同 base 层）。
export const MatcapBase = {
  id: 'MatcapBase',
  displayName: 'Matcap Base',
  tier: 'standard',
  stage: 'base',
  channels: ['baseColor'],
  requires: { uniforms: [], varyings: [], textures: [] },
  params: {
    // 渐变两端：高光端（朝光）/ 阴影端（背光）
    colorHi: { type: 'color', default: [0.92, 0.95, 1.0] },
    colorLo: { type: 'color', default: [0.08, 0.10, 0.18] },
    // 程序化高光（fake specular）
    specColor: { type: 'color', default: [1.0, 1.0, 1.0] },
    specStrength: { type: 'float', default: 0.7, min: 0, max: 3 },
    shininess: { type: 'float', default: 24, min: 1, max: 128 },
    // 边缘光（rim）
    rimColor: { type: 'color', default: [0.5, 0.7, 1.0] },
    rimStrength: { type: 'float', default: 0.3, min: 0, max: 3 },
    rimPower: { type: 'float', default: 3.0, min: 0.5, max: 8 },
    // 整体替换强度：1=完全替换标准着色，<1=与原着色混合
    strength: { type: 'float', default: 1.0, min: 0, max: 1 },
  },
  cost: { instructions: 'med', textureReads: 0, drawCalls: 0 },
  compatibleWith: [], // base 层自身不声明 compatibleWith
  incompatibleWith: ['CartoonBase'],
  crossSlotIncompatible: ['CartoonBase', 'Glass'],
  stateBindings: [],
};

export const Flame = {
  id: 'Flame',
  displayName: 'Flame',
  tier: 'standard',
  stage: 'color',
  channels: ['baseColor', 'emissive'],
  // v1 为纯程序化火焰（无噪声贴图）→ requires.textures/cost.textureReads 同步为 0（见 #04 FlameLayer 实现）
  requires: { uniforms: ['uTime'], varyings: [], textures: [] },
  params: {
    color: { type: 'color', default: [0.1, 0.4, 1.0], freeLocked: true },
    intensity: { type: 'float', default: 0.9, min: 0, max: 2, freeLocked: true },
    speed: { type: 'float', default: 1.2, min: 0, max: 5 },
    tintStrength: { type: 'float', default: 0.18, min: 0, max: 1 },
    glowStrength: { type: 'float', default: 0.8, min: 0, max: 3 },
    scale: { type: 'float', default: 2.0, min: 0.2, max: 8 },
    threshold: { type: 'float', default: 0.55, min: 0, max: 1 },
  },
  cost: { instructions: 'med', textureReads: 0, drawCalls: 0 },
  compatibleWith: BASE_COMPATIBLE,
  incompatibleWith: ['DissolveLayer'],
  stateBindings: [],
};

export const EmissivePulse = {
  id: 'EmissivePulse',
  displayName: 'Emissive Pulse',
  tier: 'standard',
  stage: 'emissive',
  channels: ['emissive'],
  requires: { uniforms: ['uTime'], varyings: [], textures: [] },
  params: {
    color: { type: 'color', default: [1, 0.8, 0.2] },
    speed: { type: 'float', default: 1.0, min: 0, max: 5 },
    intensity: { type: 'float', default: 0.8, min: 0, max: 2 },
  },
  cost: { instructions: 'low', textureReads: 0, drawCalls: 0 },
  compatibleWith: BASE_COMPATIBLE,
  incompatibleWith: [],
  stateBindings: [],
};

export const HitFlash = {
  id: 'HitFlash',
  displayName: 'Hit Flash',
  tier: 'standard',
  stage: 'feedback',
  channels: ['baseColor', 'emissive'],
  requires: { uniforms: ['uHitFlash'], varyings: [], textures: [] },
  params: {
    flashColor: { type: 'color', default: [1, 1, 1] },
    falloff: { type: 'float', default: 3.0, min: 0.1, max: 10 },
    intensity: { type: 'float', default: 1, min: 0, max: 3 },
  },
  cost: { instructions: 'low', textureReads: 0, drawCalls: 0 },
  compatibleWith: BASE_COMPATIBLE,
  incompatibleWith: [],
  stateBindings: ['uHitFlash'],
};

// ChargeAura（Phase 2A）：蓄力辉光层——绑运行时 uChargeLevel，蓄力越高辉光越强，满蓄闪烁加剧。
//   护城河 1 的可玩化落点（视觉随战斗状态实时响应）。stage='feedback'（与 HitFlash 同大类）。
//   uChargeLevel/uTime 为运行时 uniform（由 GameStateUniformBus / 动画循环 tick），不进 variantKey。
export const ChargeAura = {
  id: 'ChargeAura',
  displayName: 'Charge Aura',
  tier: 'standard',
  stage: 'feedback',
  channels: ['emissive'],
  requires: { uniforms: ['uChargeLevel', 'uTime'], varyings: [], textures: [] },
  params: {
    color: { type: 'color', default: [0.4, 0.7, 1.0] },
    intensity: { type: 'float', default: 1.0, min: 0, max: 3 },
    pulseSpeed: { type: 'float', default: 2.0, min: 0, max: 10 },
    risePower: { type: 'float', default: 1.5, min: 0.2, max: 4 }, // charge→glow gamma
    rimBias: { type: 'float', default: 0.6, min: 0, max: 1 },     // 0=整体辉光 1=仅轮廓蒸腾
  },
  cost: { instructions: 'med', textureReads: 0, drawCalls: 0 },
  compatibleWith: BASE_COMPATIBLE,
  incompatibleWith: [],
  stateBindings: ['uChargeLevel'],
};

// Triplanar（wood/stone base 用）：世界空间三投影程序化材质，无需 UV/贴图。
//   wood/stone 复用同一个 layer，靠 colorLo/colorHi/scale/stretch 区分观感（见 TriplanarLayer.js 头注）。
export const Triplanar = {
  id: 'Triplanar',
  displayName: 'Triplanar Material',
  tier: 'standard',
  stage: 'base',
  channels: ['baseColor'],
  requires: { uniforms: [], varyings: [], textures: [] },
  // v2 手绘感：pattern 分木/石；结构参数（grain/plank/edge/cell）+ macro/fine。默认档=wood。
  params: {
    colorLo: { type: 'color', default: [0.55, 0.48, 0.40] },
    colorHi: { type: 'color', default: [1.22, 1.00, 0.85] },
    scale: { type: 'float', default: 5.1, min: 0.1, max: 20 },
    stretch: { type: 'float', default: 9.0, min: 1, max: 12 },
    strength: { type: 'float', default: 0.9, min: 0, max: 1 },
    pattern: { type: 'float', default: 0.0, min: 0, max: 4 },      // 0=grain(wood) 1=cellular(stone) 2=brick 3=marble 4=cobblestone
    grainContrast: { type: 'float', default: 0.22, min: 0, max: 0.6 },
    plankScale: { type: 'float', default: 0.55, min: 0.05, max: 4 },
    edge: { type: 'float', default: 0.32, min: 0.02, max: 0.6 },
    cellVariance: { type: 'float', default: 0.10, min: 0, max: 0.35 },
    macroStrength: { type: 'float', default: 0.14, min: 0, max: 0.5 },
    fineNoise: { type: 'float', default: 0.05, min: 0, max: 0.3 },
  },
  cost: { instructions: 'med', textureReads: 0, drawCalls: 0 },
  compatibleWith: [], // base 层自身不声明 compatibleWith
  incompatibleWith: ['CartoonBase', 'MatcapBase'],
  crossSlotIncompatible: ['CartoonBase', 'MatcapBase', 'Glass'],
  stateBindings: [],
};

export const FresnelRim = {
  id: 'FresnelRim',
  displayName: 'Fresnel Rim',
  tier: 'standard',
  stage: 'stylization',
  channels: ['emissive'],
  requires: { uniforms: [], varyings: [], textures: [] },
  params: {
    color: { type: 'color', default: [0.6, 0.8, 1.0], designerRange: { h: [180, 280], s: [0.2, 1], v: [0.4, 1] }, aiRange: { h: [190, 250], s: [0.3, 0.9], v: [0.5, 1] } },
    power: { type: 'float', default: 3.0, min: 0.5, max: 8, hardRange: [0.5, 10], designerRange: [0.8, 8], aiRange: [1.2, 4] },
    intensity: { type: 'float', default: 1.0, min: 0, max: 3, hardRange: [0, 5], designerRange: [0, 3], aiRange: [0.5, 2.5] },
  },
  cost: { instructions: 'low', textureReads: 0, drawCalls: 0 },
  compatibleWith: BASE_COMPATIBLE,
  incompatibleWith: [],
  stateBindings: [],
  forbidden: ['intensity > 4', 'power < 0.8'],
  notes: [
    'Fresnel rim should highlight edges without overpowering the base material.',
    'Do not generate parameters outside the allowed ranges.',
  ],
};

export const CORE_LAYER_MANIFESTS = [
  CartoonBase,
  MatcapBase,
  Triplanar,
  Flame,
  EmissivePulse,
  HitFlash,
  ChargeAura,
  FresnelRim,
  ...OVERRIDE_LAYER_MANIFESTS,
];

/**
 * 把 5 个核心层注册进给定 registry。
 * @param {{register: (manifest:object)=>any}} registry
 * @returns {string[]} 已注册的 id 列表
 */
export function registerCoreLayers(registry) {
  for (const manifest of CORE_LAYER_MANIFESTS) {
    registry.register(manifest);
  }
  return CORE_LAYER_MANIFESTS.map(m => m.id);
}
