const DEFAULT_URL = new URL('../../model/material-tags-v1.json', import.meta.url).href;

let cachedPromise = null;
let cachedUrl = null;

function isObject(value) {
  return value !== null && typeof value === 'object' && !Array.isArray(value);
}

const EXPLICIT_SILVER_PATTERN = /\b(?:silver|sterling|argent)\b|白银|纯银|镀银|银(?:色|白|质|制|饰|剑|刃|柄|甲|盔)/i;
const STRUCTURAL_TAGS = new Set(['base', 'water']);

function nodeTags(node) {
  return Array.isArray(node?.tags) ? node.tags : [];
}

function isCompanionTag(tagName, vocabulary) {
  return isObject(vocabulary?.tags?.[tagName]?.runtime?.companion);
}

/**
 * Normalize and validate material tags returned by the generation backend.
 * Existing imported models are intentionally not passed through this boundary.
 */
export function prepareGeneratedMaterialTags(modelJson, {
  description = '',
  vocabulary = null,
  normalizeSilver = false,
} = {}) {
  const nodes = Array.isArray(modelJson?.nodes) ? modelJson.nodes : [];
  const errors = [];
  let normalizedSilver = 0;

  if (normalizeSilver && !EXPLICIT_SILVER_PATTERN.test(description)) {
    for (const node of nodes) {
      for (const tag of nodeTags(node)) {
        if (tag?.tag === 'base' && tag.value === 'silver') {
          tag.value = 'metal';
          delete tag.variant;
          normalizedSilver++;
        }
      }
    }
  }

  const byId = new Map(nodes.map(node => [node?.id, node]));
  const childrenByParent = new Map();
  for (const node of nodes) {
    if (!node?.parent) continue;
    const children = childrenByParent.get(node.parent) || [];
    children.push(node);
    childrenByParent.set(node.parent, children);
  }

  for (const node of nodes) {
    if (node?.mesh) continue;
    const companionTags = nodeTags(node).filter(tag => isCompanionTag(tag?.tag, vocabulary));
    if (!companionTags.length) continue;

    for (const tag of companionTags) {
      if (!node.parent) {
        errors.push({
          nodeId: node.id,
          tag: tag.tag,
          reason: 'companion effect group cannot be the model root',
        });
      }

      let ancestor = byId.get(node.parent);
      while (ancestor) {
        const inheritedConflict = nodeTags(ancestor).find(candidate =>
          STRUCTURAL_TAGS.has(candidate?.tag) || isCompanionTag(candidate?.tag, vocabulary));
        if (inheritedConflict) {
          errors.push({
            nodeId: node.id,
            tag: tag.tag,
            reason: `companion effect group inherits conflicting '${inheritedConflict.tag}' from ancestor '${ancestor.id}'`,
          });
          break;
        }
        ancestor = byId.get(ancestor.parent);
      }

      for (const child of childrenByParent.get(node.id) || []) {
        if (!child.mesh) {
          errors.push({
            nodeId: node.id,
            tag: tag.tag,
            reason: `companion effect group must contain direct mesh children; '${child.id}' is a nested group`,
          });
          continue;
        }
        const childConflict = nodeTags(child).find(candidate => STRUCTURAL_TAGS.has(candidate?.tag));
        if (childConflict) {
          errors.push({
            nodeId: child.id,
            tag: tag.tag,
            reason: `companion mesh cannot also declare structural '${childConflict.tag}'`,
          });
        }
      }
    }
  }

  return { valid: errors.length === 0, errors, normalizedSilver, modelJson };
}

export function getDefaultMaterialTagVocabularyUrl() {
  return DEFAULT_URL;
}

export function validateMaterialTagVocabulary(vocabulary) {
  const errors = [];
  if (!isObject(vocabulary)) {
    return { valid: false, tagCount: 0, errors: ['vocabulary must be an object'] };
  }
  if (!isObject(vocabulary.README)) errors.push('README must be an object');
  if (!isObject(vocabulary.tags)) errors.push('tags must be an object');

  const entries = isObject(vocabulary.tags) ? Object.entries(vocabulary.tags) : [];
  for (const [name, definition] of entries) {
    if (!isObject(definition)) {
      errors.push(`tags.${name} must be an object`);
      continue;
    }
    if (definition.mode !== 'enum' && definition.mode !== 'blend') {
      errors.push(`tags.${name}.mode must be enum or blend`);
    }
    if (typeof definition.description !== 'string' || !definition.description.trim()) {
      errors.push(`tags.${name}.description must be a non-empty string`);
    }
    if (definition.mode === 'enum' && (!Array.isArray(definition.values) || definition.values.length === 0)) {
      errors.push(`tags.${name}.values must be a non-empty array`);
    }
    if (definition.variantEnum !== undefined && !Array.isArray(definition.variantEnum)) {
      errors.push(`tags.${name}.variantEnum must be an array`);
    }
  }

  return { valid: errors.length === 0, tagCount: entries.length, errors };
}

export function resetMaterialTagVocabularyCache() {
  cachedPromise = null;
  cachedUrl = null;
}

export async function getMaterialTagVocabulary(options = {}) {
  const url = options.url || getDefaultMaterialTagVocabularyUrl();
  const fetchImpl = options.fetchImpl || globalThis.fetch;
  if (typeof fetchImpl !== 'function') throw new Error('material tag vocabulary fetch is unavailable');
  if (cachedPromise && cachedUrl === url) return cachedPromise;

  cachedUrl = url;
  cachedPromise = (async () => {
    const response = await fetchImpl(url, { headers: { Accept: 'application/json' } });
    if (!response?.ok) throw new Error(`material tag vocabulary request failed: ${response?.status ?? 'unknown'}`);
    const vocabulary = await response.json();
    const validation = validateMaterialTagVocabulary(vocabulary);
    if (!validation.valid) {
      throw new Error(`invalid material tag vocabulary: ${validation.errors.join('; ')}`);
    }
    return vocabulary;
  })().catch((error) => {
    cachedPromise = null;
    cachedUrl = null;
    throw error;
  });

  return cachedPromise;
}

export async function resolveMaterialTagVocabulary(value, options = {}) {
  if (value === false) return null;
  if (isObject(value)) {
    const validation = validateMaterialTagVocabulary(value);
    if (!validation.valid) {
      throw new Error(`invalid material tag vocabulary: ${validation.errors.join('; ')}`);
    }
    return value;
  }
  return getMaterialTagVocabulary(options);
}
